from django.contrib import admin
from .models import Product, ProductProperties


admin.site.register(Product)
admin.site.register(ProductProperties)
