from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response

from items.models import Product
from items.serializers import MinimizeProductSerializer, TableProductsSerializer


class ProductsListView(APIView):
    def get(self, request, *args, **kwargs):
        """
        The get function is used to get a list of products from the database.
            The function takes in a request object and returns a response object.
            The request object contains the query parameters that are passed into it, which are then used to filter out
            products from the database based on their id's. These id's are stored in an array called 'products_ids'.

        :param self: Represent the instance of the object
        :param request: Get the request object
            :argument query_params dictionary request parameters
                :argument products_list string(list of number) list of products
        :param *args: Send a non-keyworded variable length argument list to the function
        :param **kwargs: Pass keyworded, variable-length argument list to a function
        :return: A list of products in the database
        """
        try:
            products_ids = list(map(int, request.query_params.get('products_list', None).split(',')))
            products = Product.objects.filter(id__in=products_ids)
        except Exception as e:
            return Response(status=status.HTTP_400_BAD_REQUEST)
        return Response(MinimizeProductSerializer(products, many=True).data, status=status.HTTP_200_OK)
    

