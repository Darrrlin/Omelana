import json
from datetime import timedelta, datetime

from django.core.paginator import PageNotAnInteger, EmptyPage, Paginator
from django.db.models import Q, F
from django.forms import model_to_dict
from django.utils import timezone

from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from rest_framework.response import Response

from category.models import Category, CategoryProperties
from items.models import Product, ProductProperties, ProductImage
from items.serializers import ProductSerializer, MinimizeProductSerializer, TableProductsSerializer
from oauth.authenticate import ModifyAuthentication
from omelana.settings import LOGGING_CHANGE_TEMPLATE, LOGGING_COPPY_TEMPLATE, LOGGING_DELETE_TEMPLATE, \
    LOGGING_ADD_TEMPLATE
from loggs.models import Logs
from omelana.uttils import json_date_to_datetime


def delete_elements(ids):
    """
    The delete_elements function takes a list of ids and updates the on_delete field to True for all products with those ids.
        This function is used in conjunction with the delete_products view, which allows users to select multiple products at once
        and delete them.

    :param ids: Filter the products that are to be deleted
    :return: A queryset of the elements that were deleted
    """
    for product in Product.objects.filter(id__in=ids):
        product.on_delete = True
        product.save()


def toggle_deleted_elements(ids):
    """
    The undeleted_elements function takes a list of ids and updates the on_delete field to False for all products with those ids.

    :param ids: Get the ids of all the products that are deleted
    :return: A queryset of the product objects that were set to on_delete=false
    """
    for product in Product.objects.filter(id__in=ids):
        product.on_delete = not product.on_delete
        product.save()


def set_sale_products(ids, sale, current_time, date_start, date_end):
    """
    The set_sale_products function takes in a list of product ids, a sale percentage,
    a current time string (in the format 'YYYY-MM-DDTHH:MM:SSZ'), and two date strings
    (also in the format 'YYYY-MM-DDTHH:MM:SSZ'). It then updates all products with those ids to have that sale percentage.
    It also sets their start and end dates based on the current time string and date strings passed into it.

    :param ids: Filter the products
    :param sale: Set the sale attribute of a product
    :param current_time: Convert the time from the client to a datetime object
    :param date_start: Set the date_start field of a product
    :param date_end: Set the end date of the sale
    :return: A list of products that were updated
    """
    products = Product.objects.filter(id__in=ids)
    current_time = json_date_to_datetime(current_time).replace(second=0, microsecond=0)
    different_time = timezone.now().replace(second=0, microsecond=0) - current_time
    date_start = json_date_to_datetime(date_start) - different_time
    date_end = json_date_to_datetime(date_end) - different_time
    products.update(sale=sale, date_start=date_start, date_end=date_end)


def change_status_availability(ids):
    """
    The change_status_availability function takes in a list of product ids and updates the status field for each
    product to be the opposite of what it was before. For example, if a product's status is True (available), then this
    will change it to False (unavailable). If a product's status is False, then this will change it to True.

    :param ids: Filter the products that will be updated
    :return: A queryset object
    """
    for product in Product.objects.filter(id__in=ids):
        product.status = not product.status
        product.save()


class ChangeProductView(APIView):
    authentication_classes = [ModifyAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request, *args, **kwargs):
        """
        The get function is used to retrieve a single product from the database.
            It takes in an id parameter and returns the corresponding product object.


        :param self: Represent the instance of the object itself
        :param request: Get the request that is sent to the server
            :argument query_params dictionary request data
            :argument id integer element id of the product
        :param *args: Send a non-keyworded variable length argument list to the function
        :param **kwargs: Pass keyworded, variable-length argument list to a function
        :return: A product object
        """
        try:
            id = int(request.query_params.get('id'))
            product = Product.objects.get(id=id)
            return Response(ProductSerializer(product).data, status=status.HTTP_200_OK)
        except Exception as e:
            return Response(status=status.HTTP_400_BAD_REQUEST)

    def create(self, request, *args, **kwargs):
        """
        The create function is used to create a new product.
            It takes the following parameters:
                title - The name of the product.
                description - A short description of what the product does.
                price - The price of the item in USD (float).

        :param self: Represent the instance of the object itself
        :param request: Get the data from the request object
            :argument data dictionary request data
                :argument category integer id of the category
                :argument title string title of the product
                :argument description string description of the product
                :argument status integer status product
                :argument ?sale dictionary(JSON.stringify) information for sale
                    :argument percent float percent sale
                    :argument ?timeline dictionary information for timeline
                        :argument date_start timestamp
                        :argument date_end timestamp
                :argument images dictionary of list information for the image product
                    :argument name string name of the image
                    :argument sequence integer sequence of the image
                :argument price float price of the product
                :argument properties list of dictionary properties of the product
            :argument FILES dictionary request files
        :param *args: Send a non-keyworded variable length argument list to the function
        :param **kwargs: Pass keyworded, variable-length argument list to a function
        :return: A response object, which is a serialized product object\
        """
        try:
            category = Category.objects.get(id=int(request.data.get('category')))
            images = request.data.get("images", None)
            sale = request.data.get("sale", None)
            status_product = request.data.get("status", None)
            properties = request.data.get("properties")
            product = Product.objects.create(
                title=request.data.get('title'),
                description=request.data.get('description'),
                price=float(request.data.get('price')),
                category=category)
            try:
                if status_product:
                    status_product = int(status_product)
                    if status_product == 2:
                        product.on_delete = True
                    else:
                        product.status = bool(status_product)
            except Exception as e:
                pass
            product.save()
            if images:
                images = json.loads(images)
                properties = json.loads(properties)
                for image in images:
                    product_image = ProductImage.objects.create(
                        product=product,
                        image=request.FILES.get(image["name"]),
                        sequence=int(image["sequence"])
                    )
                    product_image.save()
            if sale:
                sale = json.loads(sale)
                product.sale = float(sale["percent"])
                date_start = timezone.now()
                date_end = timezone.now() + timedelta(30)
                if "timeline" in sale:
                    if "date_start" in sale["timeline"]:
                        date_start = json_date_to_datetime(sale["timeline"]["date_start"])

                    if "date_end" in sale["timeline"]:
                        date_end = json_date_to_datetime(sale["timeline"]["date_end"])

                product.start_sale = date_start
                product.end_sale = date_end
            else:
                product.sale = 0
                product.start_sale = None
                product.end_sale = None

            product.save()
            for property in properties:
                product_properties = ProductProperties.objects \
                    .create(
                    properties=CategoryProperties.objects.get(id=int(property)),
                    product=product,
                    value=properties[property]
                )
                product_properties.save()

            Logs.objects.create(
                table='products',
                id_element=product.id,
                title="CREATE",
                description=LOGGING_ADD_TEMPLATE.format(id=self.request.user, model="Product", item=product.id)
            )

            return Response(ProductSerializer(product).data, status=status.HTTP_201_CREATED)
        except ZeroDivisionError as e:
            return Response(status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, *args, **kwargs):
        """
        The delete function is used to delete elements from the database.
        It takes in a request object and returns a response object.
        The request should contain an id field with the ids of all elements to be deleted, separated by commas.

        :param self: Represent the instance of the object itself
        :param request: Get the request object
            :argument data dictionary request data
                :argument id string id of the product to be deleted
        :param *args: Send a non-keyworded variable length argument list to the function
        :param **kwargs: Pass keyworded, variable-length argument list to a function
        :return: A status code of 204
        """
        try:
            product_ids = [int(x) for x in request.data.get('id').split(",")]
            delete_elements(product_ids)
            Logs.objects.bulk_create([
                Logs(
                    table='products',
                    id_element=product,
                    title="DELETE",
                    description=LOGGING_DELETE_TEMPLATE.format(id=self.request.user, model="Product", item=product)
                )
                for product in product_ids
            ])

            return Response(status=status.HTTP_204_NO_CONTENT)
        except Exception as e:
            return Response(status=status.HTTP_400_BAD_REQUEST)

    def update(self, request, *args, **kwargs):
        """
        The update function is used to update a product.
            It takes in the following parameters:
                request - The request object that contains the data for updating a product.
                format - The format of the response, defaults to None.

        :param self: Represent the instance of the object
        :param request: Get the data from the request
            :argument data dictionary request data
                :argument category integer id of the category
                :argument id integer id of the product to be updated
                :argument title string title of the product
                :argument description string description of the product
                :argument price float price of the product
                :argument status integer status product
                :argument ?sale dictionary(JSON.stringify) information for sale
                    :argument percent float percent sale
                    :argument ?timeline dictionary information for timeline
                        :argument date_start timestamp
                        :argument date_end timestamp
                :argument properties dict of properties of the product
                    :argument value string value of the product
                :argument ?deleted_images strint(list of number) list of id images of the product
                :argument ?new_images dictionary of list information for the new image product
                    :argument name string name of the image
                    :argument sequence integer sequence of the image
                :argument ?old_images dictionary of list information for the image product
                    :argument id string name of the image
                    :argument sequence integer sequence of the image
            :argument FILES dictionary request files
        :param *args: Send a non-keyworded variable length argument list to the function
        :param **kwargs: Pass keyworded, variable-length argument list to a function
        :return: A response with the serialized product
        """
        try:
            id = int(request.data.get('id'))
            product = Product.objects.get(pk=id)
            product.title = request.data.get('title')
            product.description = request.data.get('description')
            product.price = float(request.data.get('price'))
            status_product = request.data.get("status", None)
            sale = request.data.get("sale", None)
            try:
                if status_product:
                    status_product = int(status_product)
                    if status_product == 2:
                        product.on_delete = True
                    else:
                        product.status = bool(status_product)
            except Exception as e:
                pass
            if sale:
                sale = json.loads(sale)
                product.sale = float(sale["percent"])
                date_start = timezone.now()
                date_end = timezone.now() + timedelta(30)
                if "timeline" in sale:
                    if "date_start" in sale["timeline"]:
                        date_start = json_date_to_datetime(sale["timeline"]["date_start"])

                    if "date_end" in sale["timeline"]:
                        date_end = json_date_to_datetime(sale["timeline"]["date_end"])

                product.start_sale = date_start
                product.end_sale = date_end
            else:
                product.sale = 0
                product.start_sale = None
                product.end_sale = None

            product.save()
            deleted_images = request.data.get('deleted_images', None)
            new_images = request.data.get("new_images", None)
            old_images = request.data.get("old_images", None)
            properties = request.data.get("properties", {})
            properties = json.loads(properties)

            if deleted_images:
                deleted_images = [int(x) for x in json.loads(deleted_images)]
                ProductImage.objects.filter(id__in=deleted_images).delete()
            if new_images:
                new_images = json.loads(new_images)
                for new_image in new_images:
                    product_image = ProductImage.objects.create(
                        product=product,
                        image=request.FILES.get(new_image["name"]),
                        sequence=int(new_image["sequence"])
                    )
                    product_image.save()

            if old_images:
                old_images = json.loads(old_images)
                for old_image in old_images:
                    product_image = ProductImage.objects.get(id=int(old_image["id"]))
                    product_image.sequence = old_image["sequence"]
                    product_image.save()

            try:
                category = Category.objects.get(id=int(request.data.get("category")))
            except Exception as e:
                category = None
            if category and product.category and category.pk == product.category.pk:
                for product_property in ProductProperties.objects.filter(product=product):
                    product_property.value = properties[str(product_property.properties.id)]
                    product_property.save()
            elif category:
                product.category = category
                product.save()
                ProductProperties.objects.filter(product=product).delete()
                for property in properties:
                    product_properties = ProductProperties.objects.create(
                        properties=CategoryProperties.objects.get(id=int(property)),
                        product=product,
                        value=properties[property]
                    )
                    product_properties.save()
            else:
                product.category = None
                product.save()

            Logs.objects.create(
                table='products',
                id_element=product.id,
                title="UPDATE",
                description=LOGGING_CHANGE_TEMPLATE.format(id=self.request.user, model="Product", item=product.id)
            )
            return Response(ProductSerializer(product).data, status=status.HTTP_200_OK)
        except Exception as e:
            return Response(status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, *args, **kwargs):
        """
        The post function is used to perform operations on multiple products at once.
        The type of operation is specified in the request data, and the ids of the products are also passed in as a comma-separated string.
        If an invalid operation type is passed, or if any other error occurs during processing, a 400 response will be returned.

        :param self: Represent the instance of the object itself
        :param request: Get the data from the request
            :argument data dictionary request data
                :argument type_methods string type request method
                :argument type_operations string type of operation to be performed on the products
                :argument id string id of the product to be updated
                :argument ?current_time integer current time of the operation
                :argument ?date_start string start date of the operation
                :argument ?date_end string end date of the operation
        :param *args: Send a non-keyworded variable length argument list to the function
        :param **kwargs: Pass keyworded, variable-length argument list to a function
        :return: A response object with status code 200
        """
        type_methods = request.data.get("type_methods", None)
        if type_methods == "CREATE":
            return self.create(request, *args, **kwargs)
        elif type_methods == "UPDATE":
            return self.update(request, *args, **kwargs)
        type_operations = request.data.get("type_operations")
        try:
            if type(request.data.get('id')) == int:
                product_ids = [request.data.get('id'), ]
            else:
                product_ids = [int(x) for x in request.data.get('id').split(",")]
        except Exception as e:
            return Response(status=status.HTTP_400_BAD_REQUEST)
        if type_operations == "sale":
            try:
                products = Product.objects.filter(id__in=product_ids)
                data_start = request.data.get("date_start", None)
                if data_start:
                    date_start = json_date_to_datetime(data_start)
                else:
                    date_start = timezone.now()

                date_end = request.data.get("date_end", None)
                if date_end:
                    date_end = json_date_to_datetime(date_end)
                else:
                    date_end = date_start + timedelta(30)
                products.update(sale=int(request.data.get("sale")), start_sale=date_start, end_sale=date_end)
                Logs.objects.bulk_create([
                    Logs(
                        table='products',
                        id_element=product,
                        title="UPDATE",
                        description=LOGGING_CHANGE_TEMPLATE.format(
                            id=self.request.user,
                            model="Product",
                            item=product
                        ))
                    for product in product_ids
                ])

            except Exception as e:
                print(e)
                return Response(status=status.HTTP_400_BAD_REQUEST)
        elif type_operations == "change_status_availability":
            for product in Product.objects.filter(id__in=product_ids):
                product.status = not product.status
                product.save()
            Logs.objects.bulk_create([
                Logs(
                    table='products',
                    id_element=product,
                    title="UPDATE",
                    description=LOGGING_CHANGE_TEMPLATE.format(
                        id=self.request.user,
                        model="Product",
                        item=product
                    ))
                for product in product_ids
            ])
        elif type_operations == "toggle_deleted_elements":
            for product in Product.objects.filter(id__in=product_ids):
                product.on_delete = not product.on_delete
                product.save()
            Logs.objects.bulk_create([
                Logs(
                    table='products',
                    id_element=product,
                    title="UPDATE",
                    description=LOGGING_CHANGE_TEMPLATE.format(
                        id=self.request.user,
                        model="Product",
                        item=product
                    ))
                for product in product_ids
            ])
        else:
            return Response(status=status.HTTP_400_BAD_REQUEST)
        return Response(status=status.HTTP_200_OK)

    def put(self, request, *args, **kwargs):  # copy
        """
        The put function is used to copy a product.
            It takes the id of the product to be copied as an argument, and returns a new instance of that product.

        :param self: Represent the instance of the object itself
        :param request: Get the data from the request
            :argument data dictionary request data
                :argument id integer id of the product to be copied
        :param *args: Send a non-keyworded variable length argument list to the function
        :param **kwargs: Pass keyworded, variable-length argument list to a function
        :return: A response object with the serialized product
        """
        try:
            id = int(request.query_params.get('id'))
            instance = Product.objects.get(id=id)

            product = Product.objects.create(
                category=instance.category,
                title=instance.title,
                description=instance.description,
                price=instance.price,
                sale=instance.sale,
                status=instance.status,
                start_sale=instance.start_sale,
                end_sale=instance.end_sale

            )
            product.save()

            if product.category:
                for propertyElement in ProductProperties.objects.filter(product=instance):
                    new_property = ProductProperties.objects.create(
                        product=product,
                        properties=propertyElement.properties,
                        value=propertyElement.value
                    )
                    new_property.save()
            ProductImage.objects.bulk_create([
                ProductImage(product=product, image=instance_image.image, sequence=instance_image.sequence)
                for instance_image in ProductImage.objects.filter(product=instance)
            ])
            Logs.objects.create(
                table='products',
                id_element=product.id,
                title="COPY",
                description=LOGGING_COPPY_TEMPLATE.format(
                    id=self.request.user,
                    model="Product",
                    item=product.id,
                    from_id=instance.id
                )
            )
        except Exception as e:
            return Response(status=status.HTTP_400_BAD_REQUEST)
        return Response(ProductSerializer(product).data, status=status.HTTP_200_OK)


class ProductsTableView(APIView):
    authentication_classes = [ModifyAuthentication]
    permission_classes = [IsAuthenticated]

    # category - category items
    # date_start - date start
    # date_end - date end
    # price_start - price start
    # price_end - price end
    # sale - sale
    # search - search
    # order_by - sorting
    def get(self, request, *args, **kwargs):
        """
        The get function is used to retrieve a list of products.
            The function takes in the following parameters:
                - category (optional): A string representing the id of a category. If no value is provided, then all products are returned regardless of their categories.
                - date_start (optional): A string representing the start date for filtering by creation time. If no value is provided, then all products are returned regardless of their creation times.
                - date_end (optional): A string representing the end date for filtering by creation time. If no value is provided, then all products are returned regardless of their creation times.&quot;

        :param self: Represent the instance of the object itself
        :param request: Get the request object
            :argument query_params dictionary request parameters
                :argument category integer id of the category
                :argument ?date_start string start date
                :argument ?date_end string end date
                :argument ?price_start integer price start
                :argument ?price_end integer price end
                :argument ?sale boolean sale status
                :argument ?search string search term
                :argument ?order_by string sorting order
                :argument ?page string sorting order
        :param *args: Send a non-keyworded variable length argument list to the function
        :param **kwargs: Pass keyworded, variable-length argument list to a function
        :return: A list of products
        """
        category = request.query_params.get("category", None)
        search = request.query_params.get("search", None)
        order_by = request.query_params.get("order_by", None)
        page = int(request.query_params.get("page", 1))

        queryset = Product.objects.all()

        try:
            if category != "none" and category is not None:
                queryset = queryset.filter(category_id=int(category))
            elif category is not None:
                queryset = queryset.filter(category=None)

            if search is not None:
                queryset = queryset.filter(
                    Q(title__icontains=search) |
                    Q(description__icontains=search) |
                    Q(price__icontains=search)
                )
            if order_by is not None:
                queryset = queryset.order_by(*[order_by, "id"])
            else:
                queryset = queryset.order_by("id")

            paginator = Paginator(queryset, 50)
            counts_page = paginator.num_pages

            try:
                queryset = paginator.page(page)
            except PageNotAnInteger:
                queryset = paginator.page(1)
            except EmptyPage:
                queryset = paginator.page(paginator.num_pages)
            queryset = queryset.object_list
        except Exception as e:
            return Response(status=status.HTTP_400_BAD_REQUEST)
        return Response({"data": TableProductsSerializer(queryset, many=True).data, "countsPage": counts_page},
                        status=status.HTTP_200_OK)
