from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response

from items.models import Product, ProductProperties
from items.serializers import MinimizeProductSerializer


class RecommendationProductsView(APIView):
    def get(self, request, *args, **kwargs):
        """
        The get function is used to get a list of products that are similar to the ones in the query_params.
        The function takes a request and returns a response with status code 200 if successful, or 400 if unsuccessful.


        :param self: Represent the instance of the object itself
        :param request: Get the request object
            :argument query_params dictionary request parameters
                :argument products_list string(list of integers) list of products
        :param *args: Send a non-keyworded variable length argument list to the function
        :param **kwargs: Pass keyworded, variable-length argument list to a function
        :return: A list of products that are similar to the ones in the request
        """
        try:
            products_ids = list(map(int, request.query_params.get('products_list', None).split(',')))
            data_products_ids = products_ids
            categories_ids = Product.objects \
                .filter(id__in=products_ids) \
                .values_list("category", flat=True)
            queryset = Product.objects \
                .filter(category__id__in=categories_ids, on_delete=False) \
                .order_by("-status", "-relevance_index")
        except Exception as e:
            queryset = Product.objects.filter(on_delete=False).order_by("-status", "-relevance_index")
            categories_ids = Product.objects.all() \
                .values_list("category", flat=True)
            products_ids = []
            data_products_ids = []

        if len(queryset) < 12:
            queryset2 = Product.objects.all() \
                            .exclude(id__in=list(queryset.values_list("id", flat=True))) \
                            .order_by("-status", '-relevance_index')[:12 - len(queryset)]
            queryset = Product.objects.filter(id__in=list(queryset.values_list("id", flat=True)) + list(
                queryset2.values_list("id", flat=True))).order_by("-status", '-relevance_index')

        # TODO: rework recommendations for complications
        first_elements, queryset = queryset[:3], queryset[3:]
        values_list = list(set(ProductProperties.objects \
                               .filter(product__id__in=products_ids) \
                               .values_list("value", flat=True)))
        part_one_elements = list(ProductProperties.objects \
                                 .filter(product__in=list(queryset), value__in=values_list) \
                                 .values_list("product", flat=True))
        part_two_elements = list(first_elements.values_list("id", flat=True))
        products_ids = list(set(part_one_elements + part_two_elements))
        products = Product.objects \
            .filter(id__in=products_ids) \
            .union(Product.objects \
                   .filter(category__id__in=categories_ids, on_delete=False) \
                   .exclude(id__in=products_ids + data_products_ids)
                   .order_by("-relevance_index")[:12 - len(products_ids)]) \
            .order_by("-relevance_index")
        return Response(MinimizeProductSerializer(products, many=True).data, status=status.HTTP_200_OK)
