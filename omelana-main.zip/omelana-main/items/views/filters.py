import math

from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from django.db.models import Count, Max
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response

from category.models import Category, CategoryProperties
from items.models import Product, ProductProperties
from items.serializers import MinimizeProductSerializer


class ProductsFilter(APIView):
    # counts_page - counts items in page.
    # page - number of pages
    # price_start - price start
    # price_end - price end
    # order_by - order
    # category - product category

    def get(self, request, *args, **kwargs):
        """
        The get function is used to retrieve a list of products from the database.
        The function takes in two parameters: request and format. The request parameter
        is used to get information about the current HTTP Request, such as GET or POST data.
        The format parameter is used for determining what kind of response should be returned,
        such as JSON or XML.

        :param self: Represent the instance of the object itself
        :param request: Get the request object
            :argument query_params dictionary request parameters
                :argument category integer id of the category
                :argument ?page integer number of the page
                :argument ?counts_page integer number of items per page
                :argument ?price_start integer price start
                :argument ?price_end integer price end
                :argument ?order_by string name of the field to order by
        :param *args: Send a non-keyworded variable length argument list to the function
        :param **kwargs: Pass keyworded, variable-length argument list to a function
        :return: A list of products that are in the category with the specified id
        """
        try:
            category_id = int(request.query_params.get('category', "d"))
            category = Category.objects.get(id=category_id)
            queryset = Product.objects.filter(category=category)
        except Exception as e:
            return Response(status=status.HTTP_400_BAD_REQUEST)
        prices = [math.ceil(element.get_price()) for element in queryset]
        prices.sort()
        if len(queryset):
            min_price = prices[0]
            max_price = prices[-1]
        else:
            min_price = 0
            max_price = 0
        page = int(request.query_params.get('page', 1))
        counts_page = int(request.query_params.get('counts_page', 15))  # TODO: load with db count
        price_start = int(request.query_params.get('price_start', 0))
        price_end = request.query_params.get('price_end', None)
        order_by = request.query_params.get('order_by', None)

        if price_start:
            prices_products_ids = []

            for product in queryset:
                product_price = product.get_price()
                if price_start <= product_price:
                    prices_products_ids.append(product.id)
            queryset = queryset.filter(id__in=prices_products_ids)
        if price_end:
            price_end = int(price_end)
            prices_products_ids = []

            for product in queryset:
                product_price = product.get_price()
                if product_price <= price_end:
                    prices_products_ids.append(product.id)
            queryset = queryset.filter(id__in=prices_products_ids)


        set_id_products = set(queryset.values_list("id", flat=True))

        list_properties_id = CategoryProperties.objects\
            .filter(category=category)\
            .values_list("id", flat=True)
        list_valid_properties_id = []
        for key in request.query_params.keys():
            if key.isdigit() and int(key) in list_properties_id:
                list_valid_properties_id.append(int(key))
        for filter_id in list_valid_properties_id:
            set_id_products = set_id_products.intersection(
                set(ProductProperties.objects
                    .filter(properties__pk=filter_id,
                            value__in=request.query_params.get(str(filter_id)).split(","))
                    .values_list("product", flat=True))
            )

        queryset = queryset.filter(id__in=list(set_id_products))
        if order_by:
            queryset = queryset.order_by("id", "-status", order_by)
        else:
            queryset = queryset.order_by("id", "-status")

        paginator = Paginator(queryset, counts_page)

        max_page = paginator.num_pages


        try:
            products = paginator.page(page)
        except PageNotAnInteger:
            products = paginator.page(1)
        except EmptyPage:
            products = paginator.page(max_page)

        return Response({"products": MinimizeProductSerializer(products, many=True).data, "filters": {
            "maxPage": max_page,
            "minPrice": int(min_price),
            "maxPrice": int(max_price)
        }}, status=status.HTTP_200_OK)


class FilterView(APIView):
    # TODO: Uncomment decorator caching
    # @method_decorator(cache_page(60 * 60 * 12))
    def get(self, request, *args, **kwargs):
        """
        The get function is used to get the filter shop for a specific category.
            The function takes in a request and returns the filter shop of that category.


        :param self: Represent the instance of the object itself
        :param request: Get the request from the client
            :argument query_params dictionary request parameters
                :argument category integer id of the category
        :param *args: Send a non-keyworded variable length argument list to the function
        :param **kwargs: Pass keyworded, variable-length argument list to a function
        :return: A list of objects, each object has a name and values
        """
        try:
            category_id = int(request.query_params.get('category', "d"))
            category = Category.objects.get(id=category_id)
            queryset_category_products = CategoryProperties.objects.filter(category=category)
        except Exception as e:
            return Response(status=status.HTTP_400_BAD_REQUEST)
        filter_shop = []
        for category_product in queryset_category_products:
            filter_shop.append({
                "id": category_product.id,
                "name": category_product.title,
                "values": ProductProperties.objects.filter(properties=category_product)
                    .values('value')
                    .annotate(count=Count('value'))
                    .order_by()
            })
        return Response(filter_shop, status=status.HTTP_200_OK)
