from rest_framework import serializers
from .models import Product, ProductProperties, ProductImage
from category.serializers import CategoryChoicesSerializer


class ImagesProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductImage
        fields = ['id', 'product', 'image', 'sequence']


class ProductPropertySerializer(serializers.ModelSerializer):
    title = serializers.ReadOnlyField(source='properties.title')
    category_properties = CategoryChoicesSerializer(source='properties')

    class Meta:
        model = ProductProperties
        fields = ("id", 'title', 'value', 'category_properties')


class MinimizeProductSerializer(serializers.ModelSerializer):
    image = serializers.SerializerMethodField()

    class Meta:
        model = Product
        fields = ["id", "price", "image", "sale", "status", "on_delete", "start_sale", "end_sale", "title"]

    def get_image(self, obj):
        image_product = ProductImage.objects.filter(product__in=[obj.id, ]).order_by("sequence")[:1]
        image_product = ImagesProductSerializer(image_product[0]).data if len(image_product) else None
        return image_product


class ProductSerializer(serializers.ModelSerializer):
    properties = ProductPropertySerializer(source='product_set', many=True, read_only=True)
    images = ImagesProductSerializer(source='product_image_set', many=True, read_only=True)

    class Meta:
        model = Product
        fields = ['id', "category", 'images', 'price', 'sale', 'status', 'on_delete', 'start_sale', 'end_sale', 'title',
                  'description', 'properties']


class TableProductsSerializer(serializers.ModelSerializer):
    category = serializers.SerializerMethodField()

    class Meta:
        model = Product
        fields = ['id', 'title', 'category', 'price', 'status', 'modify', 'on_delete']

    def get_category(self, obj):
        if not obj.category:
            return "Не має"
        else:
            return obj.category.title
