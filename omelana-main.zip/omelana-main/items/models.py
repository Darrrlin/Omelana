from django.utils import timezone

from django.core.validators import MinValueValidator, MaxValueValidator
from django.db import models

from category.models import Category, CategoryProperties


class Product(models.Model):
    category = models.ForeignKey(Category, on_delete=models.SET_NULL, blank=True, null=True)
    title = models.CharField(max_length=250)
    description = models.TextField(max_length=500, null=True, blank=True, default=None)
    price = models.FloatField(validators=[MinValueValidator(0.0), ])
    sale = models.SmallIntegerField(validators=[MinValueValidator(0), MaxValueValidator(100)], blank=True, null=True,
                                    default=None)
    status = models.BooleanField(default=True)
    start_sale = models.DateTimeField(blank=True, null=True, default=None)
    end_sale = models.DateTimeField(blank=True, null=True, default=None)
    modify = models.DateTimeField(auto_now=True)
    created = models.DateTimeField(auto_now_add=True)
    on_delete = models.BooleanField(default=False)
    relevance_index = models.FloatField(default=0)

    def save(self, *args, **kwargs):
        """
        The save function is called when the model instance is saved.
        The save function rounds the price to two decimal places and then saves it.

        :param self: Refer to the current instance of a class
        :param *args: Send a non-keyworded variable length argument list to the function
        :param **kwargs: Pass keyworded, variable-length argument list to a function
        :return: The object itself
        """
        self.price = round(self.price, 2)
        super(Product, self).save(*args, **kwargs)

    def is_on_sale(self):
        """
        The is_on_sale function returns True if the product is currently on sale.
        It uses the start_sale and end_sale fields to determine this.

        :param self: Refer to the object itself
        :return: True if the start_sale and end_sale fields are set
        """
        today = timezone.now()
        return self.start_sale and self.end_sale and self.start_sale < today < self.end_sale

    def get_price(self):
        """
        The get_price function returns the price of a product.
        If the product is on sale, it will return the discounted price.

        :param self: Represent the instance of the class
        :return: The price of the product
        """
        if self.is_on_sale():
            return self.price - self.price / 100 * self.sale
        return self.price

    def __str__(self):
        """
        The __str__ function is the default human-readable representation of the object.
        This means that if you print an object, or convert it to a string for display,
        this function will be called. It should return a string.

        :param self: Represent the instance of the class
        :return: The title of the product
        """
        return self.title

    class Meta:
        db_table = "products"


class ProductProperties(models.Model):
    properties = models.ForeignKey(CategoryProperties, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='product_set')
    value = models.TextField(max_length=500)

    class Meta:
        db_table = "products_properties"


class ProductImage(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='product_image_set')
    image = models.FileField(upload_to='products')
    sequence = models.PositiveSmallIntegerField(default=5)
    created = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "products_images"
