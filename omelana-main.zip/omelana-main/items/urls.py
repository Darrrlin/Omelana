from django.urls import path
from .views import ProductsFilter, FilterView, ProductsListView, RecommendationProductsView, ChangeProductView, \
    ProductsTableView

urlpatterns = [
    path('filter-elements', ProductsFilter.as_view()),
    path('filter', FilterView.as_view()),
    path('recommendation', RecommendationProductsView.as_view()),
    path('elements', ProductsListView.as_view()),
    path('admin/elements', ProductsTableView.as_view()),
    path('admin/element', ChangeProductView.as_view()),
]
