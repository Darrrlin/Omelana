import os

from omelana.settings import BASE_DIR

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [os.path.join(BASE_DIR, 'frontend/templates')],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

LOGGING_ADD_TEMPLATE = 'User with "id":{id} add new item to "model":{model} with "id":{item}'
LOGGING_DELETE_TEMPLATE = 'User with "id":{id} delete item to "model":{model} with "id":{item}'
LOGGING_COPPY_TEMPLATE = 'User with "id":{id} copy item to "model":{model} from "id":{from_id} to "id":{item}'
LOGGING_CHANGE_TEMPLATE = 'User with "id":{id} changed item to "model":{model} with "id":{item}'
