DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': "omelana",
        'HOST': 'localhost',
        'PORT': '3306',
        'USER': 'root',
        'PASSWORD': '',
    }
}
