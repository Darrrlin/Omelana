CORS_ORIGIN_ALLOW_ALL = True
CORS_ORIGIN_WHITELIST = [
    'http://localhost:3000',  # the domain for front-end app(you can add more than 1)
    'http://localhost:8000'
]

CORS_ALLOW_CREDENTIALS = True