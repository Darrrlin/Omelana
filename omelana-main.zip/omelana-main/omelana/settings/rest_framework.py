REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': (
        'oauth.authenticate.ModifyAuthentication',
    )
}