from datetime import datetime


def json_date_to_datetime(date: str):
    format_date_time = "%Y-%m-%d"
    return datetime.strptime(date, format_date_time)
