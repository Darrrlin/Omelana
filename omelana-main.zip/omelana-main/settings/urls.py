from django.urls import path
from .views import *


urlpatterns = [
    path('settingslist/', SettingsList.as_view()),
    path('settingscategorylist/', SettingsCategoryList.as_view()),
    path('gettitle/<int:pk>', SettingTitle.as_view()),
    path('getValues/<int:pk>',SettingValues.as_view()),
    path('getValues/',SettingValues.as_view()),
    path('changeSetting/',ChangeSettings.as_view())

]
