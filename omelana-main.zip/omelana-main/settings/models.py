from django.db import models


class CategorySetting(models.Model):
    title = models.CharField(max_length=250)
    created = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "settings_categories"

    def __str__(self):
        return self.title


class Setting(models.Model):
    category_setting = models.ForeignKey(CategorySetting, on_delete=models.CASCADE)
    title = models.CharField(max_length=250)
    value = models.TextField(max_length=500)
    value_file = models.FileField(upload_to='setting', blank=True, null=True)
    modify = models.DateTimeField(auto_now=True)
    created = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "settings"

    def __str__(self):
        return self.title
