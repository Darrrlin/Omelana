from django.shortcuts import render
from rest_framework import generics, viewsets, status
from .serializers import *
from .models import *
import rest_framework.views

class SettingsList(generics.ListCreateAPIView):
    queryset = Setting.objects.all()
    serializer_class = SettingsSerializer


class SettingsCategoryList(generics.ListCreateAPIView):
    queryset = CategorySetting.objects.all()
    serializer_class = CategoriesSettingsSerializer


class SettingTitle(generics.RetrieveAPIView):
    queryset = Setting.objects.all()
    serializer_class = SettingTitleSerializer
    

class SettingValues(generics.RetrieveAPIView):
    queryset = CategorySetting.objects.all()
    serializer_class = SettingValuesSerializer

class ChangeSettings(rest_framework.views.APIView):
    def post(self, request, *args, **kwargs):
        try:
            category = request.data.get('category', None)
            type_method = request.data.get('type_method',None)
            if type_method == 'get':
                data = Setting.objects.filter(category_setting__title=category)
                return Response(SettingsSerializer(data, many=True).data, status=status.HTTP_200_OK)
            elif type_method == 'update':
                
                data = request.data.get('data', None)

                value_file = request.data.get('value_file', None)
                if category=='Deliveries and payments':
                    Setting.objects.filter(category_setting__title=category).delete()
                    for elem in data.split('=|=')[0:-1]:
                        deliverySetting = Setting()
                        deliverySetting.title='value'
                        deliverySetting.category_setting_id=CategorySetting.objects.get(title=category).id
                        deliverySetting.value = elem[0:-5]
                        deliverySetting.save()
                    return Response(status=status.HTTP_200_OK)
                elif category == 'Main':
                    data = request.data.get('value', None)
                    value_file = request.FILES.get('value_file',None)
                    title = request.data.get('title', None)
                    set1 = Setting.objects.get(title=title)
                    set1.value = data
                    if(value_file!=None):
                        set1.value_file = value_file
                    set1.save()
                    return Response(status=status.HTTP_200_OK)
                else:
                    Setting.objects.filter(category_setting__title=category).delete()
                    for i in data.split('|')[0:-1]:
                        print(i.split(','))
                        setting = Setting()
                        setting.category_setting_id=CategorySetting.objects.get(title=category).id
                        setting.title = i.split(',')[0]
                        setting.value = i.split(',')[1]
                        if value_file != None:
                            setting.value_file = i.split(',')[2]
                        setting.save()
                    return Response(status=status.HTTP_200_OK)
                    


            
        except Exception as e:
            print(e)
            return Response(status=status.HTTP_400_BAD_REQUEST)