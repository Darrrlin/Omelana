from corsheaders.conf import Settings
from rest_framework.response import Response
from settings.models import *
from rest_framework import serializers, static, status


class CategoriesSettingsSerializer(serializers.ModelSerializer):
    class Meta:
        model = CategorySetting
        fields = '__all__'


    def get_settings(self, category):
        objects = Setting.objects.filter(category_setting=category)
        serialized_settings = SettingsSerializer(objects, many=True)
        return serialized_settings.data


class SettingsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Setting
        fields = '__all__'



class SettingTitleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Setting
        fields = ['title']

    def get(self, pk):
        title = CategorySetting.objects.get(pk=pk)
        if title:
            serialized_title = SettingTitleSerializer(title).data
            return Response(serialized_title, status=status.HTTP_200_OK)
        return Response(None, status=status.HTTP_404_NOT_FOUND)


class SettingValuesSerializer(serializers.ModelSerializer):
    values = serializers.SerializerMethodField('get_values_by_category')
    class Meta:
        model = CategorySetting
        fields = ['values']

    def get_values_by_category(self, pk):
        values = Setting.objects.filter(category_setting__title=pk)
        return SettingsSerializer(values, many=True).data