from django.contrib.auth.models import update_last_login

from rest_framework.exceptions import AuthenticationFailed
from rest_framework_simplejwt.serializers import TokenObtainSerializer
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.settings import api_settings


class TokenObtainPairSerializer(TokenObtainSerializer):
    token_class = RefreshToken

    def validate(self, attrs):
        super().validate(attrs)

        if not self.user.is_staff:
            raise AuthenticationFailed(
                self.error_messages["no_active_account"],
                "no_active_account",
            )

        token = self.get_token(self.user)
        data = {"refresh": str(token), "access": str(token.access_token)}

        if api_settings.UPDATE_LAST_LOGIN:
            update_last_login(None, self.user)

        return data

    def get_token(self, user):
        token = self.token_class.for_user(user)
        token["username"] = user.username
        token["is_superuser"] = user.is_superuser
        return token
