from rest_framework_simplejwt.authentication import JWTAuthentication

from rest_framework.authentication import CSRFCheck
from rest_framework import exceptions
from rest_framework_simplejwt.token_blacklist.models import OutstandingToken, BlacklistedToken


def enforce_csrf(request):
    def dummy_get_response(request):
        return None

    check = CSRFCheck(dummy_get_response)
    check.process_request(request)
    reason = check.process_view(request, None, (), {})
    if reason:
        raise exceptions.PermissionDenied('CSRF Failed: %s' % reason)


class ModifyAuthentication(JWTAuthentication):
    def authenticate(self, request):
        header = self.get_header(request)
        if header is None:
            return None

        raw_token = self.get_raw_token(header)
        if raw_token is None:
            return None

        validated_token = self.get_validated_token(raw_token)

        enforce_csrf(request)

        return self.get_user(validated_token), validated_token


def disabled_all_token_user(user_id: int):
    tokens = OutstandingToken.objects.filter(user_id=user_id)
    for token in tokens:
        t, _ = BlacklistedToken.objects.get_or_create(token=token)

    return True
