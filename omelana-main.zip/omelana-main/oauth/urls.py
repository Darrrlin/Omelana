from django.urls import path
from .views import (
    LoginView,
    RefreshToken,
    LogoutAllView,
    LogoutView,
    ChangePasswordView
)

urlpatterns = [
    path('login/', LoginView.as_view()),
    path('logout/', LogoutView.as_view()),
    path('logout-all/', LogoutAllView.as_view()),
    path('login/refresh/', RefreshToken.as_view()),
    path('change-password/', ChangePasswordView.as_view()),
]
