import re

from django.contrib.auth.models import User
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.serializers import TokenRefreshSerializer
from rest_framework_simplejwt.tokens import RefreshToken as RefreshTokenDefault

from rest_framework_simplejwt.views import TokenViewBase
from rest_framework_simplejwt.exceptions import TokenError, InvalidToken

from django.middleware import csrf

from oauth.authenticate import disabled_all_token_user
from oauth.serializers import TokenObtainPairSerializer
from omelana import settings


class LoginView(TokenViewBase):
    serializer_class = TokenObtainPairSerializer

    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)

        try:
            serializer.is_valid(raise_exception=True)
        except TokenError as e:
            raise InvalidToken(e.args[0])

        response = Response()

        data_full = serializer.validated_data

        response.set_cookie(
            key=settings.SIMPLE_JWT['AUTH_COOKIE'],
            value=data_full["refresh"],
            expires=settings.SIMPLE_JWT['REFRESH_TOKEN_LIFETIME'],
            secure=settings.SIMPLE_JWT['AUTH_COOKIE_SECURE'],
            httponly=settings.SIMPLE_JWT['AUTH_COOKIE_HTTP_ONLY'],
            samesite=settings.SIMPLE_JWT['AUTH_COOKIE_SAMESITE']
        )
        csrf.get_token(request)
        response.data = {'access': data_full["access"]}
        response.status_code = status.HTTP_200_OK
        return response


class RefreshToken(TokenViewBase):
    serializer_class = TokenRefreshSerializer

    def post(self, request, *args, **kwargs):
        refresh_token = request.COOKIES.get(settings.SIMPLE_JWT['AUTH_COOKIE']) or None

        if not refresh_token:
            return Response({"error": "Admin not authenticated"}, status=status.HTTP_401_UNAUTHORIZED)

        serializer = self.get_serializer(data={"refresh": refresh_token})
        try:
            serializer.is_valid(raise_exception=True)
        except TokenError as e:
            raise InvalidToken(e.args[0])

        return Response(serializer.validated_data, status=status.HTTP_200_OK)


class LogoutView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request):
        try:
            refresh_token = request.COOKIES.get(settings.SIMPLE_JWT['AUTH_COOKIE']) or None

            if not refresh_token:
                return Response({"error": "User not authenticated"}, status=status.HTTP_401_UNAUTHORIZED)

            token = RefreshTokenDefault(refresh_token)
            token.blacklist()

            response = Response()
            response.delete_cookie(settings.SIMPLE_JWT['AUTH_COOKIE'])
            response.status_code = status.HTTP_205_RESET_CONTENT

            return response
        except Exception as e:
            return Response(status=status.HTTP_400_BAD_REQUEST)


class LogoutAllView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request):
        try:
            disabled_all_token_user(request.user.id)

            response = Response()
            response.delete_cookie(settings.SIMPLE_JWT['AUTH_COOKIE'])
            response.status_code = status.HTTP_205_RESET_CONTENT

            return response
        except Exception as e:
            return Response(status=status.HTTP_400_BAD_REQUEST)


class ChangePasswordView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request):
        try:
            new_password = request.data.get('newPassword', "")
            if (not request.user.check_password(request.data.get('oldPassword', "")) or
                    not re.fullmatch(r'^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])[A-Za-z0-9]{8,}',
                                     new_password)):
                return Response(status=status.HTTP_423_LOCKED)

            user = User.objects.get(id=request.user.id)
            user.set_password(new_password)
            user.save()

            disabled_all_token_user(request.user.id)

            response = Response()
            response.delete_cookie(settings.SIMPLE_JWT['AUTH_COOKIE'])
            response.status_code = status.HTTP_205_RESET_CONTENT

            return response
        except Exception as e:
            return Response(status=status.HTTP_400_BAD_REQUEST)
