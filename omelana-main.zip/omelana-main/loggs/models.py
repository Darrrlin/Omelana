from django.db import models


class Logs(models.Model):
    table = models.CharField(max_length=150)
    id_element = models.PositiveSmallIntegerField()
    title = models.CharField(max_length=250)
    description = models.TextField(max_length=500, null=True, blank=True, default=None)
    created = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "logging_operations"

    def __str__(self):
        """
        The __str__ function is the default human-readable representation of the object.
        This means that if you print an object, or convert it to a string for display,
        this function will be called. It should return a string.

        :param self: Represent the instance of the class
        :return: The title of the logging
        """
        return self.title
