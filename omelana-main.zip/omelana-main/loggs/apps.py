from django.apps import AppConfig


class LoggsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'loggs'
