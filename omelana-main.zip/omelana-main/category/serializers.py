from rest_framework import serializers
from category.models import Category, CategoryProperties, PropertiesChoices
from items.models import Product



class ChoicesSerializer(serializers.ModelSerializer):
    class Meta:
        model = PropertiesChoices
        fields = ['id', 'title', ]


class CategoryChoicesSerializer(serializers.ModelSerializer):
    properties_choices = serializers.SerializerMethodField()

    class Meta:
        model = CategoryProperties
        fields = ['id', 'title', 'properties_choices']

    def get_properties_choices(self, obj):
        properties_choices_query = PropertiesChoices.objects.filter(
            properties_id=obj.id)
        serializer = ChoicesSerializer(properties_choices_query, many=True)

        return serializer.data


class CategoryFullSerializer(serializers.ModelSerializer):
    properties = serializers.SerializerMethodField()
    count = serializers.SerializerMethodField()

    class Meta:
        model = Category
        fields = ['id', 'title', 'description', 'img_src', 'properties', 'count']

    def get_properties(self, obj):
        properties_query = CategoryProperties.objects.filter(
            category_id=obj.id)
        serializer = CategoryChoicesSerializer(properties_query, many=True)
        return serializer.data
    
    def get_count(self, obj):
            item_query = Product.objects.filter(category=obj)
            return len(item_query)


class CategorySerializer(serializers.ModelSerializer):
    count = serializers.SerializerMethodField()

    class Meta:
        model = Category
        fields = ['id', 'title', 'created', 'count']

    def get_count(self, obj):
            item_query = Product.objects.filter(category=obj)
            return len(item_query)

    