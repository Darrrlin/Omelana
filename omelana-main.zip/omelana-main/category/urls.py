from django.urls import path

from category.views import ChangeCategoryView, ListCategoryView

urlpatterns = [
    path('admin/elements', ListCategoryView.as_view()),
    path('admin/element', ChangeCategoryView.as_view()),
]
