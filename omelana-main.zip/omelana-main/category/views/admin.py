import json

from django.db.models import Q
from django.forms import model_to_dict
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from rest_framework.response import Response

from category.models import Category, CategoryProperties, PropertiesChoices
from category.serializers import CategoryFullSerializer, CategorySerializer
from items.models import ProductProperties, Product
from oauth.authenticate import ModifyAuthentication
from omelana.settings import LOGGING_CHANGE_TEMPLATE, LOGGING_COPPY_TEMPLATE, LOGGING_DELETE_TEMPLATE, \
    LOGGING_ADD_TEMPLATE, DEFAULT_PROPERTY_VALUES_NONE
from loggs.models import Logs


class ChangeCategoryView(APIView):
    authentication_classes = [ModifyAuthentication]
    permission_classes = (IsAuthenticated,)

    def get(self, request, *args, **kwargs):
        """
        The get function is used to retrieve a single category object from the database.
        It takes in an id parameter, which is used to find the correct category object.
        If no such object exists, it returns a 404 error code.

        :param self: Represent the instance of the object
        :param request: Pass the http request that triggered this view
            :argument query_params dictionary data request parameters
                :argument id integer id of the category
        :param *args: Send a non-keyworded variable length argument list to the function
        :param **kwargs: Pass keyworded, variable-length argument list to a function
        :return: A response object with the data of a categoryfullserializer
        """
        try:
            category_id = int(request.query_params.get('id', None))
            category = Category.objects.get(id=category_id)
            serializer = CategoryFullSerializer(category)
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Exception as e:
            return Response(status=status.HTTP_404_NOT_FOUND)

    def create(self, request, *args, **kwargs):
        """
        The create function is used to create a new category.

        :param self: Represent the instance of the object itself
        :param request: Get the data from the request body
             :argument data dictionary request parameters
                :argument title string category name
                :argument description string category description
                :argument is_new_image boolean indicating if the image of the category should be changed
                :argument properties !(string(JSON)) | list of dictionaries containing the properties of the category
                    :argument title string name category property
                    :argument description string description of the category property
                    :argument values list of strings containing the values of the category property
            :argument FILES dictionary request files
                :argument image file containing the image of the category
        :param *args: Send a non-keyworded variable length argument list to the function
        :param **kwargs: Pass keyworded, variable-length argument list to a function
        :return: A response object, which is a json object that contains the data you want to return
        """
        try:
            title = request.data.get('title')
            description = request.data.get('description')
            properties = request.data.get('properties')
            is_new_image = request.data.get('is_new_image', None)
            if is_new_image:
                image = request.FILES.get('image')
                properties = json.loads(properties)
            else:
                image = None
            category = Category.objects.create(title=title, description=description, img_src=image)
            for property in properties:
                property_title = property['title']
                property_description = property['description']
                property_values = property['values'] if type(property['values']) == list \
                    else property['values'].split(',')
                category_properties = CategoryProperties.objects.create(
                    category=category,
                    title=property_title,
                    description=property_description
                )
                PropertiesChoices.objects.bulk_create([
                    PropertiesChoices(properties=category_properties, title=property_value)
                    for property_value in property_values
                ])
                category_properties.save()
            Logs.objects.create(
                table='categories',
                id_element=category.id,
                title="CREATE",
                description=LOGGING_ADD_TEMPLATE.format(id=self.request.user, model="Category", item=category.id)
            )
            category.save()
            return Response({"id": category.id}, status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response(status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, *args, **kwargs):
        """
        The delete function is used to delete a category.
            It takes in the request and format as parameters.
            The function first tries to get the id of the category from the request data, if it exists, then it gets that category object from Category model using its id.
            Then all products with that particular category are updated by setting their categories to None (i.e., no categories).
            Next, all properties associated with this particular category are deleted using ProductProperties model and CategoryProperties model respectively.

        :param self: Represent the instance of the object itself
        :param request: Get the data from the request
            :argument data dictionary request parameters
                :argument id integer id of the category
        :param *args: Send a non-keyworded variable length argument list to the function
        :param **kwargs: Pass keyworded, variable-length argument list to a function
        :return: A response with a status code of 204
        """
        try:
            category_id = [int(x) for x in request.query_params.get('id', None).split(',')]
            category = Category.objects.filter(id__in=category_id)
            Product.objects.filter(category__in=category).update(category=None)
            category_properties = CategoryProperties.objects.filter(category__in=category)
            ProductProperties.objects.filter(properties__in=list(category_properties)).delete()
            category.delete()
            Logs.objects.bulk_create([
                Logs(
                    table='categories',
                    id_element=x,
                    title="DELETE",
                    description=LOGGING_DELETE_TEMPLATE.format(id=self.request.user, model="Category",
                                                               item=x)
                )
                for x in category_id
            ])
            return Response(status=status.HTTP_204_NO_CONTENT)
        except Exception as e:
            return Response(status=status.HTTP_404_NOT_FOUND)

    def put(self, request, *args, **kwargs):  # copy
        """
        The put function is used to copy a category.
            The function takes the id of the category to be copied and creates a new instance of that category with all its properties and choices.


        :param self: Represent the instance of the object
        :param request: Get the data from the request object
            :argument data dictionary request parameters
                :argument id integer id of the category
        :param *args: Send a non-keyworded variable length argument list to the function
        :param **kwargs: Pass keyworded, variable-length argument list to a function
        :return: A 201 response, which means that the object was created
        """
        try:
            category_id = int(request.query_params.get('id', None))
            instance = Category.objects.get(id=category_id)
            kwargs = model_to_dict(instance, exclude=["modify", "id", "created"])
            category = Category.objects.create(**kwargs)
            category.img_src = instance.img_src
            for category_property_old in CategoryProperties.objects.filter(category=instance):
                category_property_new = CategoryProperties.objects.create(
                    category=category,
                    title=category_property_old.title,
                    description=category_property_old.description
                )
                PropertiesChoices.objects.bulk_create([
                    PropertiesChoices(properties=category_property_new, title=property_choice.title)
                    for property_choice in PropertiesChoices.objects.filter(properties=category_property_old)
                ])
                category_property_new.save()
            category.save()
            Logs.objects.create(
                table='categories',
                id_element=category_id,
                title="COPY",
                description=LOGGING_COPPY_TEMPLATE.format(
                    id=self.request.user,
                    model="Category",
                    from_id=category_id,
                    item=category.id
                )
            )
            return Response(CategoryFullSerializer(category).data, status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response(status=status.HTTP_404_NOT_FOUND)

    def update(self, request, *args, **kwargs):
        """
        The update function is used to update a category.
            It takes the following parameters:
                - id (int): The id of the category to be updated.
                - title (str): The new title of the category.
                - description (str): The new description of the category.

        :param self: Represent the instance of the object
        :param request: Get the data from the request object
            :argument data dictionary request parameters
                :argument id integer id of the category
                :argument title string new title of the category
                :argument description string new description of the category
                :argument is_new_image boolean indicating if the image of the category should be changed
                :argument properties list of dictionary new properties of the category
                    :argument title string new title of the category property
                    :argument description string new description of the category property
                    :argument values string new values of the category property
            :argument FILES dictionary request files
                :argument image file containing the image of the category
        :param *args: Send a non-keyworded variable length argument list to the function
        :param **kwargs: Pass keyworded, variable-length argument list to a function
        :return: A 204 status code, which means that the request was successful but no content is returned
        """
        try:
            category_id = int(request.data.get('id', None))
            category = Category.objects.get(id=category_id)
            title = request.data.get('title')
            description = request.data.get('description')
            properties = request.data.get('properties')
            is_new_image = request.data.get('is_new_image', None)
            if is_new_image:
                image = request.FILES.get('image', None)
                category.img_src = image
            properties = json.loads(properties)
            category.title = title
            category.description = description

            category.save()
            dict_ids = {}
            dict_titles = {}
            for i in range(len(properties)):
                property = properties[i]
                if "id" in property:
                    dict_ids[int(property["id"])] = i
                else:
                    dict_titles[property["title"]] = i
            category_properties = CategoryProperties.objects.filter(category=category)


            removed_list_index = []

            for category_property in category_properties:
                if category_property.id in dict_ids:
                    element_id = dict_ids[category_property.id]
                    del dict_ids[category_property.id]
                elif category_property.title in dict_titles:
                    element_id = dict_titles[category_property.title]
                    del dict_titles[category_property.title]
                else:
                    category_property.delete()
                    continue
                element = properties[element_id]
                element["values"] = element["values"] if type(element["values"]) == list \
                    else element["values"].split(',')
                category_property.title = element["title"]
                category_property.description = element["description"]
                property_choices = PropertiesChoices.objects.filter(properties=category_property)
                for property_choice in property_choices:
                    if property_choice.title not in element["values"]:
                        ProductProperties.objects \
                            .filter(value=property_choice.title, properties=category_property) \
                            .update(
                            value=element["values"][0] if len(element["values"]) > 0 else DEFAULT_PROPERTY_VALUES_NONE)
                        property_choice.delete()
                    else:
                        element["values"].remove(property_choice.title)
                PropertiesChoices.objects.bulk_create([
                    PropertiesChoices(properties=category_property, title=value)
                    for value in element["values"]
                ])
                category_property.save()
                removed_list_index.append(element_id)
            for element_id in sorted(removed_list_index, reverse=True):
                del properties[element_id]

            for property in properties:
                property_title = property['title']
                property_description = property['description']
                property_values = property["values"] if type(property["values"]) == list \
                    else property["values"].split(',')
                category_properties = CategoryProperties.objects.create(
                    category=category,
                    title=property_title,
                    description=property_description
                )
                PropertiesChoices.objects.bulk_create([
                    PropertiesChoices(properties=category_properties, title=property_value)
                    for property_value in property_values
                ])
                ProductProperties.objects.bulk_create([
                    ProductProperties(
                        properties=category_properties,
                        product=product,
                        value=property_values[0] if len(property_values) > 0 else DEFAULT_PROPERTY_VALUES_NONE)
                    for product in Product.objects.filter(category=category)
                ])
                category_properties.save()

            Logs.objects.create(
                table='categories',
                id_element=category.id,
                title="UPDATE",
                description=LOGGING_CHANGE_TEMPLATE.format(id=self.request.user, model="Category", item=category.id)
            )
            return Response(status=status.HTTP_204_NO_CONTENT)
        except Exception as e:
            return Response(status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, *args, **kwargs):
        """
        The post function is used to create and update objects.
            The type_methods parameter determines which method will be called.
            If the type_methods parameter is &quot;CREATE&quot;, then the create function will be called, otherwise if it's &quot;UPDATE&quot; then the update function will be called.

        :param self: Represent the instance of the class
        :param request: Get the data from the client
            :argument data dictionary request data
                :argument type_methods string type request method
        :param *args: Send a non-keyworded variable length argument list to the function
        :param **kwargs: Pass keyworded, variable-length argument list to a function
        :return: A response object
        """
        type_methods = request.data.get("type_methods", None)
        if type_methods == "CREATE":
            return self.create(request, *args, **kwargs)
        elif type_methods == "UPDATE":
            return self.update(request, *args, **kwargs)
        return Response(status=status.HTTP_400_BAD_REQUEST)


class ListCategoryView(APIView):
    authentication_classes = [ModifyAuthentication]
    permission_classes = (IsAuthenticated,)

    def get(self, request, *args, **kwargs):
        """
        The get function is used to retrieve all categories from the database.
        The function takes in a request parameter, which is used to determine what type of response should be returned.
        If the request parameter 'type' has a value of "short", then only basic information about each category will be returned.
        If the request parameter 'type' has a value of "full", then detailed information about each category will be returned.

        :param self: Represent the instance of the object itself
        :param request: Get the request object
            :argument query_params dictionary request parameters
                :argument type string type of response to be returned
        :param *args: Send a non-keyworded variable length argument list to the function
        :param **kwargs: Pass keyworded, variable-length argument list to a function
        :return: The serialized data of the categories, with a status code 200
        """
        type_request = request.query_params.get('type', "short")
        categories = Category.objects.filter()

        if type_request == "short":
            serialized_category = CategorySerializer
        elif type_request == "full":
            serialized_category = CategoryFullSerializer
        else:
            return Response(status=status.HTTP_400_BAD_REQUEST)
        return Response(serialized_category(categories, many=True).data, status=status.HTTP_200_OK)
