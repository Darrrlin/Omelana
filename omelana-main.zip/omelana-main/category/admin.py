from django.contrib import admin
from .models import Category, CategoryProperties, PropertiesChoices


admin.site.register(Category)
admin.site.register(CategoryProperties)
admin.site.register(PropertiesChoices)
