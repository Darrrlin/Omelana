from django.core.validators import MinValueValidator, MaxValueValidator
from django.db import models


class Category(models.Model):
    title = models.CharField(max_length=250)
    description = models.TextField(max_length=500, null=True, blank=True, default=None)
    img_src = models.FileField(upload_to='category', blank=True, null=True)
    modify = models.DateTimeField(auto_now=True)
    created = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "categories"

    def __str__(self):
        """
        The __str__ function is the default human-readable representation of the object.
        This means that if you print an object, or convert it to a string for display,
        this function will be called. It should return a string.

        :param self: Represent the instance of the class
        :return: The title of the category
        """
        return self.title


class CategoryProperties(models.Model):
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name="category_properties_set")
    title = models.CharField(max_length=100)
    description = models.TextField(max_length=300, null=True, blank=True, default=None)

    class Meta:
        db_table = "category_properties"
    def __str__(self):
        """
        The __str__ function is the default human-readable representation of the object.
        This means that if you print an object, or convert it to a string for display,
        this function will be called. It should return a string.

        :param self: Represent the instance of the class
        :return: The title of the category properties
        """
        return self.title


class PropertiesChoices(models.Model):
    properties = models.ForeignKey(CategoryProperties, on_delete=models.CASCADE, related_name="properties_choices_set")
    title = models.CharField(max_length=100)

    class Meta:
        db_table = "property_choices"

    def __str__(self):
        """
        The __str__ function is the default human-readable representation of the object.
        This means that if you print an object, or convert it to a string for display,
        this function will be called. It should return a string.

        :param self: Represent the instance of the class
        :return: The title of the properties choices
        """
        return self.title
