from django.urls import path
from statistic import views


urlpatterns = [
    path('statiscticlist/', views.StatiscticView.as_view()),
    path('currentmonthstatisctic/', views.CurrentMonthStatistic.as_view()),
    path('topsum/',views.TopSales.as_view()),
    path('findbydate/', views.DateFilterStatistic.as_view()),
    path('topcustomers/',views.CustomersStatistic.as_view())
]
