from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator, MinLengthValidator
import datetime
from category.models import Category


class MonthlyEarnings(models.Model):
    month = models.SmallIntegerField(
        validators=[MinValueValidator(1),
                    MaxValueValidator(12)],
        default=datetime.datetime.now().month,
    )
    year = models.SmallIntegerField(
        validators=[MinValueValidator(1),
                    MaxValueValidator(31)],
        default=datetime.datetime.now().year,
    )


class CategoryEarnings(models.Model):
    category = models.CharField(max_length=250)
    month = models.ForeignKey(MonthlyEarnings, on_delete=models.SET_NULL, blank=True, null=True)
    earning = models.FloatField(
                    null=True, blank=True,
                    validators=[MinValueValidator(0.0), ]
    )
    count = models.SmallIntegerField(MinValueValidator(0))



