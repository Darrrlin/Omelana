from rest_framework.response import Response
from category.serializers import CategorySerializer
from statistic.models import *
from rest_framework import serializers, static, status
from django.db.models import Sum, Count
import datetime
from orders.models import *
from orders.serializers import OrdersSerializer
import json
from datetime import datetime
from category.models import *
from django.db.models import Q