from rest_framework.response import Response
from category.serializers import CategorySerializer
from statistic.models import *
from rest_framework import serializers, static, status
from django.db.models import Sum, Count
import datetime
from orders.models import *
from orders.serializers import OrdersSerializer
import json
from datetime import datetime
from category.models import *
from django.db.models import Q

'''
Months_statistic[
    month[
        earnings,
        count,
        ]
    ]
Current_month_statistic"[
    month,
    aboutmonths[
        category,
        earnings
        ],
    ]
relevantitems[
    category,
    product,
    rel_index
    ],
categories_statistics[
    category,
    earnings,
    orderscounts,
    topthreeitems[
        title,
        count,
        earning
        ]
    ],
topcustomers[
    name,
    number,
    mail,
    sum,
    orderscount
    ]
]

'''

'''
    Creating a result in ResultSerializer
    consist of several views wrote in 12-th line
    first two views responds first SerializerMethodField
'''  # TODO:Made all fields


# TODO:Take values from online and offline payments


class SimpleCategorySerializer(CategorySerializer):
    class Meta:
        model = CategoryEarnings
        fields = '__all__'


class CurrentMonthStatisticSerializer(serializers.ModelSerializer):
    month = serializers.SerializerMethodField('get_categories_statistics')

    class Meta:
        model = MonthlyEarnings
        fields = '__all__'

    def get_categories_statistics(self, request):
        categoryearning = CategoryEarnings.objects.filter(month__month=datetime.today().month,
                                                          month__year=datetime.today().year)
        if not categoryearning:
            MonthlyEarningsSerializer.create()
            categoryearning = CategoryEarnings.objects.filter(month__month=datetime.today().month,
                                                              month__year=datetime.today().year)
        return SimpleCategorySerializer(categoryearning, many=True).data


class MonthlyEarningsSerializer(serializers.ModelSerializer):
    month1 = serializers.SerializerMethodField('get_categories_statistics')

    class Meta:
        model = MonthlyEarnings
        fields = '__all__'

    def get_categories_statistics(self, monthlyearnings):
        objects1 = CategoryEarnings.objects.filter(month__id=monthlyearnings.id)
        return SimpleCategorySerializer(objects1, many=True).data

    def create(self, data):
        """
        The create function is used to create a new instance of the MonthlyEarnings model.
        It takes in data from the request and creates an object with that data. It then saves it to the database.

        :param self: Represent the instance of the object itself
        :param data: Pass the data to be serialized
        :return: A monthlyearnings object
        :doc-author: Trelent
        """
        CategoryEarnings.objects.all().delete()
        MonthlyEarnings.objects.all().delete()
        object1 = MonthlyEarnings.objects.filter(month=datetime.today().month,
                                                 year=datetime.today().year).first()
        if not object1:
            object1 = MonthlyEarnings(month=datetime.today().month, year=datetime.today().year)
        object1.save()
        orders = Order.objects.filter(created__month=datetime.today().month,
                                      created__year=datetime.today().year)
        for order in orders:
            orderitems = OrderItem.objects.filter(order=order) \
                .values('title_category') \
                .annotate(sum=Sum('price')) \
                .annotate(count=Count('title_category')) \
                .order_by()

            bulk_list = []
            for item in orderitems:
                bulk_list.append(
                    CategoryEarnings(
                        month=MonthlyEarnings.objects.get(month=datetime.today().month, year=datetime.today().year),
                        category=item['title_category'],
                        earning=item['sum'],
                        count=item['count']
                    )
                )
            CategoryEarnings.objects.bulk_create(bulk_list)
            return object1


class CustomersSerializer(serializers.ModelSerializer):
    sum = serializers.IntegerField(required=False)
    email = serializers.EmailField(source="Order.email")

    class Meta:
        model = Order
        fields = ['email', 'first_name', 'second_name', 'sur_name', 'phone_number', 'sum']
