from rest_framework import serializers
from orders.models import *


class DateFilterSerializer(serializers.ModelSerializer):
    startDate = serializers.DateTimeField(write_only=True)
    endDate = serializers.DateTimeField(write_only=True)

    class Meta:
        model = Order
        fields = '__all__'

class ProductDateFilterSerializer(serializers.ModelSerializer):
    startDate = serializers.DateTimeField(write_only=True)
    endDate = serializers.DateTimeField(write_only=True)

    class Meta:
        model = OrderItem
        fields = '__all__'



