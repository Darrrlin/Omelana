from rest_framework import generics
from orders.serializers import OrderItemSerializer
from statistic.serializers.serializers import *
from .models import *
from .serializers.dateFilter import *
from statistic.serializers.serializers import *
from statistic.serializers.dateFilter import *

class StatiscticView(generics.ListCreateAPIView):
    serializer_class = MonthlyEarningsSerializer
    queryset = MonthlyEarnings.objects.all()


class CurrentMonthStatistic(generics.ListAPIView):
    serializer_class = CurrentMonthStatisticSerializer
    queryset = MonthlyEarnings.objects.all()


class DateFilterStatistic(generics.ListAPIView):
    serializer_class = DateFilterSerializer
    queryset = Order.objects.all()

    def get(self, request):
        startDate = request.query_params.get('startDate', "")
        endDate = request.query_params.get('endDate', "")
        orderitems = OrderItem.objects.filter(order__created__lte=endDate).\
            filter(order__created__gte=startDate) \
            .values('order',
                    'title_category',
                    'order__first_name',
                    'order__email',
                    'order__second_name',
                    'order__sur_name',
                    'order__type_payment',
                    'order__phone_number') \
            .annotate(sum=Sum('price')) \
            .annotate(count=Count('title_category')) \
            .order_by()
        response = {
            'totalSum':0,
            'count': 0,
            'categories':[]
        }
        for order in orderitems:
            response['totalSum'] += order['sum']
            response['count'] += order['count']
            response['categories'].append(order)

        return Response(response, status=status.HTTP_200_OK)


class CustomersStatistic(generics.ListAPIView):
    serializer_class = OrderItemSerializer
    queryset = OrderItem.objects.all()

    def get(self, request):
        orders = OrderItem.objects.all() \
            .values(
            'order__email',
            'order__second_name',
            'order__sur_name',
            'order__first_name',
            'order__phone_number'
                    ) \
            .annotate(sum=Sum('price')) \
            .order_by()
        response = []
        for order in orders:
            response.append(
                {
                    'email': order['order__email'],
                    'name': order['order__first_name'],
                    'sur_name': order['order__sur_name'],
                    'phone_number': order['order__phone_number'],
                    'totalSum': order['sum'],
                    'count': len(Order.objects.annotate(
                        count=Count('id', filter=Q(phone_number=order['order__phone_number'],)))
                    )

                }
            )
        return Response(response, status=status.HTTP_200_OK)


class TopSales(generics.ListAPIView):
    serializer_class = ProductDateFilterSerializer
    queryset = OrderItem.objects.all()

    def get(self, request):
        startDate = request.query_params.get('startDate', "")
        endDate = request.query_params.get('endDate', "")
        order_items_sum = OrderItem.objects.filter(order__created__lte=endDate).\
            filter(order__created__gte=startDate) \
            .values('title_product')\
            .annotate(sum=Sum('price')) \
            .annotate(count=Count('title_product')) \
            .order_by('-sum')[:10]
        order_items_count = OrderItem.objects.filter(order__created__lte=endDate). \
                            filter(order__created__gte=startDate) \
                            .values('title_product') \
                            .annotate(sum=Sum('price')) \
                            .annotate(count=Count('title_product')) \
                            .order_by('-count')[:10]

        response = {
            'topSum':order_items_sum,
            'topCount':order_items_count
        }
        return Response(response, status=status.HTTP_200_OK)
