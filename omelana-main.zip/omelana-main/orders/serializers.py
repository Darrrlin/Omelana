from rest_framework import serializers, status
from category.models import Category
from orders.models import Order, OrderItem
from items.models import Product
from rest_framework.response import Response


class OrderItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = OrderItem
        fields = '__all__'

    def get(self,request, pk):
        """
    The get function is used to retrieve a single order item from the database.
        It takes in an id and returns the corresponding order item.

    :param self: Represent the instance of the object itself
    :param request: Pass the request object to the view
    :param pk: Get the primary key of the item that we want to update
    :return: The data of the order item with the given pk
    """
        try:
            item = OrderItem.objects.get(pk=pk)
            return Response(OrderItemSerializer(item).data, status=status.HTTP_200_OK)
        except Exception as e:
            return Response(serializers.ErrorDetail ,status=status.HTTP_400_BAD_REQUEST)


class OrdersSerializer(serializers.ModelSerializer):
    items = serializers.SerializerMethodField('get_order_items')
    items_list = serializers.CharField(write_only=True)

    class Meta:
        model = Order
        fields = '__all__'

    def get(self,request, pk):
        """
    The get function is used to retrieve all orders from the database.
        It returns a list of all orders in the database, and their associated information.

    :param self: Represent the instance of the object itself
    :param request: Pass the request object to the view
    :param pk: Get the primary key of a specific order
    :return: A list of all the orders
    """
        orders = Order.objects.all()
        serialized_orders = OrdersSerializer(orders, many=True)
        return Response(serialized_orders.data, status=status.HTTP_200_OK)

    def get_order_items(self, order):
        """
        The get_order_items function is a helper function that returns the order items for an order.
        It takes in an Order object and returns a list of serialized OrderItem objects.

        :param self: Refer to the class itself
        :param order: Filter the orderitem objects by order
        :return: A list of order items
        """
        objects = OrderItem.objects.filter(order=order)
        return OrderItemSerializer(objects, many=True).data

    def validate(self, data):
        """
        The validate function is called by the serializer's .is_valid() method.
        It receives a dictionary of validated data and either returns that same
        dictionary, or raises a ValidationError if any validation failed.

        :param self: Represent the instance of the object
        :param data: Get the data from the request
        :return: A dictionary of validated data
        """
        try:
            if len(data['email']) < 5:
                raise serializers.ValidationError('Email address is too short')
            if len(data['first_name']) < 2:
                raise serializers.ValidationError('Name is too short')
            if len(data['address']) < 5:
                raise serializers.ValidationError('Address is too short')
            if len(data['phone_number']) < 9:
                raise serializers.ValidationError('Phone number is too short')
            items_list = str(data['items_list'])[0:-1].split(',')
            for item in items_list:
                current_product = Product.objects.get(id=item)
                if not current_product:
                    raise serializers.ValidationError('Product is not exists')
        except Exception as exc:
            print(exc)
            raise serializers.ValidationError(str(exc)+' ' + str(data['items_list']))
        return data

    def create(self, validated_data):
        """
    The create function is used to create a new instance of the model
        that this serializer is bound to.

    :param self: Represent the instance of the object itself
    :param validated_data: Get the data from the request
    :return: An order object, which contains all the data about the order
    """
        try:
            order = Order()
            order.email = validated_data.pop('email')
            order.first_name = validated_data.pop('first_name')
            order.second_name = validated_data.pop('second_name')
            order.sur_name = validated_data.pop('sur_name')
            order.status = 1
            order.address = validated_data.pop('address')
            order.type_payment = validated_data.pop('type_payment')
            order.phone_number = validated_data.pop('phone_number')
            order.save()
            items_list = str(validated_data.pop('items_list'))[0:-1].split(',')
            for item in items_list:
                current_product = Product.objects.get(pk=item)
                order_item = OrderItem()
                order_item.order = order
                order_item.product = current_product
                order_item.category = current_product.category
                order_item.title_product = Product.objects.get(pk=item).title
                order_item.title_category = current_product.category.title
                order_item.price = current_product.get_price()
                order_item.save()
            return order
        except Exception as e:
            return Response(str(e), status=status.HTTP_400_BAD_REQUEST)






