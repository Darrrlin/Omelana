import json

import rest_framework.views
from django.db.migrations import serializer
from django.shortcuts import render
from rest_framework import generics, viewsets, status
from .serializers import *
from .models import Order
from rest_framework.response import Response
from orders.models import Order, OrderItem
from items.models import Product
from category.models import Category


class OrderView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Order.objects.all()
    serializer_class = OrdersSerializer
    items_list = serializers.IntegerField()


class OrdersList(generics.ListCreateAPIView):
    queryset = Order.objects.all()
    serializer_class = OrdersSerializer


class OrderItemsList(generics.ListCreateAPIView):
    queryset = OrderItem.objects.all()
    serializer_class = OrderItemSerializer


class OrderItemView(generics.RetrieveUpdateDestroyAPIView):
    queryset = OrderItem.objects.all()
    serializer_class = OrderItemSerializer

class OrderUpdater(rest_framework.views.APIView):
    def post(self, request, *args, **kwargs):
        try:
            type_method = request.data.get('type_method', None)
            ids = []
            if request.data.get('ids').find(',') == -1:
                ids = [request.data.get('ids'), ]
            else:
                ids = [int(x) for x in request.data.get('ids').split(",")]
            values = Order.objects.filter(id__in=ids)
            
            if type_method == 'setReading':
                for post in values:
                    post.status = 1
            if type_method == 'setComplete':
                for post in values:
                    post.status = 3
            if type_method == 'setProces':
                for post in values:
                    post.status = 2
            if type_method == 'setRemoved':
                for post in values:
                    post.status = 0
            Order.objects.bulk_update(values, ["status"])
            return Response(status=status.HTTP_200_OK)
        except Exception as e:
            return Response(status=status.HTTP_400_BAD_REQUEST)



