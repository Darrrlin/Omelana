from django.urls import path
from orders import views

urlpatterns = [
    path('orderslist/', views.OrdersList.as_view()),
    path('orderlist/<int:pk>', views.OrderView.as_view()),
    path('orderitemslist/', views.OrderItemsList.as_view()),
    path('orderitemlist/<int:pk>', views.OrderItemView.as_view()),
    path('orderupdate/', views.OrderUpdater.as_view())

]
