from django.core.validators import MinValueValidator, MaxValueValidator, MinLengthValidator
from django.db import models

from category.models import Category
from items.models import Product


class Order(models.Model):
    REMOVED = 0
    REGISTER = 1
    PROCESSED = 2
    COMPLETED = 3
    STATUS_CHOICES = (
        (REGISTER, 'Placing an order'),
        (PROCESSED, 'Order processed'),
        (COMPLETED, 'Order completed'),
    )

    ONLINE = 1
    MADE = 2
    TYPE_PAYMENTS_CHOICES = (
        (ONLINE, 'Payment online'),
        (MADE, 'Payment made')
    )

    email = models.EmailField(max_length=254)
    first_name = models.CharField(max_length=70)
    second_name = models.CharField(max_length=80)
    sur_name = models.CharField(max_length=70, blank=True, null=True)
    status = models.SmallIntegerField(
        validators=[MinValueValidator(0),
                    MaxValueValidator(3)],
        choices=STATUS_CHOICES,
        default=REGISTER,
    )
    address = models.TextField(max_length=500)
    type_payment = models.SmallIntegerField(
        validators=[MinValueValidator(1),
                    MaxValueValidator(2)],
        choices=TYPE_PAYMENTS_CHOICES
    )
    phone_number = models.CharField(max_length=12, validators=[MinLengthValidator(10)])

    modify = models.DateTimeField(auto_now=True)
    created = models.DateTimeField(auto_now_add=True)

    def is_register(self):
        return self.status == self.REGISTER

    def is_processed(self):
        return self.status == self.PROCESSED

    def is_completed(self):
        return self.status == self.COMPLETED

    def is_online_payment(self):
        return self.type_payment == self.ONLINE

    def is_made_payment(self):
        return self.type_payment == self.MADE

    class Meta:
        db_table = "orders"


class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.SET_NULL, blank=True, null=True)
    category = models.ForeignKey(Category, on_delete=models.SET_NULL, blank=True, null=True)
    title_product = models.CharField(max_length=250)
    title_category = models.CharField(max_length=250)
    price = models.FloatField(validators=[MinValueValidator(0.0), ])
    created = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "order_items"

    def __str__(self):
        return self.title_product
