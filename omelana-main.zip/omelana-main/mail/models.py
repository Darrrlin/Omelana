from django.db import models

from orders.models import Order


class Mail(models.Model):
    order = models.ForeignKey(Order, on_delete=models.SET_NULL, blank=True, null=True)
    title = models.CharField(max_length=250)
    description = models.TextField(max_length=500, null=True, blank=True, default=None)
    created = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "emails"

    def __str__(self):
        return self.title
