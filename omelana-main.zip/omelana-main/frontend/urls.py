from django.urls import path
from .views import admin, product, category, order, delivery_and_payment, contacts, data_privacy_rules, user_agreement, \
    main

urlpatterns = [
    path('admin/<first_chunk>/<second_chunk>/<third_chunk>/<fourth_chunk>/', admin),
    path('admin/<first_chunk>/<second_chunk>/<third_chunk>/<fourth_chunk>', admin),
    path('admin/<first_chunk>/<second_chunk>/<third_chunk>/', admin),
    path('admin/<first_chunk>/<second_chunk>/<third_chunk>', admin),
    path('admin/<first_chunk>/<second_chunk>/', admin),
    path('admin/<first_chunk>/<second_chunk>', admin),
    path('admin/<first_chunk>/', admin),
    path('admin/<first_chunk>', admin),
    path('admin/', admin),
    path('products/<int:pk>/', product),
    path('products/<int:pk>', product),
    path('category/<int:pk>/', category),
    path('category/<int:pk>', category),
    path('order/', order),
    path('order', order),
    path('delivery-and-payment/', delivery_and_payment),
    path('delivery-and-payment', delivery_and_payment),
    path('contacts/', contacts),
    path('contacts', contacts),
    path('data-privacy-rules/', data_privacy_rules),
    path('data-privacy-rules', data_privacy_rules),
    path('user-agreement/', user_agreement),
    path('user-agreement', user_agreement),
    path('', main)
]
