from django.http import HttpResponse, Http404
from django.shortcuts import render
from category.models import Category
from items.models import Product, ProductImage, ProductProperties
from settings.models import CategorySetting, Setting


def get_header(pk, type_url="none") -> dict:
    category_list = Category.objects.all()   
    phones_list = Setting.objects.all().filter(category_setting_id__id=4)
    phones=[d.value for d in phones_list if d.title == 'number']
    active_category_name = ""
    active_link = pk
    if type(pk) == int:
        if type_url == 'category':
            category_object = category_list.get(pk=pk)
            active_category_name = category_object.title
        else:
            products = Product.objects.get(pk=pk)
            active_category_name = products.category.title
            active_link = products.category.pk
    data = {
        "category_list": category_list,
        "active_category_name": active_category_name,
        "active_link": active_link,
        "phone": phones
    }
    # header_data:dict -
    #     category_list:list
    #     active_link:int|str
    #     active_category_name:string
    #     phone:string
    # TODO: work with settings
    return data


def get_footer() -> dict:
    # footer_data
    #     email: str,
    #     instagram: FileField,
    #     facebook: FileField,
    #     viber: FileField,
    #     telegram: FileField,
    # TODO: work with settings
    try:
        values = Setting.objects.all().filter(category_setting_id__id=4)
        footer_data={
            'email': [d.value for d in values if d.title == 'gmail'][0],
            'instagram': [d.value for d in values if d.title == 'instagram'][0],
            'facebook': [d.value for d in values if d.title == 'facebook'][0],
            'viber': [d.value for d in values if d.title == 'viber'][0],
            'telegram': [d.value for d in values if d.title == 'telegram'][0],
            'phone':[d.value for d in values if d.title == 'number'],
        }
    except Exception as e:
        footer_data = {
            'email': "test@example.com",
            'instagram': "https://example.com",
            'facebook': "https://example.com",
            'viber': "https://example.com",
            'telegram': "https://example.com",
            'phone': "+380000000000",
        }
    return footer_data


def admin(request, *args, **kwargs) -> HttpResponse:
    return render(request, "admin/index.html")


def main(request, *args, **kwargs) -> HttpResponse:
    values = Setting.objects.filter(category_setting__title='Main')
    print(values)
    data = {
        'main_photo':{
            'url':values[0].value_file
        },
        "main_text": {
            "value": values[0].value
        },
        'description_photo': {
            'url': values[1].value_file
        },
        "description_text": {
            "value": values[1].value
            }
    }
    # data: dict
    #     main - photo: FileField,
    #     main - text: SettingsModel,
    #     description_photo: FileField,
    #     description_text: SettingsModel
    # TODO: work with settings
    return render(request, "home.page/index.html",
                  {"header_data": get_header(""), "footer_data": get_footer(), "data": data})


def product(request, pk, *args, **kwargs) -> HttpResponse:
    try:
        product_object = Product.objects.get(pk=pk)
    except Product.DoesNotExist:
        raise Http404()

    images = ProductImage.objects.filter(product=product_object).order_by('sequence')
    properties = ProductProperties.objects.filter(product=product_object)
    discount = False
    price = product_object.price
    if product_object.is_on_sale():
        discount = product_object.get_price()

    data = {
        "title": product_object.title,
        "description": product_object.description,
        "is_read_more": len(product_object.description) > 500,
        "pk": pk,
        "images": images,
        "discount": discount,
        "price": price,
        "is_deleted": product_object.on_delete,
        "properties": properties,
    }
    return render(request, "products.pages/product.html",
                  {"header_data": get_header(pk, "product"), "footer_data": get_footer(), "data": data})


def category(request, pk, *args, **kwargs) -> HttpResponse:
    data = {}
    try:
        category_object = Category.objects.get(pk=pk)
    except Category.DoesNotExist:
        raise Http404()

    return render(request, "products.pages/products.list.html",
                  {"header_data": get_header(pk, "category"), "footer_data": get_footer(), "data": data})


def order(request, *args, **kwargs) -> HttpResponse:
    return render(request, "orders.page/confirm.order.html")


def delivery_and_payment(request, *args, **kwargs) -> HttpResponse:
    return render(request, "delivery-and-payment.page/index.html",
                  {"header_data": get_header("delivery"), "footer_data": get_footer()})

def contacts(request, *args, **kwargs) -> HttpResponse:
    values = Setting.objects.all().filter(category_setting_id__id=4)
    data={
        'phone_title':[d.value for d in values if d.title == 'number title'][0],
        'phones':[d.value for d in values if d.title == 'number'],
        'mail_title':[d.value for d in values if d.title == 'gmail title'][0],
        'mail':[d.value for d in values if d.title == 'gmail'][0],
        'messanger_title':[d.value for d in values if d.title == 'messanger title'][0],
        'viber':[d.value for d in values if d.title == 'viber'][0],
        'telegram':[d.value for d in values if d.title == 'telegram'][0],
        'social_title':[d.value for d in values if d.title == 'social title'][0],
        'instagram':[d.value for d in values if d.title == 'instagram'][0],
        'facebook':[d.value for d in values if d.title == 'facebook'][0]
    }
    return render(request, "contacts/index.html",
                  {"header_data": get_header("contacts"), "footer_data": get_footer(),'data':data})


def data_privacy_rules(request, *args, **kwargs) -> HttpResponse:
    
    values = Setting.objects.all().filter(category_setting_id__id=2)
    data = {
        "title": values[0].value,
        "page_description": "",
        "page_keywords": "",
        "page_canonical_url": "/data-privacy-rules/",
        # TODO: work with settings
        "text": values[1].value
    }

    return render(request, "agreement/agreement.html",
                  {"header_data": get_header(""), "footer_data": get_footer(), "data": data})


def user_agreement(request, *args, **kwargs) -> HttpResponse:
    values = Setting.objects.all().filter(category_setting_id__id=3)
    data = {
        "title": values[0].value,
        "page_description": "",
        "page_keywords": "",
        "page_canonical_url": "/user-agreement/",
        # TODO: work with settings
        "text": values[1].value
    }

    return render(request, "agreement/agreement.html",
                  {"header_data": get_header(""), "footer_data": get_footer(), "data": data})
