import React from "react";
import { createRoot } from 'react-dom/client';
import setupStore from "./components/uttils/strore/initializeStore";
import {Provider} from "react-redux";
import {App} from "./components/App"

const store = setupStore();
const appDiv  = document.getElementById("app");
const root = createRoot(appDiv);
root.render(
    <Provider store={store}>
        <App/>
    </Provider>
);