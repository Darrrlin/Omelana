import React, {useEffect} from "react";
import axios from "axios";
import {useDispatch} from "react-redux";
import {ThemeProvider} from "@mui/material";
import {setCredential} from "./processes/auth";
import {Router} from "./processes/routing";
import {configApi} from "./uttils/api/config";
import {theme} from "./config/deisgn/mui.config";

export function App() {
    const dispatch = useDispatch()

    useEffect(() => {
        axios({
            method: 'POST',
            url: configApi.baseUrl + configApi.tokenInfo.urlRefresh,
            data: {}
        })
            .then(response => {
                dispatch(setCredential(response.data));
            })
            .catch(error => {
                // code error
            });
    }, []);
    return (
        <ThemeProvider theme={theme}>
            <Router />
        </ThemeProvider>
    )
}