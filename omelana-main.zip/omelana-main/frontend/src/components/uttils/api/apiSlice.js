import {createApi, fetchBaseQuery} from "@reduxjs/toolkit/query/react";
import {setCredential, logOut} from "../../processes/auth";
import {configApi} from "./config";
import axios from "axios";

const baseQuery = fetchBaseQuery({
    baseUrl: configApi.baseUrl,
    credentials: "include",
    prepareHeaders: (headers, {getState}) => {
        if (configApi.tokenInfo) {
            const token = getState().auth[configApi.tokenInfo.name];
            if (token) {
                const csrfToken = document.cookie.split("; ").find(element => element.startsWith('csrftoken=')).split("csrftoken=")[1];
                headers.set('X-CSRFToken', csrfToken);
                headers.set("authorization", `${configApi.tokenInfo.nameBearer}${token}`);
            }
        }
        return headers
    }
})

const baseQueryWithReAuth = async (args, api, extraOptions) => {
    let result = await baseQuery(args, api, extraOptions);
    if (result?.error?.status === 403 || result?.error?.status === 401) {
        try {
            const refreshResult = await axios({
                method: 'POST',
                url: configApi.baseUrl + configApi.tokenInfo.urlRefresh,
                data: {}
            });


            api.dispatch(setCredential(({...refreshResult.data})))

            result = await baseQuery(args, api, extraOptions)
        } catch (err) {
            api.dispatch(logOut());
        }
    }
    return result;
}

export const apiSlice = createApi({
    baseQuery: baseQueryWithReAuth,
    endpoints: builder => ({})
})