export const configApi= {
    baseUrl: "/api/",
    tokenInfo: {
        name: "accessToken",
        nameBearer: "Bearer ",
        localNameRefreshToken: "refreshTokenTNPU",
        localNameAccessToken: "refreshTokenTNPU",
        urlRefresh: "auth/login/refresh/"
    }
};