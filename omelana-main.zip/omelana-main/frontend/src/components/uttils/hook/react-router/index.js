import {useContext, useEffect, useState} from 'react';
import {UNSAFE_NavigationContext as NavigationContext} from 'react-router-dom';

const useConfirmExit = (cb, when = true, confirmed) => {
    const {navigator} = useContext(NavigationContext);
    const [pathname, setPathname] = useState("");

    useEffect(() => {
        if (!when) {
            return;
        }

        const push = navigator.push;

        if (!confirmed) {
            navigator.push = (...args) => {
                if (!pathname) {
                    const [location] = args;
                    setPathname(`${location.pathname}${location.search}`);
                    cb();
                }
            };
        }

        return () => {
            navigator.push = push;
        }
    }, [pathname, when, confirmed]);

    return {pathname, setPathname};
}

export const useNavigationBlocker = (when = true, confirmed) => {
    const [isOpenModal, setIsOpenModal] = useState(false);

    useEffect(() => {
        if (when) {
            window.onbeforeunload = () => {
                return '';
            }
        }

        return () => {
            window.onbeforeunload = null;
        };
    }, [when]);

    const cb = () => setIsOpenModal(true);

    const {pathname, setPathname} = useConfirmExit(cb, when, confirmed);

    return { isOpenModal, setIsOpenModal, pathname, setPathname };
}

export default useNavigationBlocker;