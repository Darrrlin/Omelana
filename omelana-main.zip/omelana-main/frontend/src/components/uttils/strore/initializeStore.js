import {configureStore} from "@reduxjs/toolkit";
import {standardReducers as initializeReducers, middlewareList} from "./config";

const setupStore = () => {
    let store = configureStore({
        reducer: initializeReducers,
        middleware: getDefaultMiddleware => getDefaultMiddleware().concat(middlewareList),
        devTools: false
    });

    store.asyncReducers = {};
    store.injectReducer = (key, reducer) => {
        store.asyncReducers[key] = reducer;
        store.replaceReducer({...initializeReducers, ...store.asyncReducers});
        return store;
    };

    return store;
};

export default setupStore;