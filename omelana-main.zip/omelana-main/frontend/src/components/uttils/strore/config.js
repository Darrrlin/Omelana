import {AuthSlice, AuthApiSlice} from "../../processes/auth";
import {combineReducers} from "redux";


export const standardReducers = combineReducers({
    "auth": AuthSlice.reducer,
    [AuthApiSlice.reducerPath]: AuthApiSlice.reducer
})

export const middlewareList = [
    AuthApiSlice.middleware
];
