import React from 'react';

const Index = ({text}) => {
    return (
        <div>
            {text}
        </div>
    );
};

export default Index;