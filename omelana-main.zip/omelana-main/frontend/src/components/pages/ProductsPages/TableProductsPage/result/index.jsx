import React, {useEffect, useState} from 'react';
import Table from "../../../../ui/tables/orderTable";
import '../css';
import CopyImage from '../../../../media/images/copy-icon.png';
import EditImage from '../../../../media/images/edit-icon.png';
import DeleteImage from '../../../../media/images/delete-icon.png';
import TitleTablePage from "../../../../ui/TitleTablePage";
import InputSearch from "../../../../ui/Inputs/InputSearch";
import SelectUI from "../../../../ui/selects/SelectUI";
import MoreIcons from "../../../../ui/icons/MoreIcons";
import FilterIcon from "../../../../ui/icons/FilterIcon";
import ElementsFilterSearchMobileWidget from "../../../../widgets/ElementsFilterSearchMobileWidget";
import {MobileContextMenu} from "../../../../widgets/MobileContextMenu";
import {Pagination} from "../../../../ui/pagintaion";
import LeftArrowIcon from "../../../../ui/icons/LeftArrowIcon";
import {useNavigate} from "react-router-dom";
import {defaultPrevUrl} from "../../../../processes/routing";
import {
    useAddSaleProductsMutation,
    useChangeStatusProductsMutation,
    useCopyProductMutation,
    useGetProductsMutation,
    useRemoveProductsMutation
} from "../../../../processes/product"
import {useGetCategoriesMutation} from "../../../../processes/category";
import AddDiscount from "../../../../widgets/AddDiscount";
import {ModalCheckSaveWidget} from "../../../../widgets/ModalCheckSaveWidget";

const stateProductList = ["В наявності", "Немає в наявності", "Видалений"];

const TableProductsPage = ({openMenu}) => {
    // [<SelectButton 'Назва товару', 'Категорія', 'Ціна', 'Статус', 'Дата редагування']
    const [head, setHead] = useState({
        isSelectAll: false,
        optionsHeader: [
            {title: "Назва товару", keyData: "name", width: "19.3vw", widthTablet: "23.82vw", widthMobile: ""},
            {title: "Категорія", keyData: "category", width: "12.77vw", widthTablet: "15.88vw", widthMobile: ""},
            {title: "Ціна", keyData: "price", width: "6.66vw", widthTablet: "6.64vw", widthMobile: ""},
            {title: "Статус", keyData: "status", width: "12.77vw", widthTablet: "15.88vw", widthMobile: ""},
            {title: "Дата редагування", keyData: "date", width: "10.06vw", widthTablet: "16.53vw", widthMobile: ""},
        ]
    });

    const [isModal, setIsModal] = useState(false);
    const [isTimeLine, setIsTimeLine] = useState(false);
    const [discountPrice, changeDiscountPrice] = useState(0);
    const [firstTimeLine, setFirstTimeline] = useState("");
    const [secondTimeLine, setSecondTimeLine] = useState("");
    const [categoryProductList, setCategoryProductList] = useState([]);
    const [removeProducts, {isLoadingRemoveProducts}] = useRemoveProductsMutation();
    const [changeStatusProducts, {isLoadingChangeStatusProducts}] = useChangeStatusProductsMutation();
    const [addSaleProducts, {isLoadingAddSaleProducts}] = useAddSaleProductsMutation();
    const [copyProductApi, {isLoadingCopyProduct}] = useCopyProductMutation();


    const [getProducts, {isLoaded}] = useGetProductsMutation();
    const [getCategories, {isLoading}] = useGetCategoriesMutation();

    let underDataButtons = [
        {
            action: (e, index) => copyProduct(index),
            color: '#0064E5',
            iconSrc: CopyImage,
            iconStyle: {'width': '24px', 'height': '24px'},
            title: "Копіювати"
        },
        {
            action: (e, index) => removeProduct(index),
            color: '#EB5757',
            iconSrc: DeleteImage,
            iconStyle: {'width': '24px', 'height': '24px'},
            title: "Видалити"
        },
        {
            action: (e, index) => editProduct(index),
            color: '#51B960',
            iconSrc: EditImage,
            iconStyle: {'width': '24px', 'height': '24px'},
            title: "Редагувати"
        }
    ];


    const categoryLoad = async () => {
        const requestDataCategories = await getCategories().unwrap();
        setCategoryProductList(requestDataCategories.map((_val, _index) => ({id: _val.id, text: _val.title})));
    }

    const dataLoad = async (request) => {
        const requestData = await getProducts(request).unwrap();
        let result = [];
        requestData.data.map((value, index) => {
            result.push({
                isSelected: false,
                id: value["id"],
                name: value['title'],
                category: value['category'],
                price: value['price'],
                statusData: value['status'],
                status: value['on_delete'] == true ? "delete" : value['status'] == true ? "is" : "not-is",
                date: value['modify'].split('T')[0]
            })
        })

        setMaxPage(parseInt(requestData.countsPage));
        setData(result);
        setListSelected([]);
        setHead({...head, isSelectAll: false});
    }

    const [data, setData] = useState([]);

    const [listSelected, setListSelected] = useState([]);
    const [isOpenContextMenu, setIsOpenContextMenu] = useState(-1);
    const [globalContextMenu, setGlobalContextMenu] = useState(false);

    const [page, setPage] = useState(1);
    const [maxPage, setMaxPage] = useState(1);
    const [isOpenMobileFilter, setIsOpenMobileFilter] = useState(false);
    const [filterData, setFilterData] = useState({
        search: "",
        otherFilter: [-1, -1]
    });
    const navigate = useNavigate();

    const selectAll = () => {
        let customData = data.map((element, index) => {
            return {...element, isSelected: !head.isSelectAll}
        });

        if (!head.isSelectAll) {
            setListSelected(data.map((_val, _index) => _index));
        } else {
            setListSelected([])
        }

        setData([...customData]);
        setHead({...head, isSelectAll: !head.isSelectAll})

    }

    const removeProduct = async (index) => {
        await removeProducts(data[index].id).unwrap();
        setData([...data.map((element, _index) => {
            if (index === _index) {
                return {
                    ...element,
                    status: element.status !== "delete" ? "delete" : element.statusData === true ? "is" : "not-is"
                };
            }
            return {...element}
        })]);

    }

    const copyProduct = async (index) => {
        const response = await copyProductApi(data[index].id).unwrap();
        setData([...data, {...data[index], id: response.id}])
    }

    const editProduct = (index) => {
        return navigate(defaultPrevUrl + `products/${data[index].id}/`);
    }

    const actionSearch = (page, filterDataResponse) => {
        const filterDataTemp = filterDataResponse ? filterDataResponse : filterData;
        let optionData = {page: page ? page : 1};
        if (filterDataTemp.search !== "") {
            optionData.search = filterDataTemp.search;
        }
        if (filterDataTemp.otherFilter[0] !== -1) {
            optionData.category = categoryProductList[filterDataTemp.otherFilter[0]].id
        }

        if (filterDataTemp.otherFilter[1] !== -1) {
            if (filterDataTemp.otherFilter[1] === 0) {
                optionData["order_by"] = "-status"
            } else if (filterDataTemp.otherFilter[1] === 1) {
                optionData["order_by"] = "status"
            } else {
                optionData["order_by"] = "-on_delete"
            }
        }
        dataLoad(optionData);
        setPage(optionData.page);
    }

    const addDiscount = () => {
        setIsModal(true);
    }

    const setStatusNotIs = async () => {
        let selectedTempElements = []
        setData([...data.map((element, index) => {
            if (element.isSelected) {
                selectedTempElements.push(element.id);
                return {
                    ...element,
                    status: element.status === "is" ? "not-is" : element.status === "not-is" ? "is" : element.status,
                    statusData: !element.statusData
                };
            }
            return {...element}
        })]);

        await changeStatusProducts(selectedTempElements.join(",")).unwrap();
        setListSelected([])
        setHead({...head, isSelectAll: false});
    }

    const setStatusDelete = async () => {
        let selectedTempElements = []
        setData([...data.map((element, index) => {
            if (element.isSelected) {
                selectedTempElements.push(element.id);
                return {
                    ...element,
                    status: element.status !== "delete" ? "delete" : element.statusData === true ? "is" : "not-is"
                };
            }
            return {...element}
        })]);
        await removeProducts(selectedTempElements.join(",")).unwrap();
        setListSelected([])
        setHead({...head, isSelectAll: false});
    }

    const clearSelectedElement = () => {
        setData([...data.map((_val, _index) => ({..._val, isSelected: false}))])
    }

    useEffect(() => {
        dataLoad({page: 1});
        categoryLoad();
        window.addEventListener('click', (e) => {
            setGlobalContextMenu(false);
        });
    }, []);

    const saveDiscount = async ()=>{
        let checkValidate = true;
        
        if(discountPrice === 0){
            checkValidate = false;
        }

        if(checkValidate){
            let discountElements = []
            let dateTimeLine = {};
            data.map((element, index) => {
                if (element.isSelected) {
                    discountElements.push(element.id);
                }
            });

            if (isTimeLine) {
                dateTimeLine = {
                    "date_start": firstTimeLine,
                    "date_end": secondTimeLine,
                };
            }


            
            await addSaleProducts({
                id: discountElements.join(","),
                ...dateTimeLine,
                "sale": discountPrice
            }).unwrap();
            setHead({...head, isSelectAll: false});
            setData(data.map((_val) => ({..._val, isSelected: false})));
            setListSelected([]);
            setDiscountError("");
            setFirstTimeline("");
            setSecondTimeLine("")
            setIsTimeLine(false);
            changeDiscountPrice(0);
            setIsModal(false);
        } else {
            setDiscountError("Введіть кількість відсотків");
        }
    }
    const[discountError,setDiscountError] = useState("")


    return (
        <div className="page-product-table">
            <AddDiscount
                error={discountError}
                saveDiscount={saveDiscount}
                isOpen={isModal}
                setIsOpen={setIsModal}
                isTimeLine={isTimeLine}
                setIsTimeLine={setIsTimeLine}
                discountPrice={discountPrice}
                changeDiscountPrice={changeDiscountPrice}
                firstTimeLine={firstTimeLine}
                setFirstTimeline={setFirstTimeline}
                secondTimeLine={secondTimeLine}
                setSecondTimeLine={setSecondTimeLine}
            />
            <TitleTablePage
                actionIcon={openMenu}
                title="Додати товар"
                actionMainButton={() => navigate(defaultPrevUrl + 'products/create')}
            >
                Додати товар
            </TitleTablePage>
            <div className="content-page-block">
                <div className="filter-form">
                    <div className="search-form">
                        <InputSearch
                            desktop="Пошук за Назвою товару"
                            phone="Пошук"
                            actionSearch={() => actionSearch()}
                            state={filterData.search}
                            setState={(val) => setFilterData({...filterData, search: val})}
                        />
                    </div>
                    <div className="select-category-form">
                        <SelectUI
                            defaultTitle="Категорія товару"
                            option={categoryProductList}
                            state={filterData.otherFilter[0]}
                            setState={(index) => {
                                let list = filterData.otherFilter;
                                list[0] = index;
                                setFilterData({...filterData, otherFilter: list});
                                actionSearch(1, {...filterData, otherFilter: list})
                            }}
                        />
                    </div>
                    <div className="select-state-form">
                        <SelectUI
                            defaultTitle="Статус товарів"
                            option={stateProductList.map((element, index) => {
                                return {text: element}
                            })}
                            state={filterData.otherFilter[1]}
                            setState={(index) => {
                                let list = filterData.otherFilter;
                                list[1] = index;
                                setFilterData({...filterData, otherFilter: list});
                                actionSearch(1, {...filterData, otherFilter: list});
                            }}
                        />
                    </div>
                    <div className="more-form" onClick={(e) => {
                        e.stopPropagation();
                        e.preventDefault();
                    }}>
                        <MoreIcons className="more-icon" onClick={() => setGlobalContextMenu(!globalContextMenu)}/>
                        <div
                            className={`context-menu-global ${globalContextMenu ? "open" : ""}`}
                        >
                            <div className="context-menu-global-action" onClick={addDiscount}>
                                Додати знижку
                            </div>
                            <div className="context-menu-global-action" onClick={setStatusNotIs}>
                                Поставити статус
                                “немає в наявності”
                            </div>
                            <div className="context-menu-global-action" onClick={setStatusDelete}>
                                Видалити
                            </div>
                        </div>
                    </div>
                    <div className={`mobile-selected-element ${listSelected.length > 0 ? "selected-element" : ""}`}>
                        <LeftArrowIcon className="left-arrow-icon" onClick={clearSelectedElement}/>
                        <div className="counts-selected-element">{listSelected.length}</div>
                        <MoreIcons className="more-icon" onClick={() => setGlobalContextMenu(!globalContextMenu)}/>
                    </div>
                    <div className="open-mobile-filter">
                        <FilterIcon className="filter-icon" onClick={() => setIsOpenMobileFilter(true)}/>
                    </div>
                </div>
                <ElementsFilterSearchMobileWidget
                    actionAccess={() => actionSearch()}
                    actionDropFilters={() => setFilterData({search: "", otherFilter: [-1, -1]})}
                    data={[
                        {title: "Категорія товару", chooses: categoryProductList},
                        {title: "Статус товару", chooses: stateProductList}
                    ]}
                    stateFilter={filterData.otherFilter}
                    setStateFilter={(value) => setFilterData({...filterData, otherFilter: value})}
                    isOpenFilter={isOpenMobileFilter}
                    setIsOpenFilter={setIsOpenMobileFilter}
                />
                <Table
                    selectElement={(index) => {
                        let dataArray = [...data];
                        dataArray[index].isSelected = !dataArray[index].isSelected;
                        setData(dataArray);
                        let value = dataArray.reduce((accumulator, currentValue) => accumulator + currentValue.isSelected, 0)
                        if (value === dataArray.length) {
                            setHead({...head, isSelectAll: true});
                        } else {
                            setHead({...head, isSelectAll: false});
                        }


                        if (dataArray[index].isSelected) {
                            setListSelected([...listSelected.filter((_val) => _val !== index)])
                        } else {
                            setListSelected([...listSelected, index]);
                        }
                    }}
                    head={head}
                    data={data}
                    uniteTablet={[1, 2]}
                    uniteMobile={{right: [[0, ""], [1, "Категорія :"], [2, "Ціна: "]], left: [3, 4]}}
                    greenState='is'
                    blueState='inprocess'
                    redState='not-is'
                    greyState='delete'
                    greenTitle='В няавності'
                    blueTitle='В процесі'
                    redTitle='Немає'
                    greyTitle='Видалений'
                    underDataButtons={underDataButtons}
                    blockWidth={72}
                    isOpenContextMenu={isOpenContextMenu}
                    setIsOpenContextMenu={(index) => setIsOpenContextMenu(index)}
                    onClickElement={() => {
                    }}
                    selectAll={selectAll}
                />
            </div>
            <Pagination page={page} setPage={(page) => actionSearch(page)} maxPage={maxPage}/>
            <MobileContextMenu
                isOpenContextMenu={globalContextMenu}
                setIsOpenContextMenu={setGlobalContextMenu}
                actionList={[
                    {action: addDiscount, title: "Додати знижку"},
                    {action: setStatusNotIs, title: "Поставити статус “немає в наявності”"},
                    {action: setStatusDelete, title: "Видалити"},
                ]}
            />

        </div>
    );
};

export default TableProductsPage;