import TableProductsPage from "./result";

export default TableProductsPage;