import TableProductsPage from "./TableProductsPage";
import ProductPage from "./ProductPage";
import CreateProductPage from "./CreateProductPage";

export {
    TableProductsPage,
    ProductPage,
    CreateProductPage
}