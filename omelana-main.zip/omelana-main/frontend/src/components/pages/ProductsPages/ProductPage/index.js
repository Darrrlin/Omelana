import ProductPage from "./result";

export default ProductPage;