import React, {useEffect, useState} from 'react';

import '../css/edit-page.css';
import '../css/view-page.css';
import {defaultPrevUrl} from "../../../../processes/routing";
import TitleSinglePage from "../../../../ui/TitleSinglePage";
import InputTextLabel from "../../../../ui/Inputs/InputTestLabel";
import SelectForm from "../../../../ui/selects/SelectForm";
import InputWithDescription from "../../../../ui/Inputs/InputWithDescription";
import PlusIcon from "../../../../ui/icons/PlusIcon";
import DiscountProductWidget from "../../../../widgets/DiscountProductWidget";
import InputTextArea from "../../../../ui/Inputs/InputTextArea";
import {MoreImages} from "../../../../ui/image";
import SelectUI from "../../../../ui/selects/SelectUI";
import {useGetCategoriesMutation} from "../../../../processes/category";
import {useGetProductMutation, useUpdateProductMutation} from "../../../../processes/product";
import {useNavigate, useParams} from "react-router-dom";
import {isNumber} from "chart.js/helpers";
import PenIcon from "../../../../ui/icons/PenIcon";
import {ModalCheckSaveWidget} from "../../../../widgets/ModalCheckSaveWidget";

const optionStatus = [
    {text: "Є в наявності", value: 1},
    {text: "Немає в наявності", value: 0},
    {text: "Видалений", value: 2},
]

const CreateProductPage = ({openMenu}) => {
    const [data, setData] = useState({
        name: "",
        nameError: "",
        status: 0,
        price: 0,
        isDiscount: false,
        discountPrice: 0,
        discountPercent: 0,
        isDiscountTimeLine: false,
        discountFirstTimeLine: "",
        discountSecondTimeLine: "",
        description: "",
        photo: [],
        deletedImages: [],
        listSelectPhoto: [],
        category: undefined,
        categoryProperties: [],
        priceError: 0,
        photoError: "",
        categoryError: 0
    });
    const [isShowDescription, setIsShowDescription] = useState(false);
    const [isEdit, setIsEdit] = useState(false);
    const [categories, setCategories] = useState(null);
    const [isOpenContextMenu, setIsOpenContextMenu] = useState(false);
    const navigate = useNavigate();
    let {id} = useParams();
    const [getCategories, {isLoadingCategory}] = useGetCategoriesMutation();
    const [updateProductData, {isLoading}] = useUpdateProductMutation();
    const [getProduct, {isLoadingProduct}] = useGetProductMutation();
    const [condition, setCondition] = useState(true);

    useEffect(() => {
        window.addEventListener("click", (e) => {
            setIsOpenContextMenu(false);
        });
    }, []);

    useEffect(() => {
        const fetchDataCategory = async () => {
            const data = await getCategories(true).unwrap();
            setCategories(data)
            return data
        }


        const fetchData = async () => {
            const categoriesData = await fetchDataCategory();
            const dataResponse = await getProduct(id).unwrap();
            let images = [...dataResponse.images];
            const categoryIndex = categoriesData.findIndex((_val) => _val.id == dataResponse.category)
            images.sort((a, b) => a.sequence - b.sequence);
            let dataSave = {
                name: dataResponse.title,
                price: dataResponse.price,
                description: dataResponse.description,
                category: categoryIndex,
                photo: images.map((_val, _index) => {
                    return {id: _val.id, imageUrl: _val.image, image: _val.image}
                }),
            }


            if (dataResponse["start_sale"] && dataResponse["end_sale"]) {
                const dateStart = new Date(Date.parse(`${dataResponse["end_sale"]}`)),
                    dateEnd = new Date(Date.parse(`${dataResponse["end_sale"]}`));
                if (dateStart && dateEnd && Date.now() - dateEnd < 0) {
                    dataSave.isDiscount = true;
                    dataSave.discountPrice = ((100 - parseInt(dataResponse["sale"])) / 100 * parseInt(dataResponse.price)).toFixed(2);
                    dataSave.discountPercent = parseInt(dataResponse["sale"]);
                    dataSave.isDiscountTimeLine = true;
                    dataSave.discountFirstTimeLine = dataResponse["start_sale"].split("T")[0];
                    dataSave.discountSecondTimeLine = dataResponse["end_sale"].split("T")[0];
                }
            }


            let properties = Array(categoriesData[dataSave.category]["properties"].length).fill(0);
            for (const property of dataResponse.properties) {
                const indexPropertyCategory = categoriesData[dataSave.category]["properties"].findIndex((_element) => _element.id === property.id);
                if (indexPropertyCategory !== -1) {
                    const indexPropertyCategoryValue = categoriesData[dataSave.category]["properties"][indexPropertyCategory]["properties_choices"].findIndex((_element) => _element.title === property.value);
                    if (indexPropertyCategoryValue !== -1) {
                        properties[indexPropertyCategory] = indexPropertyCategoryValue;
                    }
                }
            }

            if (dataResponse["on_delete"] === true) {
                dataSave.status = 2
            } else if (parseInt(dataResponse["status"]) === 0) {
                data.status = 1;
            } else {
                data.status = 0;
            }

            dataSave.categoryProperties = properties;

            setData({...data, ...dataSave});
        }

        fetchData();
    }, [id]);``

    const checkValid = () => {
        let checkValidate = true, errorData = {};

        if (data.name === "") {
            checkValidate = false;
            errorData.nameError = "Введіть назву товару";
        }

        if (parseInt(data.price) === 0) {
            checkValidate = false;
            errorData.priceError = "Введіть ціну товару";
        }

        if (data.photo.length === 0) {
            checkValidate = false;
            errorData.photoError = "Завантажте принаймні одне фото товару";
        }

        if (data.category === -1) {
            checkValidate = false;
            errorData.categoryError = "Оберіть категорію товару";
        }

        return [checkValidate, errorData];
    }

    const generateFormData = () => {
        const formData = new FormData();
        formData.append("id", id);
        formData.append("category", `${categories[data.category].id}`)
        formData.append("title", data.name);
        formData.append("description", data.description);
        formData.append("status", `${optionStatus[data.status].value}`);
        if (data.isDiscount) {
            let sale = {}
            sale.percent = data.discountPercent;
            if (data.isDiscountTimeLine) {
                sale.timeline = {};
                if (data.discountFirstTimeLine) {
                    sale.timeline.date_start = data.discountFirstTimeLine
                }

                if (data.discountSecondTimeLine) {
                    sale.timeline.date_end = data.discountSecondTimeLine
                }
            }
            formData.append("sale", JSON.stringify(sale));
        }
        formData.append("price", `${data.price}`)
        let properties = {};
        for (const categoryPropertyKey in data.categoryProperties) {
            properties[`${categories[data.category]["properties"][categoryPropertyKey]["id"]}`] = categories[data.category]["properties"][categoryPropertyKey]["properties_choices"][data.categoryProperties[categoryPropertyKey]]["title"]
        }
        formData.append("properties", JSON.stringify(properties))

        formData.append("deleted_images", JSON.stringify(data.deletedImages));

        let newImages = [], oldImages = [],
            indexImages = Array(data.photo.length - data.listSelectPhoto.length).fill(false).map((_, idx) => data.listSelectPhoto.length + idx);

        for (const imagesKey in data.photo) {
            const indexSelected = data.listSelectPhoto.findIndex((_val) => {
                return imagesKey == _val;
            });
            let name = "", sequence = 0;
            if (indexSelected !== -1) {
                name = `photo-product-${indexSelected}`;
                sequence = indexSelected;
            } else {
                name = `photo-product-${indexImages[0]}`;
                sequence = indexImages[0];
                indexImages.shift()
            }

            if (data.photo[imagesKey].isNew || !data.photo[imagesKey].id) {
                newImages.push({
                    name: name,
                    sequence: sequence,
                });
                formData.append(name, data.photo[imagesKey].image);
            } else {
                oldImages.push({
                    id: data.photo[imagesKey].id,
                    sequence: sequence,
                });
            }
        }

        formData.append("new_images", JSON.stringify(newImages));
        formData.append("old_images", JSON.stringify(oldImages));
        return formData;
    }

    const saveProduct = async () => {
        const [checkValidate, errorData] = checkValid();

        if (checkValidate) {
            const formData = generateFormData();
            try {
                await updateProductData(formData).unwrap();
                setIsEdit(false);
                setCondition(true);
            } catch (err) {
                setData({
                    ...data,
                    nameError: "Невірні дані!",
                    priceError: "Невірні дані!",
                    photoError: "Невірні дані!",
                    categoryError: "Невірні дані!",
                });
            }
        } else {
            setData({...data, ...errorData});
        }
    }

    const saveProductOnClose = async () => {
        const [checkValidate, errorData] = checkValid();

        if (checkValidate) {
            const formData = generateFormData();
            try {
                await updateProductData(formData).unwrap();
            } catch (err) {
            }
        }
    }

    return (
        <>
            <ModalCheckSaveWidget condition={condition} save={saveProductOnClose} />
            <TitleSinglePage
                tabletIcon={!isEdit ? "arrow" : undefined}
                mobileIcon='arrow'
                actionIcon={openMenu}
                sectionTitle="Товари"
                sectionPath={defaultPrevUrl + "products/"}
                mainTitle={!isEdit ? "Товари" : "Редагувати товар"}
                mainTitleName={data.name}
                actionMainButton={!isEdit ? () => setIsEdit(true) : saveProduct}
                styleClassMainButton="primary"
                icon={!isEdit ? PenIcon : null}
            >
                {!isEdit ? "Редагувати товар" : "Зберегти товар"}
            </TitleSinglePage>
            {!isEdit &&
                <div className="product-view-page">
                    <div className='head-title-section title'>{data.name}</div>
                    <div className="form-section title">
                        <div className="status-input-data">
                            <div className="input-data price">
                                <div className="title">
                                    Ціна
                                </div>
                                <div className="data">
                                    {data.price}
                                </div>
                            </div>
                            <div
                                className={`status-product ${data.status === 0 ? "active" : data.status === 1 ? "not-active" : "delete"}`}>
                                {optionStatus[data.status].text}
                            </div>
                        </div>
                        {data.isDiscount &&
                            <div className="discount-input-data">
                                <div className="input-data discount discount-price">
                                    <div className="title">
                                        Ціна знижена
                                    </div>
                                    <div className="data">
                                        {data.discountPrice}
                                    </div>
                                </div>
                                <div className="input-data discount discount-percent">
                                    <div className="title">
                                        Відсоток
                                    </div>
                                    <div className="data">
                                        {data.discountPercent}
                                    </div>
                                </div>
                                {data.isDiscountTimeLine &&
                                    <div className="input-data discount discount-time-line">
                                        <div className="title">
                                            Часовий проміжок
                                        </div>
                                        <div className="data">
                                            {data.discountFirstTimeLine} - {data.discountSecondTimeLine}
                                        </div>
                                    </div>
                                }
                            </div>
                        }

                        <div
                            className={`input-data description ${isShowDescription || data.description.length < 400 ? "show" : ""}`}>
                            <div className="title">
                                Опис
                            </div>
                            <div className="data">
                                {data.description}
                                {!isShowDescription && data.description.length > 400 &&
                                    <div className="is-show-description-block"
                                         onClick={() => setIsShowDescription(true)}>
                                        <div className="action-read-more">
                                            Читати повністю
                                        </div>
                                    </div>
                                }

                            </div>
                        </div>
                    </div>
                    <div className='head-title-section photo'>Фото</div>
                    <div className="form-section photo">
                        {data.photo.map((elementPhoto, indexPhoto) =>
                            <div className="form-photo-data" key={`form-photo-${indexPhoto}`}>
                                <img
                                    src={elementPhoto.imageUrl}
                                    className="photo-source"
                                    alt={`photo-${indexPhoto}`}
                                    key={`image-source-${indexPhoto}`}
                                />
                            </div>
                        )}

                    </div>

                    <div className='head-title-section properties'>Характеристика товару</div>

                    <div className="form-section properties">
                        <div className="product-property-data">
                            <div className="product-property-data-title-data">
                                Категорія:
                            </div>
                            <div className="product-property-data-source">
                                {isNumber(data.category) && !isLoadingCategory && categories[data.category].title}
                            </div>
                        </div>
                        {isNumber(data.category) && !isLoadingCategory &&
                            <>
                                {categories[data.category]["properties"].map((element, index) => {
                                        return (
                                            <div className="product-property-data" key={`product-property-data-${index}`}>
                                                <div className="product-property-data-title-data"
                                                     key={`product-property-data-title-data-${index}`}>
                                                    {element.title}:
                                                </div>
                                                <div className="product-property-data-source"
                                                     key={`product-property-data-source-${index}`}>
                                                    {element["properties_choices"][data.categoryProperties[index]].title}
                                                </div>
                                            </div>
                                        )
                                    }
                                )}
                            </>
                        }
                    </div>
                </div>
            }
            {isEdit &&
                <div className="page-product-edit">
                    <div className='head-title-section'>Інформація про товар</div>
                    <div className="form-section">
                        <div className="form-title">
                            <InputTextLabel
                                className="form-name"
                                value={data.name}
                                onChange={(e) => {
                                    if (condition) {
                                        setCondition(false);
                                    }
                                    setData({...data, name: e.target.value});
                                }}
                                label="Назва"
                                prefixLabel="name"
                                errorText={data.nameError}
                            />
                            <SelectForm
                                title="Статус"
                                option={optionStatus}
                                state={data.status}
                                setState={(val) => {
                                    if (condition) {
                                        setCondition(false);
                                    }
                                    setData({...data, status: val});
                                }}
                            />
                        </div>
                        <div className="from-price">
                            <InputWithDescription
                                desc="грн"
                                label="Ціна"
                                state={data.price}
                                setState={(value) => {
                                    if (condition) {
                                        setCondition(false);
                                    }
                                    setData({...data, price: value});
                                }}
                            />
                            {!data.isDiscount &&
                                <div className="action-add-discount"
                                     onClick={() => setData({...data, isDiscount: true})}>
                                    <PlusIcon className="add-icon"/>
                                    <span className="add-title">
                                    Додати знижену ціну
                                </span>
                                </div>
                            }
                        </div>
                        {data.isDiscount &&
                            <div className="form-discount">
                                <DiscountProductWidget
                                    currentPrice={data.price}
                                    discountPrice={data.discountPrice}
                                    setDiscountPrice={(value) => {
                                        if (condition) {
                                            setCondition(false);
                                        }
                                        setData({...data, discountPrice: value});
                                    }}
                                    discountPercent={data.discountPercent}
                                    setDiscountPercent={(value) => {
                                        if (condition) {
                                            setCondition(false);
                                        }
                                        setData({...data, discountPercent: value});
                                    }}
                                    isTimeLine={data.isDiscountTimeLine}
                                    setIsTimeLine={(value) => setData({...data, isDiscountTimeLine: value})}
                                    firstTimeLine={data.discountFirstTimeLine}
                                    setFirstTimeline={(value) => {
                                        if (condition) {
                                            setCondition(false);
                                        }
                                        setData({...data, discountFirstTimeLine: value});
                                    }}
                                    secondTimeLine={data.discountSecondTimeLine}
                                    setSecondTimeLine={(value) => {
                                        if (condition) {
                                            setCondition(false);
                                        }
                                        setData({...data, discountSecondTimeLine: value});
                                    }}
                                    isOpenContextMenu={isOpenContextMenu}
                                    setIsOpenContextMenu={setIsOpenContextMenu}
                                    actionDisableDiscount={() => setData({...data, isDiscount: false})}
                                    setPricePercentData={(value1, value2) => {
                                        if (condition) {
                                            setCondition(false);
                                        }
                                        setData({...data, discountPrice: value1, discountPercent: value2});
                                    }}
                                />
                            </div>
                        }

                        <div className="form-description">
                            <InputTextArea
                                height="163px"
                                label="Опис"
                                state={data.description}
                                setState={(value) => {
                                    if (condition) {
                                        setCondition(false);
                                    }
                                    setData({...data, description: value});
                                }}
                                error=""
                            />
                        </div>
                    </div>

                    <div className='head-title-section'>Фото</div>

                    <div className="form-section">
                        <MoreImages
                            width="max(158px, 10.97vw)"
                            height="max(210px, 14.58vw)"
                            imageData={data.photo}
                            setImageData={(value) => {
                                if (condition) {
                                    setCondition(false);
                                }
                                setData({...data, photo: value});
                            }}
                            error={data.photoError}
                            setError={(value) => setData({...data, photoError: value})}
                            listSelect={data.listSelectPhoto}
                            setListSelect={(value) => {
                                if (condition) {
                                    setCondition(false);
                                }
                                setData({...data, listSelectPhoto: value});
                            }}
                            deletedImageData={(index) => {
                                if (condition) {
                                    setCondition(false);
                                }
                                if (data.photo[index].id) {
                                    setData({
                                        ...data,
                                        photo: data.photo.filter(element => element !== data.photo[index]),
                                        listSelectPhoto: data.listSelectPhoto.filter(element => element !== index).map((_val, _index) => _index < index ? _val : _val - 1),
                                        deletedImages: [...data.deletedImages, data.photo[index].id],
                                    });
                                    return
                                }
                                setData({
                                    ...data,
                                    photo: data.photo.filter(element => element !== data.photo[index]),
                                    listSelectPhoto: data.listSelectPhoto.filter(element => element !== index).map((_val, _index) => _index < index ? _val : _val - 1)
                                });
                            }}
                        />
                    </div>

                    <div className='head-title-section'>Характеристики</div>
                    <div className="form-section">
                        <div className="product-property">
                            <div className="title">Категорії</div>
                            <div className="option-select-property">
                                <SelectUI
                                    defaultTitle="Виберіть категорію"
                                    option={categories.map((element, index) => {
                                        return {text: element.title}
                                    })}
                                    state={data.category}
                                    setState={(val) => {
                                        if (condition) {
                                            setCondition(false);
                                        }
                                        setData({
                                            ...data,
                                            category: val,
                                            categoryProperties: new Array(categories[val].properties.length).fill(0)
                                        })
                                    }}
                                />
                                {data.categoryError
                                    ? <div className="error-select">{data.categoryError}</div>
                                    : null
                                }
                            </div>
                        </div>
                        {isNumber(data.category) && !isLoadingCategory &&
                            <>
                                {categories[data.category]["properties"].map((element, index) =>
                                    <div className="product-property" key={`product-property-${index}`}>
                                        <div className="title"
                                             key={`product-property-title-${index}`}>{element.title}</div>
                                        <div className="option-select-property"
                                             key={`product-property-option-select-property-${index}`}>
                                            <SelectUI
                                                key={`product-property-select-ui-${index}`}
                                                option={element["properties_choices"].map((elementMap, indexMap) => {
                                                    return {text: elementMap.title}
                                                })}
                                                state={data.categoryProperties[index]}
                                                setState={(val) => {
                                                    if (condition) {
                                                        setCondition(false);
                                                    }
                                                    let array = data.categoryProperties;
                                                    array[index] = val;
                                                    setData({...data, categoryProperties: array});
                                                }}
                                                error={!!data.categoryError}
                                            />
                                        </div>
                                    </div>
                                )}
                            </>
                        }

                    </div>
                </div>}
        </>
    );
};

export default CreateProductPage;