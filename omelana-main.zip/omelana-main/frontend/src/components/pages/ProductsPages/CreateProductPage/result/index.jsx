import React, {useEffect, useState} from 'react';

import '../css';
import {defaultPrevUrl} from "../../../../processes/routing";
import TitleSinglePage from "../../../../ui/TitleSinglePage";
import InputTextLabel from "../../../../ui/Inputs/InputTestLabel";
import SelectForm from "../../../../ui/selects/SelectForm";
import InputWithDescription from "../../../../ui/Inputs/InputWithDescription";
import PlusIcon from "../../../../ui/icons/PlusIcon";
import DiscountProductWidget from "../../../../widgets/DiscountProductWidget";
import InputTextArea from "../../../../ui/Inputs/InputTextArea";
import {MoreImages} from "../../../../ui/image";
import SelectUI from "../../../../ui/selects/SelectUI";
import {useGetCategoriesMutation} from "../../../../processes/category";
import {useNavigate} from "react-router-dom";
import {useCreateProductMutation} from "../../../../processes/product";
import {ModalCheckSaveWidget} from "../../../../widgets/ModalCheckSaveWidget";

const optionStatus = [
    {text: "Є в наявності", value: 1},
    {text: "Немає в наявності", value: 0},
    {text: "Видалений", value: 2},
]

const CreateProductPage = ({openMenu}) => {
    const [data, setData] = useState({
        name: "",
        nameError: "",
        status: 0,
        price: 0,
        isDiscount: false,
        discountPrice: 0,
        discountPercent: 0,
        isDiscountTimeLine: false,
        discountFirstTimeLine: "",
        discountSecondTimeLine: "",
        description: "",
        photo: [],
        listSelectPhoto: [],
        category: -1,
        categoryProperties: [],
        priceError: "",
        photoError: "",
        categoryError: ""
    });
    const [categories, setCategories] = useState([]);
    const [isOpenContextMenu, setIsOpenContextMenu] = useState();
    const [getCategories, {isLoadingCategory}] = useGetCategoriesMutation();
    const navigate = useNavigate();
    const [saveProductData, {isLoading}] = useCreateProductMutation();
    const [condition, setCondition] = useState(true);

    useEffect(() => {

        const fetchDataCategory = async () => {
            const data = await getCategories(true).unwrap();
            setCategories(data)
        }

        fetchDataCategory();

    }, []);

    const checkValid = () => {
        let checkValidate = true, errorData = {};

        if (data.name === "") {
            checkValidate = false;
            errorData.nameError = "Введіть назву товару";
        }

        if (parseInt(data.price) === 0) {
            checkValidate = false;
            errorData.priceError = "Введіть ціну товару";
        }

        if (data.photo.length === 0) {
            checkValidate = false;
            errorData.photoError = "Завантажте принаймні одне фото товару";
        }

        if (data.category === -1) {
            checkValidate = false;
            errorData.categoryError = "Оберіть категорію товару";
        }

        return [checkValidate, errorData]
    }

    const generateFormData = () => {
        const formData = new FormData();
        formData.append("category", `${categories[data.category].id}`);
        formData.append("title", data.name);
        formData.append("description", data.description);
        formData.append("status", `${optionStatus[data.status].value}`);
        if (data.isDiscount) {
            let sale = {}
            sale.percent = data.discountPercent;
            if (data.isDiscountTimeLine) {
                sale.timeline = {};
                if (data.discountFirstTimeLine) {
                    sale.timeline.date_start = data.discountFirstTimeLine;
                }

                if (data.discountSecondTimeLine) {
                    sale.timeline.date_end = data.discountSecondTimeLine;
                }
            }
            formData.append("sale", JSON.stringify(sale));
        }
        let images = [],
            indexImages = Array(data.photo.length - data.listSelectPhoto.length).fill(false).map((_, idx) => data.listSelectPhoto.length + idx);
        for (const imagesKey in data.photo) {
            const indexSelected = data.listSelectPhoto.findIndex((_val) => {
                return imagesKey == _val;
            });
            let name = "", sequence = 0;
            if (indexSelected !== -1) {
                name = `photo-product-${indexSelected}`;
                sequence = indexSelected;
            } else {
                name = `photo-product-${indexImages[0]}`;
                sequence = indexImages[0];
                indexImages.shift()
            }
            images.push({
                name: name,
                sequence: sequence,
            })
            formData.append(name, data.photo[imagesKey].image);
        }

        formData.append("images", JSON.stringify(images))
        formData.append("price", `${data.price}`)
        let properties = {};
        for (const categoryPropertyKey in data.categoryProperties) {
            properties[`${categories[data.category]["properties"][categoryPropertyKey]["id"]}`] = categories[data.category]["properties"][categoryPropertyKey]["properties_choices"][data.categoryProperties[categoryPropertyKey]]["title"]
        }
        formData.append("properties", JSON.stringify(properties))

        return formData;
    }


    const saveProductOnClose = async () => {
        const [checkValidate, errorData] = checkValid();

        if (checkValidate) {
            const formData = generateFormData();
            try {
                await saveProductData(formData).unwrap();
            } catch (err) {
            }
        }
    }


    const saveProduct = async () => {
        const [checkValidate, errorData] = checkValid();

        if (checkValidate) {
            const formData = generateFormData();
            setCondition(true);
            try {
                const response = await saveProductData(formData).unwrap();
                return navigate(defaultPrevUrl + `products/${response.id}/`);
            } catch (err) {
                setData({
                    ...data,
                    nameError: "Невірні дані!",
                    priceError: "Невірні дані!",
                    photoError: "Невірні дані!",
                    categoryError: "Невірні дані!",
                });
            }
        } else {
            setData({...data, ...errorData});
        }
    }
    return (
        <>
            <ModalCheckSaveWidget condition={condition} save={saveProductOnClose} />
            <TitleSinglePage
                tabletIcon="arrow"
                mobileIcon='arrow'
                actionIcon={openMenu}
                sectionTitle="Товари"
                sectionPath={defaultPrevUrl + "products/"}
                mainTitle="Додати товар"
                mainTitleName="Додати товар"
                actionMainButton={saveProduct}
                styleClassMainButton="secondary"
            >
                Зберегти товар
            </TitleSinglePage>
            <div className="page-product-create">
                <div className='head-title-section'>Інформація про товар</div>
                <div className="form-section">
                    <div className="form-title">
                        <InputTextLabel
                            className="form-name"
                            value={data.name}
                            onChange={(e) => {
                                if (condition) {
                                    setCondition(false);
                                }
                                setData({...data, name: e.target.value});
                            }}
                            label="Назва"
                            prefixLabel="name"
                            errorText={data.nameError}
                        />
                        <SelectForm
                            title="Статус"
                            option={optionStatus}
                            state={data.status}
                            setState={(val) => {
                                if (condition) {
                                    setCondition(false);
                                }
                                setData({...data, status: val});
                            }}
                        />
                    </div>
                    <div className="from-price">
                        <InputWithDescription
                            desc="грн"
                            label="Ціна"
                            state={data.price}
                            setState={(value) => {
                                if (condition) {
                                    setCondition(false);
                                }
                                setData({...data, price: value});
                            }}
                            error={data.priceError}
                        />
                        {!data.isDiscount &&
                            <div className="action-add-discount" onClick={() => setData({...data, isDiscount: true})}>
                                <PlusIcon className="add-icon"/>
                                <span className="add-title">
                                    Додати знижену ціну
                                </span>
                            </div>
                        }
                    </div>
                    {data.isDiscount &&
                        <div className="form-discount">
                            <DiscountProductWidget
                                currentPrice={data.price}
                                discountPrice={data.discountPrice}
                                setDiscountPrice={(value) => {
                                    if (condition) {
                                        setCondition(false);
                                    }
                                    setData({...data, discountPrice: value});
                                }}
                                discountPercent={data.discountPercent}
                                setDiscountPercent={(value) => {
                                    if (condition) {
                                        setCondition(false);
                                    }
                                    setData({...data, discountPercent: value});
                                }}
                                isTimeLine={data.isDiscountTimeLine}
                                setIsTimeLine={(value) => setData({...data, isDiscountTimeLine: value})}
                                firstTimeLine={data.discountFirstTimeLine}
                                setFirstTimeline={(value) => {
                                    if (condition) {
                                        setCondition(false);
                                    }
                                    setData({...data, discountFirstTimeLine: value});
                                }}
                                secondTimeLine={data.discountSecondTimeLine}
                                setSecondTimeLine={(value) => {
                                    if (condition) {
                                        setCondition(false);
                                    }
                                    setData({...data, discountSecondTimeLine: value});
                                }}
                                isOpenContextMenu={isOpenContextMenu}
                                setIsOpenContextMenu={setIsOpenContextMenu}
                                actionDisableDiscount={() => setData({...data, isDiscount: false})}
                                setPricePercentData={(value1, value2) => {
                                    if (condition) {
                                        setCondition(false);
                                    }
                                    setData({...data, discountPrice: value1, discountPercent: value2});
                                }}
                            />
                        </div>
                    }

                    <div className="form-description">
                        <InputTextArea
                            height="163px"
                            label="Опис"
                            state={data.description}
                            setState={(value) => {
                                if (condition) {
                                    setCondition(false);
                                }
                                setData({...data, description: value});
                            }}
                            error=""
                        />
                    </div>
                </div>

                <div className='head-title-section'>Фото</div>

                <div className="form-section">
                    <MoreImages
                        width="max(158px, 10.97vw)"
                        height="max(210px, 14.58vw)"
                        imageData={data.photo}
                        setImageData={(value) => {
                            if (condition) {
                                setCondition(false);
                            }
                            setData({...data, photo: value});
                        }}
                        error={data.photoError}
                        setError={(value) => {
                            if (condition) {
                                setCondition(false);
                            }
                            setData({...data, photoError: value});
                        }}
                        listSelect={data.listSelectPhoto}
                        setListSelect={(value) => {
                            if (condition) {
                                setCondition(false);
                            }
                            setData({...data, listSelectPhoto: value});
                        }}
                        deletedImageData={(index) => {
                            if (condition) {
                                setCondition(false);
                            }
                            setData({
                                ...data,
                                photo: data.photo.filter(element => element !== data.photo[index]),
                                listSelectPhoto: data.listSelectPhoto.filter(element => element !== index).map((_val, _index) => _index < index ? _val : _val - 1)
                            });
                        }}
                    />
                </div>

                <div className='head-title-section'>Характеристики</div>
                <div className="form-section">
                    <div className="product-property">
                        <div className="title">Категорії</div>
                        <div className="option-select-property">
                            <SelectUI
                                defaultTitle="Виберіть категорію"
                                option={categories.map((element, index) => {
                                    return {text: element.title}
                                })}
                                state={data.category}
                                setState={(val) => {
                                    if (condition) {
                                        setCondition(false);
                                    }
                                    setData({
                                        ...data,
                                        category: val,
                                        categoryProperties: new Array(categories[val].properties.length).fill(0)
                                    })
                                }}
                                error={!!data.categoryError}
                            />
                            {data.categoryError &&
                                <div className="error-select">{data.categoryError}</div>
                            }
                        </div>
                    </div>
                    {data.category !== -1 && !isLoadingCategory &&
                        <>
                            {categories[data.category]["properties"].map((element, index) =>
                                <div className="product-property" key={`product-property-${index}`}>
                                    <div className="title" key={`product-property-title-${index}`}>{element.title}</div>
                                    <div className="option-select-property"
                                         key={`product-property-option-select-property-${index}`}>
                                        <SelectUI
                                            key={`product-property-select-ui-${index}`}
                                            option={element["properties_choices"].map((elementMap, indexMap) => {
                                                return {text: elementMap.title}
                                            })}
                                            state={data.categoryProperties[index]}
                                            setState={(val) => {
                                                let array = data.categoryProperties;
                                                array[index] = val;
                                                setData({...data, categoryProperties: array});
                                            }}
                                        />
                                    </div>
                                </div>
                            )}
                        </>
                    }
                </div>
            </div>
        </>
    );
};

export default CreateProductPage;