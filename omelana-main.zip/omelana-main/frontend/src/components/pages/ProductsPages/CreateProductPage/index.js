import CreateProductPage from "./result";

export default CreateProductPage;