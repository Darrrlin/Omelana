import LoginPage from "./result";

export {
    LoginPage
}