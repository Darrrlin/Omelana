import React from "react";
import FormLoginWidget from "../../../widgets/FormLoginWidget/result";
import LogoIcon from "../../../ui/icons/LogoIcon";
import {Box} from "@mui/material";
import "../css";

function LoginPage(props){
    return (
        <Box sx={{
            width: '100%',
            height: '100%',
            padding: '16px',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center'
        }}>

            <LogoIcon className={"logo-login-page"} />
            <FormLoginWidget/>
        </Box>
    )
}

export default LoginPage;