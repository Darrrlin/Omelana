import AddEditOderPage from "./result/index.jsx";

export {
    AddEditOderPage
}