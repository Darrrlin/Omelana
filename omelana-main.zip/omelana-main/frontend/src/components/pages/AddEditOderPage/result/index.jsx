import React, {useState, useEffect} from 'react';
import Button from '../../../ui/buttons/SettingsButton';
import '../css/index.css';
import Select from '../../../ui/selects/OrderSelect';
import InputTextLabel from '../../../ui/Inputs/InputTestLabel';
import AutocompleteInput from '../../../ui/Inputs/AutocompleteInput'
import InputTextArea from '../../../ui/Inputs/InputTextArea'

const AddEditOderPage = (props) => {
    const apiKey = '9292798adf2829108b26e77a94ba6a18';
    const url = 'https://api.novaposhta.ua/v2.0/json/';
    let dataPars = '';
    let data = {
        'modelName':'Address',
        'calledMethod':'getCities',
        "methodProperties": {
            "Limit" : "50",

               }
    };
    let options = {
        'method':'POST',
        'headers':{
            'content-type':'application/json',
            'apiKey': {apiKey}
        }
    }
    function fetchDemo() {
        return fetch(url).then(function(response) {
            return response.json();
        }).then(function(json) {
            return json;
        });
    }

    function calculateSum(array, property1, property2) {
        const total = array.reduce((accumulator, object) => {
          return accumulator + object[property1]*object[property2];
        }, 0);

        setTotalSum(total);
      }
      
    const [totalSum,setTotalSum] = useState(0);
    const [value, setValue]= useState('Відкрите');
      
    const [radioState, setRadioState] = useState('selfTernopil');

    const changeradioState = (e)=>{
        setRadioState(e.target.value);
    }
    const [paymetRadioState, setPaymetRadioState] = useState('onTake')

    const changepaymetRadioState = (e)=>{
        setPaymetRadioState(e.target.value);
        }
    const [cities, setCities] = useState([])

    const onClick = ()=>{
    }

    const product = [{
        id:0,
        title:'',
        price:10,
        count:0,
        summ:0
    }];

    const [contacts, setConstacts]=useState(
        {
            name:'',
            surname:'',
            phone:'',
            mail:''
        })
    
    const changeContacts=(title,value)=>{
        let values = [contacts]
        values[title] = value;
        setConstacts(values);
    }


    const [products,setProducts] = useState([]);
    let arrayCities = []
    useEffect(()=>{
        setProducts(product);
        
        fetch(url, {
        method: 'POST',
        body: JSON.stringify({
            "modelName": "Address",
            "calledMethod": "getCities"
        }),
        headers: {
            'Content-type': 'application/json; charset=UTF-8',
        },
        })
        .then((response) => response.json())
        .then((data) => {
            data.data.map((data,index)=>{
                arrayCities.push(data.Description);
                setCities([...arrayCities])
            })
            
          
        })
        .catch((err) => {
            console.log(err.message);
        });
        
    },[])   

    useEffect(() => {
        calculateSum(products,'price','count')
      }, [products]);
      
    const addProduct = () =>{
        let values = [...products];
        var newProduct = product[0];
        newProduct['id'] = values.length;
        values.push(newProduct);
        setProducts(values);
    }

    const increment = (index)=>{
        let values = [...products]
        values[index]['count'] = values[index]['count']+1;
        setProducts(values);
    }

    const decrement = (index)=>{
        let values = [...products]
        if(values[index]['count']>1){
            values[index]['count'] = values[index]['count']-1;
        } 
        setProducts(values);
    }

    const changeTitle=(index,value)=>{
        let values = [...products]
        values[index]['title'] = value;
        setProducts(values);
    }

    const changeCount=(index,value)=>{
        let values = [...products]
        values[index]['count'] = value;
        setProducts(values);
    }

    const sortValue=(status)=>{
        setValue(status);
    }
    const [deliveryOptions, setDeliveryOptions] = useState([
        {
            id:0
        },
        {
            id:1
        },
        {
            id:2,
            city:'',
            street:'',
            house:'',
            number:''
        },
        {
            id:3,
            city:'',
            street:'',
            house:'',
            number:''
        }
    ])
    const changeDeliveryOptions=(index, title, value)=>{
        let values = [...deliveryOptions]
        values[index][title] = value;
        setDeliveryOptions(values);
    }
    const [textArea,setTextArea] = useState('')

    return (
        <div>
            <Button
             header='Контакти'
             text='Зберегти зміни'
             onClick={onClick}
            />
            <div className='add-product-page'>
                <span className='order-title'>
                    {/*Замовлення {props.order.id? '№'+props.order.id:''}*/}
                    <span>
                        Замовлення
                    </span>
                    <span>
                        Статус
                    <Select
                        options={[
                            {value:'inproces', name: 'В обробці'},
                            {value:'closed', name:'Закрите'},
                            {value:'removed',name:'Видалене'}
                        ]}
                        value={value}
                        onChange ={sortValue}
                        defaultValueDesctop='Відкрите'
                        defaultValuePhone='Відкрите'
                    />
                    </span>
                </span>
                <div className="details">
                    <span className="details-title">
                        Деталі замовлення
                    </span>
                    <hr className="edit-order-horizontal-line" />
                    {products.map((item,index)=>(
                        <div key={index} className='product-block'>
                            <hr style={{display: index > 0?'block':'none'}} 
                            className="edit-order-horizontal-line hr-beetwen-products" />
                            <span className="title-product-block">
                                <InputTextLabel
                                    value={item.title}
                                    onChange={(e)=>changeTitle(item.id,e.target.value)}
                                    label='Товар'
                                    
                                    />

                            </span>
                            <div className='phone-adaptive-block'>
                                <span className="title-price-block">
                                    <span className='title'>
                                        Ціна
                                    </span>
                                    <span className='value'>
                                        {item.price }грн
                                    </span>
                                
                                </span>
                                <span className="title-count-block">
                                    <span className='title'>
                                        Кількість
                                    </span>
                                    <span className='value'>
                                    <span onClick={()=>decrement(item.id)}>-</span> 
                                    <input type='number' value={item.count} onChange={(e)=>changeCount(item.id,e.target.value)} > 
                                        </input>
                                        <span onClick={()=>increment(item.id)}>+</span>
                                    </span>
                                
                                </span>
                                <span className="title-price-block">
                                    <span className='title'>
                                        Сума
                                    </span>
                                    <span className='value'>
                                        {item.price *item.count}грн
                                    </span>
                                
                                </span>
                            </div>
                            <span className='title-icon-block'>
                                <span>
                                    . . .
                                </span>

                            </span>
                            
                            
                        </div>
                    ))}
                    <hr className="edit-order-horizontal-line" />
                    <div className="add-order-button" onClick={addProduct}>
                        + Додати товар
                    </div>
                    <div className="sum-orders-label">
                        Сума {totalSum}
                    </div>
                </div>
                <span className="title-contacts">
                        Контактні дані клієнта
                    </span>
                <div className="contacts-form">
                    
                    <span>
                    <InputTextLabel
                                    value={contacts.name}
                                    onChange={(e)=>changeContacts('name',e.target.value)}
                                    label='Імя'
                                    />
                    </span>
                    <span>
                    <InputTextLabel
                                    value={contacts.surname}
                                    onChange={(e)=>changeContacts('surname',e.target.value)}
                                    label='Прізвище'
                                    />
                    </span>
                    <span>
                    <InputTextLabel
                                    value={contacts.phone}
                                    onChange={(e)=>changeContacts('phone',e.target.value)}
                                    label='Номер телефону'
                                    />
                    </span>
                    <span>
                    <InputTextLabel
                                    value={contacts.mail}
                                    onChange={(e)=>changeContacts('mail',e.target.value)}
                                    label='Електронна пошта'
                                    />
                    </span>
                </div>
                <span className="title-contacts">
                    Доставка
                    </span>
                <div className="delivery-details">
                    <form action="" className='margin-bottom-class'>
                        <input type="radio" 
                            value = 'selfTernopil'
                            name="selfTakeTernolip" 
                            onChange={changeradioState}
                            checked={radioState === 'selfTernopil'}/>
                        <label for="contactChoice1">Самовивіз з Тернополя</label>

                        <br />
                        <div className='hidden-delivery-block' style={{display: radioState === 'selfTernopil'?'block':'none'}} > 
                            Менеджер звяжиться для уточнення замовлення
                           
                        </div>
                        <input type="radio" 
                            value = 'selfNova'
                            name="selfNova" 
                            onChange={changeradioState}
                            checked={radioState === 'selfNova'}
                            />
                        <label for="contactChoice1">Самовивіз з Нової пошти</label>

                        <br />
                        <div className='hidden-delivery-block' style={{display: radioState === 'selfNova'?'grid':'none'}} > 
                            
                        <AutocompleteInput
                                options={cities}
                                hasError={true}
                                title={'Вкажіть населений пункт України'}
                            />
                        <AutocompleteInput
                            options={['asd','dsa','dsad']}
                            hasError={true}
                            title={'Виберіть відповідне відділення'}
                        />
                        </div>
                        <input type="radio" 
                            value = 'selfUkr'
                            name="selfUkr" 
                            onChange={changeradioState}
                            checked={radioState === 'selfUkr'}
                            />
                        <label for="contactChoice1">Самовивіз з Укрпошти</label>

                        <br />
                        <div className='hidden-delivery-block' style={{display: radioState === 'selfUkr'?'grid':'none'}} > 
                            
                        <AutocompleteInput
                                options={cities}
                                hasError={true}
                                title={'Вкажіть населений пункт України'}
                            />
                        <AutocompleteInput
                            options={['asd','dsa','dsad']}
                            hasError={true}
                            title={'Виберіть відповідне відділення'}
                            />
                        </div>
                        <input type="radio" 
                            value = 'courerNova'
                            name="courerNova" 
                            onChange={changeradioState}
                            checked={radioState === 'courerNova'}
                            />
                        <label for="contactChoice1">Кур’єр Нової пошти</label>

                        <br />
                        <div className='hidden-delivery-block' style={{display: radioState === 'courerNova'?'block':'none'}} > 
                            
                        <AutocompleteInput
                                options={cities}
                                hasError={true}
                                title={'Вкажіть населений пункт України'}
                            />
                            <div className='second-line-delivery-block'>
                                <InputTextLabel
                                    value={deliveryOptions[2].street}
                                    label='Вулиця'
                                    onChange={(e)=>changeDeliveryOptions(2,'street',e.target.value)}
                                />
                                 <InputTextLabel
                                    value={deliveryOptions[2].house}
                                    label='Будинок'
                                    onChange={(e)=>changeDeliveryOptions(2,'house',e.target.value)}
                                />
                                 <InputTextLabel
                                    value={deliveryOptions[2].number}
                                    label='Вулиця'
                                    onChange={(e)=>changeDeliveryOptions(2,'number',e.target.value)}
                                />
                            </div>
                        </div>
                        <input type="radio" 
                            value = 'courerUkr'
                            name="courerUkr" 
                            onChange={changeradioState}
                            checked={radioState === 'courerUkr'}
                            />
                        <label for="contactChoice1">Кур’єр Укрпошти</label>
                        <br />
                        <div className='hidden-delivery-block' style={{display: radioState === 'courerUkr'?'block':'none'}} > 
                            
                            <AutocompleteInput
                                options={cities}
                                hasError={true}
                                title={'Вкажіть населений пункт України'}
                            />
                            <div className='second-line-delivery-block'>
                                <InputTextLabel
                                    value={deliveryOptions[3].street}
                                    label='Вулиця'
                                    onChange={(e)=>changeDeliveryOptions(3,'street',e.target.value)}
                                />
                                 <InputTextLabel
                                    value={deliveryOptions[3].house}
                                    label='Будинок'
                                    onChange={(e)=>changeDeliveryOptions(3,'house',e.target.value)}
                                />
                                 <InputTextLabel
                                    value={deliveryOptions[3].number}
                                    label='Вулиця'
                                    onChange={(e)=>changeDeliveryOptions(3,'number',e.target.value)}
                                />
                            </div>
                        </div>
                </form>
                <span className="title-contacts margin-top-class">
                    Оплата
                    </span>
                    <form action="" className='payment-form margin-bottom-class'>
                        <input type="radio" 
                            value = 'onTake'
                            name="onTake" 
                            onChange={changepaymetRadioState}
                            checked={paymetRadioState === 'onTake'}/>
                        <label for="onTake">Оплата при отриманні</label>

                        <br />
                        <input type="radio" 
                            value = 'online'
                            name="online" 
                            onChange={changepaymetRadioState}
                            checked={paymetRadioState === 'online'}/>
                        <label for="online">Картою онлайн</label>
                    </form>
                    <span className="title-contacts margin-top-class">
                        Коментарі до замовлення
                    </span>
                    <div className='last-text-area'>
                        <InputTextArea
                        value={textArea}
                        onChange={(e)=>setTextArea(e.target.value)}
                        title=''
                        error=''
                        
                        />
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AddEditOderPage;