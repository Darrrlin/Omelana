import CategoryPage from "./result/";

export {
    CategoryPage
}