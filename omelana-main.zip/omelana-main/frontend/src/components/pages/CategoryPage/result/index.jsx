import React, {useEffect, useState} from 'react';
import Table from "../../../ui/tables/orderTable";

import '../css'

import CopyImage from '../../../media/images/copy-icon.png';
import EditImage from '../../../media/images/edit-icon.png';
import DeleteImage from '../../../media/images/delete-icon.png';
import TitleTablePage from "../../../ui/TitleTablePage";
import InputSearch from "../../../ui/Inputs/InputSearch";
import SelectUI from "../../../ui/selects/SelectUI";
import MoreIcons from "../../../ui/icons/MoreIcons";
import {MobileContextMenu} from "../../../widgets/MobileContextMenu";
import {Pagination} from "../../../ui/pagintaion";
import {defaultPrevUrl} from "../../../processes/routing";
import {useCopyCategoryMutation, useGetCategoriesMutation, useRemoveCategoryMutation} from '../../../processes/category'
import {useNavigate} from "react-router-dom";
import LeftArrowIcon from "../../../ui/icons/LeftArrowIcon";

const stateCategoryList = ["від найбільшого до найменшого", "від найменшого до найбільшого"];

const TableProductsPage = ({openMenu}) => {
    const navigate = useNavigate();
    const [getCategories, {isLoading}] = useGetCategoriesMutation();
    const [removeCategories, {isRemoved}] = useRemoveCategoryMutation();
    const [copyCategories, {isCopied}] = useCopyCategoryMutation();
    const [staticData, setStaticData] = useState([])

    const selectAll = () => {
        let customData = data.map((element, index) => {
            return {...element, isSelected: !head.isSelectAll}
        });

        if (!head.isSelectAll) {
            setListSelected(data.map((_val, _index) => _index));
        } else {
            setListSelected([])
        }

        setData([...customData]);
        setHead({...head, isSelectAll: !head.isSelectAll})
    }

    function compare(a, b) {
        if (a.counts < b.counts) {
            return -1;
        }
        if (a.counts > b.counts) {
            return 1;
        }
        return 0;
    }

    // [<SelectButton 'Назва товару', 'Категорія', 'Ціна', 'Статус', 'Дата редагування']
    const [head, setHead] = useState({
        //My work
        //Select all0.5
        //Select one1
        //get request
        //pagiantion
        //remove
        //open category
        //sort
        //filter
        //removed checked
        //clear select
        isSelectAll: false,
        optionsHeader: [
            {title: "Назва категорії", keyData: "name", width: "19.16vw", widthTablet: "31.77vw", widthMobile: ""},
            {title: "Кількість товарів", keyData: "counts", width: "19.16vw", widthTablet: "23.82vw", widthMobile: ""},
            {title: "Дата редагування", keyData: "date", width: "10.06vw", widthTablet: "16.53vw", widthMobile: ""},
        ]
    });

    const removeCategory = async (e, index) => {
        await removeCategories(data[index]['id']).unwrap();
        setData([...data.filter((value, _index) => {
            return _index !== index
        })])
    };

    const underDataButtons = [
        {
            action: (e, index) => copyCategory(index),
            color: '#0064E5',
            iconSrc: CopyImage,
            iconStyle: {'width': '24px', 'height': '24px'},
            title: "Копіювати"
        },
        {
            action: removeCategory,
            color: '#EB5757',
            iconSrc: DeleteImage,
            iconStyle: {'width': '24px', 'height': '24px'},
            title: "Видалити"
        },
        {
            action: (e, index) => editCategory(index),
            color: '#51B960',
            iconSrc: EditImage,
            iconStyle: {'width': '24px', 'height': '24px'},
            title: "Редагувати"
        }
    ];


    const [data, setData] = useState([]);

    const [listSelected, setListSelected] = useState([]);
    const [isOpenContextMenu, setIsOpenContextMenu] = useState(-1);
    const [globalContextMenu, setGlobalContextMenu] = useState(false);

    const [page, setPage] = useState(1);
    const [maxPage, setMaxPage] = useState(1);
    const [filterData, setFilterData] = useState({
        search: "",
        otherFilter: [-1]
    });

    const copyCategory = async (index) => {
        const response = await copyCategories(data[index].id).unwrap();
        setData([...data, {...data[index], id: response.id}])
    }


    const editCategory = (index) => {
        return navigate(defaultPrevUrl + `category/${data[index].id}/`);
    }

    const actionSearch = () => {
        if (filterData.search === "") {
            dataLoad();
        } else {
            let queryData = [...staticData];
            let searchingData = []
            queryData.map((element, index) => {
                if (String(element.name).toLowerCase().includes(String(filterData.search).toLowerCase())) {
                    searchingData.push(element)
                }
            })
            setData(searchingData);
        }
        setListSelected([]);

    }
    const setStatusDelete = async () => {
        let deleteElement = []
        data.map(async (element, index) => {
            if (element.isSelected) {
                deleteElement.push(element.id);
            }
        });
        await removeCategories(deleteElement.join(",")).unwrap();
        setListSelected([])
        setHead({...head, isSelectAll: false});
        setData([...data.filter((_val) => _val.isSelected !== true)]);
    }


    const clearSelectedElement = () => {
        setData([...data.map((_val, _index) => ({..._val, isSelected: false}))])
    }
    const dataLoad = async () => {
        let dataTemp = [];
        const requestData = await getCategories().unwrap();
        requestData.map((element, index) => {
            dataTemp.push({
                isSelected: false,
                id: element['id'],
                name: element['title'],
                counts: element['count'],
                date: element['created'].split("T")[0]
            });
        })
        setData([...dataTemp]);
        setStaticData(dataTemp);
        setListSelected([]);
    }

    useEffect(() => {
        dataLoad();

        window.addEventListener('click', (e) => {
            setGlobalContextMenu(false);
        });
    }, []);

    return (
        <div className="page-category-table">
            <TitleTablePage
                actionIcon={openMenu}
                title="Категорії"
                actionMainButton={() => navigate(defaultPrevUrl + 'category/create')}
            >
                Додати категорію
            </TitleTablePage>
            <div className="content-page-block">
                <div className="filter-form">
                    <div className="search-form">
                        <InputSearch
                            desktop="Пошук за Назвою категорії"
                            phone="Пошук"
                            actionSearch={actionSearch}
                            state={filterData.search}
                            setState={(e) => setFilterData({...filterData, search: e})}
                        />
                    </div>
                    <div className="select-state-form">
                        <SelectUI
                            defaultTitle="Сортувати за кількістю товару"
                            option={stateCategoryList.map((element, index) => {
                                return {text: element}
                            })}
                            state={filterData.otherFilter[0]}
                            setState={(index) => {
                                setListSelected([]);
                                let list = filterData.otherFilter;
                                list[0] = index;
                                setFilterData({...filterData, otherFilter: list});
                                if (filterData.otherFilter[0] === 0) {
                                    setData(data.sort(compare))
                                } else {
                                    setData(data.sort(compare).reverse())
                                }
                            }}
                        />
                    </div>
                    <div className="more-form" onClick={(e) => {
                        e.stopPropagation();
                        e.preventDefault();
                    }}>
                        <MoreIcons className="more-icon" onClick={() => setGlobalContextMenu(!globalContextMenu)}/>
                        <div
                            className={`context-menu-global ${globalContextMenu ? "open" : ""}`}
                        >
                            <div className="context-menu-global-action" onClick={setStatusDelete}>
                                Видалити
                            </div>
                        </div>
                    </div>
                    <div className={`mobile-selected-element ${listSelected.length > 0 ? "selected-element" : ""}`}>
                        <LeftArrowIcon className="left-arrow-icon" onClick={clearSelectedElement}/>
                        <div className="counts-selected-element">{listSelected.length}</div>
                        <MoreIcons className="more-icon" onClick={() => setGlobalContextMenu(!globalContextMenu)}/>
                    </div>
                </div>
                <Table
                    selectElement={(index) => {
                        let dataArray = [...data];
                        dataArray[index].isSelected = !dataArray[index].isSelected;
                        setData(dataArray);
                        let value = dataArray.reduce((accumulator, currentValue) => accumulator + currentValue.isSelected, 0);
                        if (value === dataArray.length) {
                            setHead({...head, isSelectAll: true});
                        } else {
                            setHead({...head, isSelectAll: false});
                        }

                        if (dataArray[index].isSelected) {
                            setListSelected([...listSelected.filter((_val) => _val !== index)])
                        } else {
                            setListSelected([...listSelected, index]);
                        }
                    }}
                    head={head}
                    data={data}
                    uniteTablet={[-1]}
                    uniteMobile={{right: [[0, ""], [1, "Кількість товари :"],], left: [2,]}}
                    greenState='is'
                    blueState='inprocess'
                    redState='not-is'
                    greyState='delete'
                    greenTitle='В няавності'
                    blueTitle='В процесі'
                    redTitle='Немає'
                    greyTitle='Видалений'
                    underDataButtons={underDataButtons}
                    blockWidth={72}
                    isOpenContextMenu={isOpenContextMenu}
                    setIsOpenContextMenu={(index) => setIsOpenContextMenu(index)}
                    onClickElement={() => {
                    }}
                    selectAll={selectAll}
                />
            </div>
            <Pagination page={page} setPage={setPage} maxPage={maxPage}/>
            <MobileContextMenu
                isOpenContextMenu={globalContextMenu}
                setIsOpenContextMenu={setGlobalContextMenu}
                actionList={[
                    {action: setStatusDelete, title: "Видалити"},
                ]}
            />

        </div>
    );
};

export default TableProductsPage;