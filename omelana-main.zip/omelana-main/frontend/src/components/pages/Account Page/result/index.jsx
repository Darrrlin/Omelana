import React, {useState} from 'react';
import MenuIcon from "@mui/icons-material/Menu";
import {IconButton} from "@mui/material";

import '../css'
import {ModalChangePassword} from "../../../widgets/ModalChangePassword";
import {logOut, useChangePasswordMutation, useLogoutAllMutation, useLogoutMutation} from "../../../processes/auth";
import {useDispatch} from "react-redux";

const AccountPage = ({openMenu}) => {
    const [isModal, setIsModal] = useState(false);
    const [changePasswordData, {isLoadingChangePassword}] = useChangePasswordMutation();
    const [logoutData, {isLoadingLogout}] = useLogoutMutation();
    const [logOutAllData, {isLoadingLogoutAll}] = useLogoutAllMutation();
    const dispatch = useDispatch()

    const [modalData, setModalData] = useState({
        current: "",
        'new': "",
        confirm: "",
        currentError: "",
        newError: "",
        confirmError: ""
    });

    const savePassword = async (e) => {
        e.preventDefault();
        let checkValidate = true,
            dataError = {};

        if (modalData.confirm !== modalData.new) {
            checkValidate = false;
            dataError.confirmError = "Паролі не збігаються!";
        }

        if (!/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z]{8,}$/.test(modalData.new)) {
            checkValidate = false;
            dataError.newError = "Пароль повинен складатися з 8 символів, 1 цифри, 1 великої літери, 1 маленької літери";
        }

        if (checkValidate) {
            try {
                const userData = await changePasswordData({
                    oldPassword: modalData.current,
                    newPassword: modalData.new
                }).unwrap();
                dispatch(logOut(userData));

            } catch (e) {
                console.log(e)
                setModalData({...modalData, currentError: "Невірний пароль"})
            }

        } else {
            setModalData({...modalData, ...dataError});
        }
    }

    const logOutAllHandler = async (event) => {
        event.preventDefault()

        try {
            const userData = await logOutAllData().unwrap();
            dispatch(logOut(userData))
        } catch (err) {
            console.log(err)
        }
    }

    const logOutHandler = async (event) => {
        event.preventDefault()

        try {
            const userData = await logoutData().unwrap();
            dispatch(logOut(userData))
        } catch (err) {
            console.log(err)
        }
    }

    return (
        <div className="account-page">
            <div className="title-bar">
                <IconButton className="hamburger-menu-button" onClick={openMenu}>
                    <MenuIcon className="hamburger-menu-icon"/>
                </IconButton>
                <div className="title-test">Особистий профіль</div>
            </div>
            <div className="content-page">
                <div className="title-content">
                    Особисті дані
                </div>
                <div className="content-data">
                    <div className="name">
                        <div className="data-block">
                            <div className="name-data">Ім’я</div>
                            <div className="value-data">Віра</div>
                        </div>
                        <div className="data-block">
                            <div className="name-data">Прізвище</div>
                            <div className="value-data">Віра</div>
                        </div>

                    </div>
                    <div className="data-block">
                        <div className="name-data">Логін</div>
                        <div className="value-data">hello@omelyana.com</div>
                    </div>
                    <div className="active-group">
                        <div className="active" onClick={() => setIsModal(true)}>Змінити пароль</div>
                        <div className="active warning" onClick={logOutAllHandler}>Вийти зі всіх пристроїв</div>
                        <div className="active warning" onClick={logOutHandler}>Вийти</div>
                    </div>
                </div>
            </div>
            <ModalChangePassword
                data={modalData}
                setData={setModalData}
                isOpen={isModal}
                setIsOpen={setIsModal}
                savePassword={savePassword}
            />
        </div>
    );
};

export default AccountPage;