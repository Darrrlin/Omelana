import React, {useState, useEffect} from "react";
import OrderMainWidget from '../../../widgets/OrderMainWidget';
import Table from '../../../ui/tables/orderTable';
import {useRemoveOrderMutation, 
    useUpdateOrderMutation, 
    useGetOrderMutation, 
    useGetOrdersMutation,
    useChangeStatusOrdersMutation} from "../../../processes/orders"
import {useNavigate, useParams} from "react-router-dom";


function OrderPage({openMenu}) {
    const [getOrders, {isLoading}] = useGetOrdersMutation();
    const [removeOrder, {isRemoved}] = useRemoveOrderMutation();
    const [ChangeStatus, {isChanging}] = useChangeStatusOrdersMutation();
    const [data, setData] = useState([]);   
    const navigate = useNavigate();
   
    useEffect(()=>{
        dataLoad();
    },[])

    const [head, setHead] = useState({
        isSelectAll: false,
        optionsHeader: [
            {title: "№", keyData: "id", width: "7.63vw", widthTablet: "7.94vw", widthMobile: ""},
            {title: "Клієнт", keyData: "client", width: "18.33vw", widthTablet: "23.82vw", widthMobile: ""},
            {title: "Номер телефону", keyData: "phone", width: "11.8vw", widthTablet: "", widthMobile: ""},
            {title: "Сума", keyData: "sum", width: "5.13vw", widthTablet: "15.88vw", widthMobile: ""},
            {title: "Статус", keyData: "status", width: "12.7vw", widthTablet: "15.88vw", widthMobile: ""},
            {title: "Дата", keyData: "date", width: "6.94vw", widthTablet: "8.46vw", widthMobile: ""},
        ]
    });

    const dataLoad = async () =>{
        let dataTemp = [];
        const requestdata = await getOrders().unwrap();
        requestdata.map((element,index)=>{
            var sumOrder = 0;
            element["items"].map((value,index)=>{
                sumOrder = sumOrder + value["price"]
            })
            dataTemp.push({
                isSelected: false,
                id:element['id'],
                client: element['first_name'] +" " + element['second_name'],
                phone: element["phone_number"],
                sum: sumOrder,
                status: element["status"] == 1 ? "open" : element["status"] == 2 ? "inprocess" : element["status"] == 3 ? "close" : "remove",
                date: element["created"].split('T')[0],
            });
        })
        setData(dataTemp);
    }
    
    const underDataButtons = [
        {
            action: (i, index) => changeToReaded(index),
            color: 'red',
            iconSrc: "https://cdn-icons-png.flaticon.com/128/3156/3156999.png",
            iconStyle: {width: '30px'},
            title: "Позначити як \"Прочитано\""
        },
        {
            action: (i, index) => changeToProgress(index),
            color: 'red',
            iconSrc: "https://cdn-icons-png.flaticon.com/128/3156/3156999.png",
            iconStyle: {width: '30px'},
            title: "Позначити як \"В процесі\""
        },
        {
            action: (i, index) => changeToComplete(index),
            color: 'red',
            iconSrc: "https://cdn-icons-png.flaticon.com/128/3156/3156999.png",
            iconStyle: {width: '30px'},
            title: "Позначити як \"Виконано\""
        },

        {
            action: (i, index) => changeToRemooved(index),
            color: 'red',
            iconSrc: "https://cdn-icons-png.flaticon.com/128/3156/3156999.png",
            iconStyle: {width: '30px'},
            title: "Видалити"
        }
    ];

    const [listSelected, setListSelected] = useState([]);
    const [isOpenContextMenu, setIsOpenContextMenu] = useState(-1);

    const openOrder = (index) => {
    }

    const returnSelectedList = ()=>{
        let sendList = [];
        data.map((value,index)=>{
            if(value.isSelected===true){
                sendList.push(value.id);
            }
            
        })
        return sendList;
    }

    const changeToReaded = async(index)=>{
        let sendList = []
        if(index){
            sendList = [data[index]['id']]
        }
        else{
            sendList =returnSelectedList();
        }
        const formData = new FormData();
        formData.append("type_method",'setReading');
        formData.append("ids",sendList.join(","));
        await ChangeStatus(formData).unwrap();
        dataLoad();
    }
    function compareState( a, b ) {
        if ( a.status < b.status ){
          return -1;
        }
        if ( a.status > b.status ){
          return 1;
        }
        return 0;
      }
      function compareDate( a, b ) {
        if ( a.created < b.created ){
          return -1;
        }
        if ( a.created > b.created ){
          return 1;
        }
        return 0;
      }
      

    const changeToComplete = async(index)=>{
        let sendList = []
        if(index){
            sendList = [data[index]['id']]
        }
        else{
            sendList =returnSelectedList();
        }
        const formData = new FormData();
        formData.append("type_method",'setComplete');
        formData.append("ids",sendList.join(","));
        await ChangeStatus(formData).unwrap();
        dataLoad();
    }

    const changeToProgress = async(index)=>{
        let sendList = []
        if(index){
            sendList = [data[index]['id']]
        }
        else{
            sendList =returnSelectedList();
        }
        const formData = new FormData();
        formData.append("type_method",'setProces');
        formData.append("ids",sendList.join(","));
        await ChangeStatus(formData).unwrap();
        dataLoad();
    }

    const changeToRemooved = async(index)=>{
        let sendList = []
        if(index){
            sendList = [data[index]['id']]
        }
        else{
            sendList =returnSelectedList();
        }
        const formData = new FormData();
        formData.append("type_method",'setRemoved');
        formData.append("ids",sendList.join(","));
        await ChangeStatus(formData).unwrap();
        dataLoad();
    }

    const selectAll = () => {
        let customData = data.map((element, index) => {
            return {...element, isSelected: !head.isSelectAll}
        });

        if (!head.isSelectAll) {
            setListSelected(data.map((_val, _index) => _index));
        } else {
            setListSelected([])
        }

        setData([...customData]);
        setHead({...head, isSelectAll: !head.isSelectAll})

    }
    const [sortStateValue, setSortStateValue] = useState('');
    const [sortDateValue, setSortDateValue] = useState('');

    useEffect(()=>{
        if(
            sortStateValue === 0
        ){
            setData([...data.sort(compareState)])
        }else{
            setData([...data.sort().reverse()])
        }
        
    },[sortStateValue])

    useEffect(()=>{
        if(
            sortStateValue === 0
        ){
            setData([...data.sort(compareDate)])
        }else{
            setData([...data.sort(compareDate).reverse()])
        }
        
    },[sortDateValue])
    const openAddPage =()=>{
        return navigate(defaultPrevUrl + `AddEditOderPages`);
    }
    return (
        <div>
            <OrderMainWidget
            buttonNum={openAddPage}
            openMenu={openMenu}
            sortStateValue={sortStateValue}
            setSortStateValue={setSortStateValue}
            sortDateValue={sortDateValue}
            setSortDateValue={setSortDateValue}
            underDataButtons = {underDataButtons}/>
            <Table
                selectElement={(index) => {
                    let dataArray = [...data];
                    dataArray[index].isSelected = !dataArray[index].isSelected;
                    let value = dataArray.reduce((accumulator, currentValue) => accumulator + currentValue, 0)
                    if (value === dataArray.length || value === 0) {
                        setHead({...head, isSelectAll: !!value});
                    }
                    if (dataArray[index].isSelected) {
                        setListSelected([...listSelected.filter((_val) => _val !== index)])
                    } else {
                        setListSelected([...listSelected, index]);
                    }}}
                head={head}
                data={data}
                uniteTablet={[1, 2]}
                uniteMobile={{right: [[0, "Замовлення № "], [1, ""], [2, ""]], left: [4, 5]}}
                greenState='open'
                blueState='inprocess'
                redState='close'
                greyState='remove'
                greenTitle='Відкрите'
                blueTitle='В процесі'
                redTitle='Закрите'
                greyTitle='Видалене'
                underDataButtons={underDataButtons}
                blockWidth={100}
                isOpenContextMenu={isOpenContextMenu}
                setIsOpenContextMenu={(index) => setIsOpenContextMenu(index)}
                onClickElement={openOrder}
                selectAll={selectAll}
            />

        </div>
    )
}

export default OrderPage;