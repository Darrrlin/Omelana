import OrderPage from "./result";

export {
    OrderPage
}