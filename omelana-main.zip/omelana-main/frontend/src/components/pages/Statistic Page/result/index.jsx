import React,{useState} from 'react'
import {Line, Pie} from 'react-chartjs-2'
import { Chart } from 'chart.js/auto'
import '../css/index.css'
import Switcher from '../../../ui/switcher'

function StatisticPage(props){

    const DataUser = [
        {
            id:1,
            title:'Хустки',
            value:34
        },
        {
            id:2,
            title:'Шарфи',
            value:33
        },
        {
            id:3,
            title:'Палантини',
            value:33
        }
    ]

    const dataSecond = [
        {
            id:1,
            month:'Січень',
            value:76790
        },
        {
            id:2,
            month:'Лютий',
            value:72394
        },
        {
            id:3,
            month:'Березень',
            value:6790
        }
    ]

    const formatNumber = (number)=> {

        const thousands = Math.floor(number);
        const formattedNumber = thousands.toLocaleString();
        return `${formattedNumber} тис. грн`;
      }
          
          const [userData, setUserData] = useState(
            {
              labels: DataUser.map((e)=>e.title+ ' ' + e.value+'%'),
              datasets:[{
                label:'Відношення',
                data:DataUser.map((e)=>e.value),
                backgroundColor:['#3F0080','#974AD5','#D482FF']
              }]
            }
          )
      
          const [secondData, setSecondData] = useState(
            {
              labels: dataSecond.map((e)=>e.month),
              datasets:[{
                label:'Заробіток',
                lineTension: 0.5,
                data:dataSecond.map((e)=>e.value/1000),
                fill:true,
                borderColor: '#974AD5',
      
                
              }]
            }
          )
      
          const options = {
            responsive: true,
            maintainAspectRatio: false
            ,
            plugins: {
              legend: {
                position: 'right',
                labels: {
                    usePointStyle: true,
                  },
              },
              tooltip:{
                enabled:false
              }
            },
          }
          const options3 = {
            plugins: {
              legend: {
                position: 'bottom',
                labels: {
                    usePointStyle: true,
                  },
                  align:'center',
                  rtl:false
              },
              
              tooltip:{
                enabled:false
              }
            },
          }
          const options2 = {
        plugins: {
          tooltip: {
            backgroundColor:'#FFFFFF',
            titleColor:'#000000',
            callbacks:{
              title:function(context){
                let label =formatNumber(dataSecond[context[0].dataIndex].value)
                return label
              },
              label:function(){
                return ''
              }
            }
          },
          legend: {
            display: false, // Приховує легенду
          },
        },
        scales: {
          x: {
            grid: {
              display: false, // Приховує вертикальні лінії
            },
          },
          y: {
            beginAtZero: true,
            ticks: {
              callback: function (value) {
                return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',') + 'K';
              },
            },
          },
        },
      
      };
      
  /* Chart.register({
    id: 'customLine',
    afterDraw: function (chart, easing) {
        if (chart.tooltip._active && chart.tooltip._active.length && chart.id === 1) {
    
        const activePoint = chart.tooltip._active[0];
        const ctx = chart.ctx;
        const x = activePoint.element.x;
        const topY = activePoint.element.y;
        const bottomY = chart.chartArea.bottom;
    
        ctx.save();
        ctx.setLineDash([5, 5]); // Встановлюємо пунктирну шаблон лінії
        ctx.beginPath();
        ctx.moveTo(x, topY);
        ctx.lineTo(x, bottomY);
        ctx.lineWidth = 1;
        ctx.strokeStyle = '#974AD5';
        ctx.stroke();
        ctx.restore();
        }
    }
    });*/

    const months = [
        'Січень',
        'Лютий',
        'Березень',
        'Квітень',
        'Травень',
        'Червень',
        'Липень',
        'Серпень',
        'Вересень',
        'Жовтень',
        'Листопад',
        'Грудень'
]


    const years = [
        '2023',
        '2024',
        '2025',
    ]
    const data={
        earn:45700000,
        earnDifference:24,
        ordersCount:230,
        ordersDifference:-9
    }
    const [checkedMonth, setCheckedMonth] = useState(new Date().getMonth());
    const [checkedSecondMonth, setCheckedSecondMonth] = useState(new Date().getMonth());
    const [checkedThirdMonth, setCheckedThirdMonth] = useState(new Date().getMonth());
    const [checkedYear, setCheckedYear] = useState(0);
      const firstDiagram = {
        labels: [
          'Red',
          'Blue',
          'Yellow'
        ],
        datasets: [{
          label: 'My First Dataset',
          data: [300, 50, 100],
          backgroundColor: [
            'rgb(255, 99, 132)',
            'rgb(54, 162, 235)',
            'rgb(255, 205, 86)'
          ],
          hoverOffset: 4
        }]
      };
      const topProducts = [
        {
            id:1,
            title:'Хустка червона',
            count:146
        },
        {
            id:2,
            title:'Шарф зимовий з візерунком',
            count:145
        },
        {
            id:3,
            title:'Хустка червона',
            count:144
        },
        {
            id:4,
            title:'Хустка червона',
            count:143
        },
        {
            id:5,
            title:'Хустка червона',
            count:142
        },
        {
            id:6,
            title:'Хустка червона',
            count:141
        },
      ]
      const topClients=[
        {
            id:1,
            name:'Кучеренко Тетяна',
            contacts:[
                '+38 (098) 765 43 21','uakutanya@gmail.com'
            ],
            count:3,
            sum:659
        },
        {
            id:2,
            name:'Кучеренко Тетяна',
            contacts:[
                '+38 (098) 765 43 21','uakutanya@gmail.com'
            ],
            count:3,
            sum:659
        },
        {
            id:3,
            name:'Кучеренко Тетяна',
            contacts:[
                '+38 (098) 765 43 21','uakutanya@gmail.com'
            ],
            count:3,
            sum:659
        },
        {
            id:4,
            name:'Кучеренко Тетяна',
            contacts:[
                '+38 (098) 765 43 21','uakutanya@gmail.com'
            ],
            count:3,
            sum:659
        },
        {
            id:5,
            name:'Кучеренко Тетяна',
            contacts:[
                '+38 (098) 765 43 21','uakutanya@gmail.com'
            ],
            count:3,
            sum:659
        },
      ]

    return(
        <div>
            
            <div className='statistic-div'>
            <Switcher
                    data={months}
                    index={checkedMonth}
                    setValue={setCheckedMonth}
                />
            <div className='inside-container'>
                <div className="inside-div">
                    Зароблено
                    <div className="key-text">
                        {
                        formatNumber(data.earn)
                        }
                    </div>
                        

                    {data.earnDifference >=0
                     ?
                      <span>
                        +
                      </span> : 
                      <span>
                        -
                      </span> } {data.earnDifference} з минулого місяця
                </div>
                <div className="inside-div">
                    Кількість замовлень
                    <div className="key-text">
                        {data.ordersCount}
                    </div>
                    {data.ordersDifference >=0
                     ?
                      <span>
                        +
                      </span> : 
                      <span>
                        -
                      </span> } {Math.abs(data.ordersDifference)} з минулого місяця
                </div>
                <div className="inside-div">
                    Продажі за категоріями
                    <Pie
                    data={userData}
                    options={options}

      />
                </div>

            </div>
            
            </div>
            <div className="second-line-div">
                <div className='inside-div second-line-inside-div key-text ' id='phone-100'>
                  <div className='text-with-switcher'>
                  Прибуток&nbsp;
                  <Switcher
                      data={years}
                      index={checkedYear}
                      setValue={setCheckedYear}
                  />
                </div>
                    <Line
                    id={'first'}
                    data={secondData}
                    options={options2}
      />
                </div>
                <div className='inside-div second-line-inside-div phone-hidden-class'>
                    <div>
                        <span className="title-statistic">
                            Топ товарів
                        </span>
                       
                    </div>
                <Switcher
                    data={months}
                    index={checkedSecondMonth}
                    setValue={setCheckedSecondMonth}
                    fontSize='1.1vw'
                /> 
                <div className='right-statistic-block'>
                    <table className='aside-table'>
                      <tbody>
                        <tr className=' aside-table-header'>
                            <th>№</th>
                            <th>Товар</th>
                            <th>Продано шт.</th>
                        </tr>
                        {topProducts.map((product, index)=>(
                            <tr className='aside-table' key={index}>
                                <th>
                                    <span className={`${index+1 < 4 ? 'aside-table-number-fill' : 'aside-table-number-not-fill'}`}>
                                        {index+1}
                                    </span>
                                </th>
                                <th>{product.title}</th>
                                <th>{product.count}</th>
                            </tr>
                        ))}
                        </tbody>
                    </table>
                </div>
                </div>
            </div>
            <div className="second-line-div phone-hidden-class">
            <div className='inside-div second-line-inside-div header-text-statistic phone-hidden-class'>
                <span className='title-statistic'>
                Топ клієнтів
                </span>
            <table className='aside-table'>
              <tbody>
                        <tr className=' aside-table-header'>
                            <th>№</th>
                            <th>Клієнт</th>
                            <th>Контакти</th>
                            <th>Кількість замовлень</th>
                            <th>Сума</th>
                        </tr>
                        {topClients.map((client, index)=>(
                            <tr className='aside-table' key={index}>
                                <th>
                                    <span className={`${index+1 < 4 ? 'aside-table-number-fill' : 'aside-table-number-not-fill'}`}>
                                        {index+1}
                                    </span>
                                </th>
                                <th>{client.name}</th>
                                <th>
                                    {client.contacts.map((contact)=>
                                    <div key={contact}>{contact}</div>
                                    )}
                                </th>
                                <th>{client.count}</th>
                                <th>{client.sum}</th>
                            </tr>
                        ))}
                        </tbody>
                    </table>
            </div> 
            <div className='inside-div second-line-inside-div'>
            <span className='title-statistic'>
                Топ категорій
                <Switcher
                    data={months}
                    index={checkedThirdMonth}
                    setValue={setCheckedThirdMonth}
                    fontSize='1.1vw'
                /> 
                </span>
                
                <Pie
                    data={userData}
                    options={options3}
                />
                </div>
            </div>
            <div className='desctop-hidden-class'>
            <div className='inside-div second-line-inside-div '>
                    <div>
                        <span className="title-statistic">
                            Топ товарів
                        </span>
                       
                    </div>
                <Switcher
                    data={months}
                    index={checkedSecondMonth}
                    setValue={setCheckedSecondMonth}

                /> 
                <div className='right-statistic-block'>
                    <table className='aside-table'>
                    <tbody>
                        <tr className=' aside-table-header'>
                            <th>№</th>
                            <th>Товар</th>
                            <th>Продано шт.</th>
                        </tr>
                        {topProducts.map((product, index)=>(
                            <tr className='aside-table' key={index}>
                                <th>
                                    <span className={`${index+1 < 4 ? 'aside-table-number-fill' : 'aside-table-number-not-fill'}`}>
                                        {index+1}
                                    </span>
                                </th>
                                <th className='phone-text-left'>{product.title}</th>
                                <th>{product.count}</th>
                            </tr>
                        ))}
                        </tbody>
                    </table>
                </div>
                </div>
                <div className='inside-div second-line-inside-div' id='phone-half-block'>
                <span className='title-statistic'>
                  Топ категорій
                  <Switcher
                      data={months}
                      index={checkedThirdMonth}
                      setValue={setCheckedThirdMonth}
                  /> 
                </span>
                <Pie
                    data={userData}
                    options={options3}
                />
                </div>
            </div>
            <div className='inside-div second-line-inside-div header-text-statistic phone-hidden-class tablet-visibyl'>
                <span className='title-statistic'>
                Топ клієнтів
                </span>
            <table className='aside-table'>
              <tbody>
                        <tr className=' aside-table-header last-tablet-table'>
                            <th>№</th>
                            <th>Клієнт</th>
                            <th>Контакти</th>
                            <th>Кількість замовлень</th>
                            <th>Сума</th>
                        </tr>
                        {topClients.map((client, index)=>(
                            <tr className='aside-table last-tablet-table' key={index}>
                                <th>
                                    <span className={`${index+1 < 4 ? 'aside-table-number-fill' : 'aside-table-number-not-fill'}`}>
                                        {index+1}
                                    </span>
                                </th>
                                <th>{client.name}</th>
                                <th>
                                    {client.contacts.map((contact)=>
                                    <div key={contact}>{contact}</div>
                                    )}
                                </th>
                                <th>{client.count}</th>
                                <th>{client.sum}</th>
                            </tr>
                        ))}
                        </tbody>
                    </table>
                    
            </div> 
            <div className='inside-div second-line-inside-div header-text-statistic phone-vis' id='last-block-phone'>
                <span className='title-statistic'>
                Топ клієнтів
                </span>
            <table className='aside-table'>
              <tbody>
                        <tr className=' aside-table-header'>
                            <th>№</th>
                            <th>Клієнт</th>
                            <th>Контакти</th>
                            <th>Кількість замовлень</th>
                            <th>Сума</th>
                        </tr>
                        {topClients.map((client, index)=>(
                            <tr className='aside-table' key={index}>
                                <th>
                                    <span className={`${index+1 < 4 ? 'aside-table-number-fill' : 'aside-table-number-not-fill'}`}>
                                        {index+1}
                                    </span>
                                </th>
                                <th>{client.name}</th>
                                <th>
                                    {client.contacts.map((contact)=>
                                    <div key={contact}>{contact}</div>
                                    )}
                                </th>
                                <th>{client.count}</th>
                                <th>{client.sum}</th>
                            </tr>
                        ))}
                        </tbody>
                    </table>
            </div> 
        </div>
    )
}
export default StatisticPage;