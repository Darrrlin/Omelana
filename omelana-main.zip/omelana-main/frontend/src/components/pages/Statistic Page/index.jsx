import StatisticPage from "./result";

export {
    StatisticPage
}