import React, {useEffect, useState} from 'react';
import PropertyCategoryWidget from "../../../widgets/PropertyCategoryWidget";
import TitleSinglePage from "../../../ui/TitleSinglePage";
import {defaultPrevUrl} from "../../../processes/routing";
import InputTextLabel from "../../../ui/Inputs/InputTestLabel";

import '../css';
import PlusIcon from "../../../ui/icons/PlusIcon";
import {useGetCategoryMutation, useUpdateCategoryMutation} from "../../../processes/category";
import {useNavigate, useParams} from "react-router-dom";
import {MobileContextMenu} from "../../../widgets/MobileContextMenu";
import OneImage from "../../../ui/image/OneImage/result";
import {ModalCheckSaveWidget} from "../../../widgets/ModalCheckSaveWidget";

const ChangeCategoryPage = ({openMenu}) => {
    const [nameCategory, setNameCategory] = useState("");
    const [errorName, setErrorName] = useState("");
    const [listProperties, setListProperties] = useState([]);
    const [isOpenContextMenu, setIsOpenContextMenu] = useState(false);
    const [indexContextMenu, setIndexContextMenu] = useState(-1);
    const [updateCategory, {isLoadingUpdate}] = useUpdateCategoryMutation();
    const [getCategory, {isLoading}] = useGetCategoryMutation();
    const navigate = useNavigate()
    let {id} = useParams();
    const [imageUrl, setImageUrl] = useState(null);
    const [image, setImage] = useState(null);
    const [imageError, setImageError] = useState(false);
    const [isNewImage, setIsNewImage] = useState(false);
    const [condition, setCondition] = useState(true);

    useEffect(() => {
        window.addEventListener("click", (e) => {
            setIsOpenContextMenu(false);
        });
    }, []);

    useEffect(() => {
        const fetchData = async () => {
            const data = await getCategory(id).unwrap();
            setNameCategory(data.title);
            setImage(data.img_src);
            setImageUrl(data.img_src);
            let listDataProperties = [];
            for (const property of data.properties) {
                let newElement = {title: property.title, description: "", values: []}
                for (const propertyChooseElement of property.properties_choices) {
                    newElement.values.push(propertyChooseElement.title);
                }
                listDataProperties.push(newElement);
            }
            setListProperties(listDataProperties);
        }

        fetchData();
    }, [id])

    const checkValid = () => {
        let checkValidate = true;
        if (!nameCategory) {
            setErrorName("Введіть назву категорії")
            checkValidate = false;
        }

        for (const index in listProperties) {
            const element = listProperties[index];
            if (!element.title) {
                listProperties[index].errorName = "Введіть назву властивості";
                checkValidate = false;
            }
        }

        if (!image) {
            setImageError(true);
            checkValidate = false;
        }

        return checkValidate;
    }

    const generateFormData = () => {
        let listPropertiesData = [];
        for (const listPropertiesDataKey in listProperties) {
            listPropertiesData.push({})
            listPropertiesData[listPropertiesDataKey].title = listProperties[listPropertiesDataKey].title
            listPropertiesData[listPropertiesDataKey].description = listProperties[listPropertiesDataKey].description
            listPropertiesData[listPropertiesDataKey].values = listProperties[listPropertiesDataKey]
                .values
                .filter((element) => element !== "")
                .join(",");
        }

        let formData = new FormData();
        formData.append("id", `${id}`);
        formData.append("title", nameCategory);
        formData.append("description", "");
        formData.append("properties", JSON.stringify(listPropertiesData));
        if (isNewImage) {
            formData.append("is_new_image", "true");
            formData.append("image", image);
        }
        formData.append("type_methods", "UPDATE");
        return formData;
    }

    const saveCategory = async (event) => {
        let checkValidate = checkValid();

        if (checkValidate) {
            setCondition(true);
            const formData = generateFormData();
            try {
                await updateCategory(formData).unwrap();
            } catch (err) {
                setErrorName("Невірні дані!");
            }
        } else {
            setListProperties([...listProperties]);
        }
    }

    const copyProperties = (index) => {
        if (condition) {
            setCondition(false);
        }
        const oldElement = listProperties[index];
        const newElement = {...oldElement, values: [...oldElement.values]}
        setListProperties([...listProperties, newElement])
    }

    const deleteProperties = (index) => {
        if (condition) {
            setCondition(false);
        }
        setListProperties(listProperties.filter((_, i) => index !== i));
    }

    const addProperties = (event) => {
        if (condition) {
            setCondition(false);
        }
        setListProperties([...listProperties, {title: "", description: "", values: []}]);
    }

    const changeProperties = (index, namePropertyObject, value) => {
        if (condition) {
            setCondition(false);
        }
        listProperties[index][namePropertyObject] = value;
        setListProperties([...listProperties]);
    }

    const saveCategoryOnClose = async () => {
        let checkValidate = checkValid();

        if (checkValidate) {
            const formData = generateFormData();

            try {
                await updateCategory(formData).unwrap();
            } catch (err) {
            }
        }
    }

    return (
        <>
            <ModalCheckSaveWidget condition={condition} save={saveCategoryOnClose} />
            <TitleSinglePage
                tabletIcon="arrow"
                mobileIcon='arrow'
                actionIcon={openMenu}
                sectionTitle="Категорії"
                sectionPath={defaultPrevUrl + "category"}
                mainTitleName={nameCategory}
                mainTitle="Редагувати категорію"
                actionMainButton={saveCategory}
                styleClassMainButton={!listProperties.length ? "secondary" : "primary"}
            >
                Зберегти категорію
            </TitleSinglePage>
            <div className='page-category-edit'>
                <div className='head-title-section'>Інформація про категорію</div>
                <div className='form-section title'>
                    <InputTextLabel
                        value={nameCategory}
                        onChange={(e) => {
                            if (condition) {
                                setCondition(false);
                            }
                            setNameCategory(e.target.value);
                        }}
                        label='Назва'
                        prefixLabel="name-category"
                        errorText={errorName}
                    />
                    <OneImage
                        title="Фото"
                        width="max(183px, 12.7vw)"
                        height="max(194px, 13.47vw)"
                        imageUrl={imageUrl}
                        setImageUrl={(val) => {
                            if (condition) {
                                setCondition(false);
                            }
                            setImageUrl(val);
                        }}
                        setImage={(value) => {
                            if (condition) {
                                setCondition(false);
                            }
                            setImage(value);
                            setIsNewImage(true);
                        }}
                        error={imageError}
                        setError={setImageError}
                    />
                </div>
                <div className='head-title-section'>Властивості категорії</div>
                <div className="form-section">
                    {listProperties.map((property, index) =>
                        <PropertyCategoryWidget name={property.title}
                                                setName={(value) => changeProperties(index, "title", value)}
                                                isOpenContextMenu={isOpenContextMenu && indexContextMenu === index}
                                                setIsOpenContextMenu={(values) => {
                                                    setIndexContextMenu(index);
                                                    setIsOpenContextMenu(values);
                                                }}
                                                listValues={property.values}
                                                setListValues={(value) => changeProperties(index, "values", value)}
                                                actionCopy={() => copyProperties(index)}
                                                actionDelete={() => deleteProperties(index)}
                                                errorName={property.errorName}
                                                key={`new-category-property-${index}`}
                        />
                    )}
                    <div className="add-property" onClick={addProperties}>
                        <PlusIcon className="add-icon"/>
                        <span className="add-title">
                            Додати властивість
                        </span>
                    </div>
                </div>
            </div>

            <MobileContextMenu
                setIsOpenContextMenu={setIsOpenContextMenu}
                isOpenContextMenu={isOpenContextMenu}
                actionList={[
                    {title: "Створити копію", action: () => copyProperties(indexContextMenu)},
                    {title: "Видалити", action: () => deleteProperties(indexContextMenu)}
                ]}
            />
        </>
    );
};

export default ChangeCategoryPage;