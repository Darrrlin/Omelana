import ChangeCategoryPage from "./result";

export {
    ChangeCategoryPage
}