import UserAgreement from "./result";

export {
    UserAgreement}