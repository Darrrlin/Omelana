import CategorySettings from "./result";

export {
    CategorySettings
}