import React, {useState, useEffect} from 'react';
import '../css/index.css'
import Button from '../../../../ui/buttons/SettingsButton/index'
import {useUpdateSettingsMutation, useGetSettingsMutation} from '../../../../processes/settings';

function CategorySettings(props){
    const [Block, setBlock] = useState([])
    const [getSettings, {isLoading}] = useGetSettingsMutation();
    const [updateSettings, {isUpdate}] = useUpdateSettingsMutation();
    
    const createBlock = () =>{
        let newArr = [...Block];
        newArr.push('');
        setBlock(newArr);
    }

    const changeBlock= id => e =>{
        let newArr = [...Block];
        newArr[id] = e.target.value;
        setBlock(newArr);
    }
    

    const removeBlock = (FBlock) =>{
        setBlock(Block.filter(e => e !== FBlock))
    }
    const onClick =()=>{

    }
    const setData =()=>{
        const fetchData = async () => {
            let values = []
            const formData = new FormData();
            formData.append("category",'Category');
            formData.append('type_method','get');
            const data = await updateSettings(formData).unwrap();
            data.map((v)=>{
                values.push(v['value']);
            });
            setBlock(values);
        }
        fetchData();
    }

    useEffect(() => {        
        setData();
    }, [])

    const updateData = async() =>{
        let sendData="";
        Block.map((v)=>{
            sendData+= 'value,'+v+'|';
        })
        const formData = new FormData();

        formData.append("category",'Category');
        formData.append('type_method','update');
        formData.append('data',sendData);

        const data = await updateSettings(formData).unwrap();
    }

    return(
        <div>
            <Button
                header='Категорія'
                text='Зберегти зміни'
                onClick={updateData}
            />
            <div className='block-content'>
                <div className='header-text'>Кількість товарів на сторінці категорії, які може вибирати користувач</div>
                <div className='description-text'>Найменше число буде відображатися для користувачів за замовчуванням </div>
                <div className='blocks-list'>
                    {
                        Block.length
                        ?
                        Block.map((block,index)=>
                            <span> * 
                                <input className='block-input' type="text" value={block} onChange={changeBlock(index)} />  
                                <img onClick={()=>removeBlock(block)} className='close-image' src="https://cdn-icons-png.flaticon.com/128/10728/10728089.png" alt="" />
                            </span>
                        )
                        :
                        <span>Порожньо</span>
                    }
                <span className='add-new' onClick={createBlock}> * <span>Додати варіант</span> </span>
                        
                </div>
            </div>
        </div>
    )
}

export default CategorySettings;