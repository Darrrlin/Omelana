import Contacts from "./result";

export {
    Contacts
}