import React,{useState, useEffect} from 'react';
import Button from '../../../../ui/buttons/SettingsButton/index';
import SettingsContainer from '../../../../ui/Containers/SettingsContainer';
import InputTextLabel from '../../../../ui/Inputs/InputTestLabel';
import {useUpdateSettingsMutation, useGetSettingsMutation} from '../../../../processes/settings';
import '../css/index.css'
function Contacts(props){
    const [getSettings, {isLoading}] = useGetSettingsMutation();
    const [updateSettings, {isUpdate}] = useUpdateSettingsMutation();
    const [myBlocks, setMyBlocks] = useState([
        {
            id:0,
            title:'Номер телефону',
            values:[
                {
                    id:0,
                    title:'Текст',
                    value:''
                },


            ]
        },
        {
            id:1,
            title:'Електронна пошта',
            values:[
                {
                    id:0,
                    title:'Текст',
                    value:''
                },
                {
                    id:1,
                    title:'Електронна пошта',
                    value:''
                }

            ]
        },
        {
            id:2,
            title:'Месенджери',
            values:[
                {
                    id:0,
                    title:'Текст',
                    value:''
                },
                {
                    id:1,
                    title:'Посилання на Viber',
                    value:''
                }
                ,
                {
                    id:2,
                    title:'Посилання на Telegram',
                    value:''
                }

            ]
        },
        {
            id:3,
            title:'Соціальні мережі',
            values:[
                {
                    id:0,
                    title:'Текст',
                    value:''
                },
                {
                    id:1,
                    title:'Посилання на Instagram',
                    value:''
                }
                ,
                {
                    id:2,
                    title:'Посилання на Facebook',
                    value:''
                }

            ]
        }
    ]);

    const setData = ()=>{
        const fetchData = async () => {
            let values = []
            const formData = new FormData();
            formData.append("category",'Contacts');
            formData.append('type_method','get');
            const data = await updateSettings(formData).unwrap();
            data.map((v)=>{
                if(v['title']==='number title'){
                Blocks[0]['values'].push(                {
                    id:0,
                    title:'Текст',
                    value:v['value']
                })
                }
                if(v['title']==='number'){
                    Blocks[0]['values'].push(                {
                        id:Blocks[0]['values'].length,
                        title:'Телефон',
                        value:v['value']
                    })
                };
                if(v['title']==='gmail title'){
                    Blocks[1]['values'].push(                {
                        id:0,
                        title:'Текст',
                        value:v['value']
                    })
                };
                if(v['title']==='gmail'){
                    Blocks[1]['values'].push(                {
                        id:1,
                        title:'Електронна пошта',
                        value:v['value']
                    })
                };
                if(v['title']==='messanger title'){
                    Blocks[2]['values'].push(                {
                        id:0,
                        title:'Текст',
                        value:v['value']
                    })
                };
                if(v['title']==='viber'){
                    Blocks[2]['values'].push(                {
                        id:1,
                        title:'Посилання на Viber',
                        value:v['value']
                    })
                };
                if(v['title']==='telegram'){
                    Blocks[2]['values'].push(                {
                        id:2,
                        title:'Посилання на Telegram',
                        value:v['value']
                    })
                };
                if(v['title']==='social title'){
                    Blocks[3]['values'].push(                {
                        id:0,
                        title:'Текст',
                        value:v['value']
                    })
                };
                if(v['title']==='instagram'){
                    Blocks[3]['values'].push(                {
                        id:1,
                        title:'Посилання на Instagram',
                        value:v['value']
                    })
                };
                if(v['title']==='facebook'){
                    Blocks[3]['values'].push(                {
                        id:2,
                        title:'Посилання на Facebook',
                        value:v['value']
                    })
                }; });
                setMyBlocks(Blocks);
                }
        
        fetchData();

    };

    const updateData = async() =>{
        let sendData="";
        const formData = new FormData();
        sendData+="number title,"+myBlocks[0]['values'][0]['value']+"|";
        myBlocks[0]['values'].map((v,index)=>{
            if(index===0){
                return
            }
            sendData+="number,"+v['value']+"|";
        })
        sendData+="gmail title,"+myBlocks[1]['values'][0]['value']+"|";
        sendData+="gmail,"+myBlocks[1]['values'][1]['value']+"|";
        sendData+="messanger title,"+myBlocks[2]['values'][0]['value']+"|";
        sendData+="viber,"+myBlocks[2]['values'][1]['value']+"|";
        sendData+="telegram,"+myBlocks[2]['values'][2]['value']+"|";
        sendData+="social title,"+myBlocks[3]['values'][0]['value']+"|";
        sendData+="instagram,"+myBlocks[3]['values'][1]['value']+"|";
        sendData+="facebook,"+myBlocks[3]['values'][2]['value']+"|";
        formData.append("category",'Contacts');
        formData.append('type_method','update');
        formData.append('data',sendData);
        const data = await updateSettings(formData).unwrap();

        //const data = await updateSettings(formData).unwrap();
    }
    
    // const setData =()=>{
    //     const fetchData = async () => {
    //           var Blocks = [
    //     {
    //         id:0,
    //         title:'Номер телефону',
    //         values:[]
    //     },
    //     {
    //         id:1,
    //         title:'Електронна пошта',
    //         values:[]
    //     },
    //     {
    //         id:2,
    //         title:'Месенджери',
    //         values:[]
    //     },
    //     {
    //         id:3,
    //         title:'Соціальні мережі',
    //         values:[]
    //     }]
    //     const data = await getSettings().unwrap();
    //     data.map((v)=>{
    //         if(v['title']==='phoneTitle'){
    //             Blocks[0]['values'].push(                {
    //                 id:1,
    //                 title:'Текст',
    //                 value:v['value']
    //             })
    //         }
    //         if(v['title']==='phone'){
    //             Blocks[0]['values'].push(                {
    //                 id:1,
    //                 title:'Телефон',
    //                 value:v['value']
    //             })
    //         };
    //         if(v['title']==='mail title'){
    //             Blocks[1]['values'].push(                {
    //                 id:0,
    //                 title:'Текст',
    //                 value:v['value']
    //             })
    //         };
    //         if(v['title']==='mail value'){
    //             Blocks[1]['values'].push(                {
    //                 id:1,
    //                 title:'Електронна пошта',
    //                 value:v['value']
    //             })
    //         };
    //         if(v['title']==='messangers title'){
    //             Blocks[2]['values'].push(                {
    //                 id:0,
    //                 title:'Текст',
    //                 value:v['value']
    //             })
    //         };
    //         if(v['title']==='Viber'){
    //             Blocks[2]['values'].push(                {
    //                 id:1,
    //                 title:'Посилання на Viber',
    //                 value:v['value']
    //             })
    //         };
    //         if(v['title']==='Telegram'){
    //             Blocks[2]['values'].push(                {
    //                 id:2,
    //                 title:'Посилання на Telegram',
    //                 value:v['value']
    //             })
    //         };
    //         if(v['title']==='Social title'){
    //             Blocks[3]['values'].push(                {
    //                 id:0,
    //                 title:'Текст',
    //                 value:v['value']
    //             })
    //         };
    //         if(v['title']==='Social title'){
    //             Blocks[3]['values'].push(                {
    //                 id:1,
    //                 title:'Посилання на Instagram',
    //                 value:v['value']
    //             })
    //         };
    //         if(v['title']==='Social title'){
    //             Blocks[3]['values'].push(                {
    //                 id:2,
    //                 title:'Посилання на Facebook',
    //                 value:v['value']
    //             })
    //         }; });
    //         setMyBlocks(Blocks);
    //         console.log(Blocks);
    //     }
    //     fetchData();
    // }

    useEffect(()=>{
        setData(); 
    },[])


   let Blocks = [
        {
            id:0,
            title:'Номер телефону',
            values:[

            ]
        },
        {
            id:1,
            title:'Електронна пошта',
            values:[

            ]
        },
        {
            id:2,
            title:'Месенджери',
            values:[
               
            ]
        },
        {
            id:3,
            title:'Соціальні мережі',
            values:[
               
            ]
        }
    ]
   const onClick = () =>{

   }



//    useEffect(()=>{
//     setData();
// },[])

const changeValue = (index,valueId,e)=>{
    let newArray = [...myBlocks];
    newArray[index].values[valueId].value = e;
    setMyBlocks(newArray);
   }
const createPhone = () =>{
    let newArray = [...myBlocks];
    newArray[0].values.push(
        {
            id:newArray[0].values.lenght,
            title:'Телефон',
            value:''
        }
    );
    setMyBlocks(newArray);
}
    return(
        <div className=''>
            <Button
             header='Контакти'
             text='Зберегти зміни'
             onClick={updateData}
            />
                
            {myBlocks.map((block)=>
            <div>
                <span className='header-text'>{block.title}</span>
                
                <SettingsContainer
                    items={
                        [
                            <div className='block-consist'>

                                <div className='block-header'>
                                    {block.values.map((value)=>
                                    <div>
                                    
                                        <InputTextLabel
                                        value={value.value}
                                        onChange={(e)=>changeValue(block.id,value.id,e.target.value)}
                                        label={value.title}
                                        
                                        />
                                        
                                    </div>
                                    )}
                                    <span style={{display: block.title === 'Номер телефону'? 'block' : 'none'}} 
                                        className='add-new-button' 
                                        onClick={()=>createPhone()}>
                                            + Додати телефон
                                        </span>
                                    
                                </div>
                            </div>
                        ]
                    }
                    
                    
                />
                </div>
                )
            }
                    
        </div>

    )
}
export default Contacts;