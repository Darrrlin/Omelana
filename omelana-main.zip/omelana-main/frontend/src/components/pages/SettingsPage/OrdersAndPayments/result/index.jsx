import React,{useState, useEffect} from 'react'
import Button from '../../../../ui/buttons/SettingsButton/index'
import SettingsContainer from '../../../../ui/Containers/SettingsContainer'
import InputTextLabel from '../../../../ui/Inputs/InputTestLabel'
import '../css/index.css';
import {useUpdateSettingsMutation} from '../../../../processes/settings';

function OrdersAndPayments(props){
    const [updateSettings, {isUpdate}] = useUpdateSettingsMutation();
    let values =[
        {
            id:0,
            title:'first',
            elements:[
                {
                    id:0,
                    name:'section1'},
                {
                    id:1,
                    name:'section2'}
            ]
        }
    ]

    const [statesArray,setStatesArray] = useState([])

    useEffect(()=>{
        setStatesArray(values);
        const fetchData = async () => {
            const formData = new FormData();
            formData.append("category",'Deliveries and payments');
            formData.append('type_method','get');
            const data = await updateSettings(formData).unwrap();
            
            values = [];
            setStatesArray([])
            data.map((value,index)=>{
                let title = String(value.value).split('|')[0];
                value = String(value.value).split('|')[1];
                values.push( {
                    id:index,
                    title:title,
                    elements:[]
                })
                value.split('shifr').map((elem)=>
                values[index].elements.push(
                        {
                            id:values[index].elements.length,
                            name:elem})
                    
                )
                
                
            })
            setStatesArray(values);
            }
        fetchData();
    

    },[])

    const changeTitle=(index,value)=>{
        let values = [...statesArray]
        values[index]['title'] = value;
        setStatesArray(values);
    }
    const changeDescription=(index,indexBlock,value)=>{
        let values = [...statesArray]
        values[index]['elements'][indexBlock]['name']=value;
        setStatesArray(values);
    }
    const onClick = () =>{
        const fetchData = async () => {
            const formData = new FormData();
            let sendData="";
            formData.append("category",'Deliveries and payments');
            formData.append('type_method','update');
            
            statesArray.map((elem, index)=>{
                sendData+= elem['title']+"|";
                elem.elements.map((value1)=>{
                    sendData+=value1['name']+"shifr";
                })
                
                sendData+='=|=';
            })
            formData.append('data',sendData);
            const data = await updateSettings(formData).unwrap();
            }
        fetchData();
        
    }

    const removeBlock = (index,Block) =>{
        let values = [...statesArray]
        values[index]['elements']=values[index]['elements'].filter(e => e.id !== Block);
        setStatesArray(values);
    }

    const createElement = () =>{
        let values = [...statesArray];
        values.push(
            {id:values.length,
            title:'',
            elements:[
                {
                    id:0,
                    name:''},
            ]});
            setStatesArray(values);
    }

    const createBlock = (index) =>{
        let values = [...statesArray];
        values[index]['elements'].push(
            {
                id: values[index]['elements'].length,
                name:''
            });
        setStatesArray(values);
    }
    const removeRow = (index)=>{
        setStatesArray((current) =>
        current.filter(
          (row) => !(row.id === index)
        )
      );

    }

    return(
        <div className='order-and-payments-block'>
            <Button
             header='Доставка і оплата'
             text='Зберегти зміни'
             onClick={onClick}
            />
            {statesArray.map(block=>(
                <div className='mapping-block'>
                    <span className='header-text'>Секція № {block.id+1}</span>
                    <SettingsContainer
                    items={
                        [
                            <div className='block-consist'>
                                <div className='block-header-container'>
                                <InputTextLabel
                                value={block.title}
                                onChange={(e)=>changeTitle(block.id,e.target.value)}
                                label='Заголовок'
                                
                                />
                                <span ><img onClick={()=>{removeRow(block.id)}} className='trash-icon' src="https://cdn-icons-png.flaticon.com/512/1843/1843344.png"/></span>
                            </div>
                            {block.elements.map((element)=>(
                                <span className='input-span'>
                                    <span>*
                                    <input className='block-input-text' type="text" value={element.name} onChange={
                                        (e)=>changeDescription(block.id, element.id,e.target.value)
                                    }></input>
                                    </span>
                                    <img onClick={()=>removeBlock(block.id, element.id)} className='close-image' src="https://cdn-icons-png.flaticon.com/128/10728/10728089.png" alt="" />
                                </span>
                                ))}
                                <span className='input-span' onClick={()=>createBlock(block.id)}>*
                                    <input readOnly={true} value='Додати пункт' className='add-new-block'></input>
                                </span>
                            </div>
                        ]
                        
                    }
                    
                />
            </div>
            ))}
            <span className='add-new-button' onClick={createElement}>+ Додати секцію</span>
        </div>
    )
}
export default OrdersAndPayments;