import React,{useState, useRef, useEffect} from 'react';
import Button from '../../../../ui/buttons/SettingsButton/index'
import '../css'
import SearchIcon from '../../../../ui/icons/OrdersIcon'
import InputTextLabel from '../../../../ui/Inputs/InputTestLabel'
import {OneImage} from '../../../../ui/image/OneImage'
import TextArea from '../../../../ui/Inputs/TextArea/textArea';
import {useUpdateSettingsMutation, useGetSettingsMutation} from '../../../../processes/settings';

function SettingsMain(props){
    const [getSettings, {isLoading}] = useGetSettingsMutation();
    const [updateSettings, {isUpdate}] = useUpdateSettingsMutation();

    const [label1,setLabel1] = useState('')
    const [label2,setLabel2] = useState('')

    const [ErrorLabel1,setErrorLabel1] = useState('')
    const [ErrorLabel2,setErrorLabel2] = useState('')

    const [Image1,setImage1] = useState()
    const [Image2,setImage2] = useState()

    const [StateLabel1, setStateLabel1] = useState('');
    const [StateLabel2, setStateLabel2] = useState('');

    const [ImageUrl1, setImageUrl1] = useState();
    const [ImageUrl2, setImageUrl2] = useState();
    
    const [ErrorImage1, setErrorImage1] = useState();
    const [ErrorImage2, setErrorImage2] = useState();


    const setData = ()=>{
        const fetchData = async () => {
            const formData = new FormData();
            formData.append("category",'Main');
            formData.append('type_method','get');
            const data = await updateSettings(formData).unwrap();
            setLabel1(data[0]['value']);
            setImageUrl1(data[0]['value_file']);
            setImage1(data[0]['value_file']);
            setLabel2(data[1]['value']);
            setImageUrl2(data[1]['value_file'])
            setImage2(data[1]['value_file']);
            
            }
        fetchData();

    }

    useEffect(()=>{
        setData();
    },[])
   
    const Check = ()=> {
        if (label1 === ''){
            setStateLabel1('заповніть поле');
            return false;
        }
        else{
            setStateLabel1('');
        }
        if (label2 === ''){
            setStateLabel2('заповніть поле');
            return false;
        }
        else{
            setStateLabel2('');
        }
        if( ImageUrl1 === undefined){
            setErrorImage1('Помилка');
            return false;
        }
        else{
            setErrorImage1('');
        }
        if( ImageUrl2 === undefined){
            setErrorImage2('Помилка');
            return false;
        }
        else{
            setErrorImage2('');
        }
        return true;
        
    }

    const onClick = async (params)=> {
        if(Check()){
            let formData = new FormData();
            formData.append("category",'Main');
            formData.append('type_method','update');
            formData.append("title", 'Title 1');
            formData.append('value_file',Image1)
            formData.append("value", label1);
            let data = await updateSettings(formData).unwrap();
            formData.append("title", 'Title 2');
            formData.append('value_file',Image2)
            formData.append("value", label2);
            data = await updateSettings(formData).unwrap();
        }
        
    }
    return(
        <div className='main'>
             <Button
                header='Головна сторінка'
                text='Зберегти зміни'
                onClick={onClick}
            />
            <div className='content-title'>Головний банер</div>
            <div className='content-block'>

                <OneImage
                width='253px'
                height='145px'
                imageUrl={ImageUrl1}
                setImageUrl={setImageUrl1}
                setImage={setImage1}
                title='Фото'
                error={ErrorImage1}
                setError={setErrorImage1}

                />
                <div>
                    <div className='inputs'>
                        <InputTextLabel
                            value={label1}
                            onChange={(e)=>setLabel1(e.target.value)}
                            label='Слоган'
                            errorText={StateLabel1}
                        />
                    </div>
                </div>
            </div>


            <div className='content-title second-title'>Інформація про магазин</div>
            <div className='content-block'>
                
            <OneImage
                width='253px'
                height='145px'
                imageUrl={ImageUrl2}
                setImageUrl={setImageUrl2}
                setImage={setImage2}
                title='Фото'
                error={ErrorImage2}
                setError={setErrorImage2}

                />
                
                <div>
                <TextArea
                    width='253px'
                    height='243px'
                    defaultValue={label2}
                    onChange={(e)=>setLabel2(e.target.value)}
                    title='Текст'
                    error={StateLabel2}
                />
                    
                  
                </div>
            </div>
        </div>
    )
}
export default SettingsMain;