import SettingsMain from "./result";

export {
    SettingsMain
}