import PersonalData from "./result";

export {
    PersonalData}