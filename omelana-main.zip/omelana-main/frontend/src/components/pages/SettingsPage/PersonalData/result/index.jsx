import React,{useState, useEffect} from 'react'
import Button from '../../../../ui/buttons/SettingsButton/index'
import InputTextLabel from '../../../../ui/Inputs/InputTestLabel'
import TextArea from '../../../../ui/Inputs/TextArea/textArea';
import '../css/index.css'
import {useUpdateSettingsMutation, useGetSettingsMutation} from '../../../../processes/settings';


function PersonalData(props){
    const [label1,setLabel1] = useState('');
    const [label2,setLabel2] = useState('');
    const [getSettings, {isLoading}] = useGetSettingsMutation();
    const [updateSettings, {isUpdate}] = useUpdateSettingsMutation();
 
    const setData = ()=>{
        const fetchData = async () => {
            let values = []
            const formData = new FormData();
            formData.append("category",'Personal data');
            formData.append('type_method','get');
            const data = await updateSettings(formData).unwrap();
            setLabel1(data[0].value);
            setLabel2(data[1].value);
        }
        fetchData();

    }
    const updateData = async() =>{
        let sendData="";
        sendData+='value,'+label1+'|value,'+label2+'|';
        const formData = new FormData();

        formData.append("category",'Personal data');
        formData.append('type_method','update');
        formData.append('data',sendData);

        const data = await updateSettings(formData).unwrap();
    }

    useEffect(()=>{
        setData();
    },[])

    const onClick =()=>{

    }
    return(
        <div>
            <Button
            header='Положення про обробку і захист персональних даних'
            text='Зберегти зміни'
            onClick={updateData}
            
            />
            <div className='user-agreement-page'>
                <InputTextLabel
                    value={label1}
                    onChange={(e)=>setLabel1(e.target.value)}
                    label='Заголовок'
                />
                <TextArea
                        width='538px'
                        height='572px'
                        defaultValue={label2}
                        onChange={(e)=>setLabel2(e.target.value)}
                        title='Текст'
                        error=''
                    />
                </div>
        </div>
    )
}
export default PersonalData;