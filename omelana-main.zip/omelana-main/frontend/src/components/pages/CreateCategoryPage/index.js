import CreateCategoryPage from "./result";

export {
    CreateCategoryPage
}