import React, {useState} from 'react';
import InputPasswordLabel from "../../../ui/Inputs/InputPasswordLabel";
import InputTextLabel from "../../../ui/Inputs/InputTestLabel";
import {Box, Button} from "@mui/material";
import {setCredential, useLoginMutation} from "../../../processes/auth";
import {useDispatch} from "react-redux";

const FormLoginWidget = () => {

    const [password, setPassword] = useState("");
    const [loginText, setLoginText] = useState("");

    const [error, setError] = useState("");
    const [login, { isLoading }] = useLoginMutation()

    const dispatch = useDispatch()


    const handleSubmit = async (event) => {
        event.preventDefault()

        try {
            const userData = await login({
                username: loginText,
                password: password
            }).unwrap();
            dispatch(setCredential(userData))
            setLoginText('')
            setPassword('')
        } catch (err) {
            setError("Невірні дані!")
        }
    }
    const handleLoginInput = (event) => setLoginText(event.currentTarget.value)

    const handlePasswordInput = (event) => setPassword(event.currentTarget.value)


    return (
        <Box sx={{
            width: '315px',
            maxWidth: '100%',
            marginTop: '69px'
        }}>
            <InputTextLabel
                value={loginText}
                onChange={handleLoginInput}
                label='Логін'
                prefixLabel="login"
                errorText={error}
                sx={{
                    marginBottom: '16px'
                }}
            />
            <InputPasswordLabel
                value={password}
                onChange={handlePasswordInput}
                label='Пароль'
                prefixLabel="password"
                errorText={error}
                sx={{
                    marginBottom: '40px'
                }}
            />
            <Button variant="contained" color="primary" sx={{
                width: '100%'
            }} onClick={handleSubmit}>
                Увійти
            </Button>
        </Box>
    );
};

export default FormLoginWidget;