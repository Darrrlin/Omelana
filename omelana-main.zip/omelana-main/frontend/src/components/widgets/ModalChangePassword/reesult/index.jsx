import React from 'react';

import '../css';
import InputPasswordLabel from "../../../ui/Inputs/InputPasswordLabel";
import {Modal} from "../../../ui/modal";
const ModalChangePassword = ({data, setData, savePassword, isOpen, setIsOpen}) => {
    const handlePasswordInput = (value, key) => {
        let tempData = {...data};
        tempData[key] = value;
        setData({...tempData});
    }

    const cancel = () => {
        setData({
            current: "",
            'new': "",
            confirm: ""
        })
        setIsOpen(false)
    }

    return (
        <Modal
            isOpen={isOpen}
            setIsOpen={setIsOpen}>
            <div className="modal-change-password">
                <div className="title">
                    Зміна паролю
                </div>
                <InputPasswordLabel
                    value={data.current}
                    onChange={(e) => handlePasswordInput(e.target.value, "current")}
                    label='Поточний пароль'
                    prefixLabel="password-current"
                    errorText={data.currentError}
                    sx={{
                        marginBottom: '16px'
                    }}
                />
                <InputPasswordLabel
                    value={data.new}
                    onChange={(e) => handlePasswordInput(e.target.value, "new")}
                    label='Новий пароль'
                    prefixLabel="password-new"
                    errorText={data.newError}
                    sx={{
                        marginBottom: '16px'
                    }}
                />
                <InputPasswordLabel
                    value={data.confirm}
                    onChange={(e) => handlePasswordInput(e.target.value, "confirm")}
                    label='Новий пароль ще раз'
                    prefixLabel="password-confirm"
                    errorText={data.confirmError}
                />

                <div className="button-group">
                    <div className="button cancel" onClick={cancel}>
                        Скасувати
                    </div>
                    <div className="button save" onClick={savePassword}>
                        Змінити пароль
                    </div>
                </div>
            </div>
        </Modal>
    );
};

export default ModalChangePassword;