import ModalChangePassword from "./reesult";

export {
    ModalChangePassword
}