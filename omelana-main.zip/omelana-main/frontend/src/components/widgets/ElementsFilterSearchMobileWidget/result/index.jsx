import React from 'react';

import '../css';
import CircleCheckBox from "../../../ui/Inputs/CircleCheckBox";

// data = {
//     title: string
//     chooses: list
// }
const ElementsFilterSearchMobileWidget = ({
                                              actionAccess,
                                              actionDropFilters,
                                              data,
                                              stateFilter,
                                              setStateFilter,
                                              isOpenFilter,
                                              setIsOpenFilter
                                          }) => {
    return (
        <div className={`mobile-filter-container ${isOpenFilter ? "open" : ""}`}>
            <div className="mobile-filter" onClick={(e) => {
                e.stopPropagation();
                e.preventDefault();
            }}>

                <div className="title-filter">Фільтри</div>
                <div className="filter-block-information">
                    {data.map((_element, index) =>
                        <div
                            className="filter-element"
                            key={`filter-element-${index}`}
                        >
                            <div
                                className="title-filter-element"
                                key={`title-filter-element-${index}`}
                            >{_element.title}</div>
                            {_element.chooses.map((elementChooses, indexElementChooses) =>
                                <div
                                    className={`choose-filter-element`}
                                    onClick={(e) => {
                                        stateFilter[index] = indexElementChooses;
                                        setStateFilter([...stateFilter])
                                    }}
                                    key={`choose-filter-element-${index}-${indexElementChooses}`}
                                >
                                    <div
                                        className="choose-filter-element-check-box"
                                        key={`choose-filter-element-check-box-${index}-${indexElementChooses}`}
                                    >
                                        <CircleCheckBox
                                            name={`choose-filter-element-check-box-${index}-${indexElementChooses}`}
                                            setState={() => {
                                            }}
                                            state={stateFilter[index] === indexElementChooses}
                                            key={`choose-filter-element-check-box-2-${index}-${indexElementChooses}`}
                                        />
                                    </div>
                                    <div
                                        className="choose-filter-element-title"
                                        key={`choose-filter-element-title-${index}-${indexElementChooses}`}
                                    >{elementChooses.text}</div>

                                </div>
                            )}

                        </div>
                    )}


                    <div className="button-group">
                        <div className="button cancel" onClick={(e) => {
                            actionDropFilters();
                            setIsOpenFilter(false);
                        }}>
                            Скинути
                        </div>
                        <div className="button access" onClick={(e) => {
                            actionAccess();
                            setIsOpenFilter(false);
                        }}>
                            Застосувати
                        </div>
                    </div>
                </div>
            </div>
            <div className="grey-background" onClick={(e) => setIsOpenFilter(false)}></div>
        </div>
    );
};

export default ElementsFilterSearchMobileWidget;