import ElementsFilterSearchMobileWidget from "./result";

export default ElementsFilterSearchMobileWidget;