import React, {useEffect, useState} from 'react';
import {Modal} from "../../../ui/modal";

import '../css';
import {useNavigate} from "react-router-dom";
import useNavigationBlocker from "../../../uttils/hook/react-router";

const ModalCheckSaveWidget = ({condition, save}) => {

    const navigate = useNavigate();
    const [confirmed, setConfirmed] = useState(false);
    const { isOpenModal, setIsOpenModal, pathname, setPathname } = useNavigationBlocker(!condition, confirmed);


    useEffect(() => {
        if (confirmed) {
            navigate(pathname);
        }
    }, [confirmed]);

    const onClose = () => {
        setIsOpenModal(false);
        setPathname('');
    };

    const saveAction = async () => {
        await save();
        submitAction();
    }

    const submitAction = () => {
        setConfirmed(true);
        setIsOpenModal(false);
    }

    return (
        <Modal
            isOpen={isOpenModal}
            setIsOpen={onClose}
            children={
            <div className="block-information" onClick={(event) => {
                event.stopPropagation();
                event.preventDefault();
            }}>
                <div className="title-question">Чи бажаєте зберегти зміни?</div>
                <div className="description-question">Чи бажаєте зберегти зміни?</div>
                <div className="button save" onClick={saveAction}>Зберегти</div>
                <div className="button dont-save" onClick={submitAction}>Не зберігати</div>
                <div className="button cancel" onClick={onClose}>Скасувати</div>
            </div>
        }
        />
    );
};

export default ModalCheckSaveWidget;