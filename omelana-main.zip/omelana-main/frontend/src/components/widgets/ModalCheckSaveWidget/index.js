import ModalCheckSaveWidget from "./result";

export {
    ModalCheckSaveWidget
}