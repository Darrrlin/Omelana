import PropertyCategoryWidget from "./result";

export default PropertyCategoryWidget;