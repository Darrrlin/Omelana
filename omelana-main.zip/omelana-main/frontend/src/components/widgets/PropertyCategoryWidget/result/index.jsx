import React from 'react';

import "../css"
import InputTextLabel from "../../../ui/Inputs/InputTestLabel";
import CheckBox from "../../../ui/Inputs/CheckBox";
import MoreIcons from "../../../ui/icons/MoreIcons";
import CloseIcon from "../../../ui/icons/CloseIcon";

const PropertyCategoryWidget = ({
                                    name,
                                    setName,
                                    isOpenContextMenu,
                                    setIsOpenContextMenu,
                                    listValues,
                                    setListValues,
                                    actionCopy,
                                    actionDelete,
                                    errorName
                                }) => {

    return (
        <div className="category-property">
            <div className="title-property-bar">
                <div className="title-property">
                    <InputTextLabel
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        label='Властивість'
                        prefixLabel="name-property"
                        errorText={errorName}
                    />
                </div>
                <div className="more-options" onClick={(e) => {
                    e.preventDefault();
                    setIsOpenContextMenu(!isOpenContextMenu);
                    e.stopPropagation();
                }}>
                    <MoreIcons className="icon"/>
                </div>
                <div className={`actions ${isOpenContextMenu ? "open" : ""}`} onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                }}>
                    <div className="action" onClick={(event) => {
                        setIsOpenContextMenu(false);
                        actionCopy();
                    }}>Створити копію
                    </div>
                    <div className="action" onClick={(event) => {
                        setIsOpenContextMenu(false);
                        actionDelete();
                    }}>Видалити
                    </div>
                </div>
            </div>
            {listValues.map((val, index) =>
                <div className="property-value-row" key={`property-value-row-${index}`}>
                    <CheckBox name={""} state={false} onChange={(e) => {
                    }}/>
                    <input className="value"
                           key={`property-value-input-${index}`}
                           value={val} onChange={(event) => {
                        listValues[index] = event.target.value;
                        setListValues([...listValues]);
                    }}/>
                    <CloseIcon key={`property-value-delete-icon-${index}`} className="delete-icon" onClick={(event) => {
                        setListValues(listValues.filter((_, i) => index !== i));
                    }}/>
                </div>
            )}
            <div className="property-value-row">
                <CheckBox name={""} state={false} onChange={(e) => {
                }}/>
                <span className="value add" onClick={(e) => setListValues([...listValues, ""])}>Додати варіант</span>
            </div>
        </div>
    );
};

export default PropertyCategoryWidget;