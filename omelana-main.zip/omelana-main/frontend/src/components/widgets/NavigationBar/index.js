import NavigationBar from "./result";


export default NavigationBar;