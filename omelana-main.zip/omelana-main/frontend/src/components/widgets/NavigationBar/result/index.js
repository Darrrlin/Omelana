import React, {useEffect, useState} from 'react';
import '../css'
import '../css/settingShortMenu.css'
import LogoIcon from "../../../ui/icons/LogoIcon";
import {Link, useLocation, useNavigate} from "react-router-dom";
import {defaultPrevUrl, protectedRoutes} from "../../../processes/routing";
import {accountRoute, settingsRoutes} from "../../../processes/routing/config";
import ExitIcon from "../../../ui/icons/ExitIcon";
import {logOut, useLogoutMutation} from "../../../processes/auth";
import {useDispatch} from "react-redux";
import TitleBarMore from "../../../ui/TitleBarMore/result";

const NavigationBar = ({isOpen, changeOpen, callbackSetCurrentRoutes, openSettingMenu, setOpenSettingMenu}) => {

    const [logOutFunctions, {isLoading}] = useLogoutMutation()

    const dispatch = useDispatch()
    const location = useLocation();
    const navigate = useNavigate();
    const [indexCurrentRoutes, setIndexCurrentRoutes] = useState(0);
    const [indexCurrentRoutesSetting, setIndexCurrentRoutesSetting] = useState(0);


    useEffect(() => {
        if (location.pathname.includes(defaultPrevUrl + accountRoute.url)) {
            setIndexCurrentRoutes("account");
            callbackSetCurrentRoutes("account");
            return;
        }
        if (location.pathname.includes(defaultPrevUrl + settingsRoutes.url)) {
            setIndexCurrentRoutes("setting");
            callbackSetCurrentRoutes("setting");
            for (const routesKey in settingsRoutes.routes) {
                const route = settingsRoutes.routes[routesKey];
                if (location.pathname.includes(route.url)) {
                    setIndexCurrentRoutesSetting(routesKey);
                    return;
                }
            }
            setIndexCurrentRoutesSetting(-1);

            return;
        }

        for (const id in protectedRoutes.routes) {
            const route = protectedRoutes.routes[id];
            if (route.isShow && location.pathname.includes(defaultPrevUrl + route.url)) {
                setIndexCurrentRoutes(id);
                callbackSetCurrentRoutes(id);
                return;
            }
        }
        setIndexCurrentRoutes(protectedRoutes.basicIndex);
        callbackSetCurrentRoutes(protectedRoutes.basicIndex);
    }, [location]);

    const handlerLogOut = async (event) => {
        event.preventDefault()

        try {
            const userData = await logOutFunctions().unwrap();
            dispatch(logOut(userData))
        } catch (err) {
            console.log(err)
        }
    }

    const changeOpenSettingsMenu = (e) => {
        e.preventDefault();
        e.stopPropagation();
        setOpenSettingMenu(!openSettingMenu);
    }


    return (
        <>
            <div
                className={`left-bar ${isOpen ? "open" : "close"} ${indexCurrentRoutes === "setting" ? "setting" : ""}`}>
                <div className="container">


                    <div className="top-block">
                        <div className="logo-block">
                            <LogoIcon className="icon" onClick={() => window.open("/", '_blank')}/>
                        </div>
                        {protectedRoutes.routes.filter((el => el.isShow === true)).map((element, index) =>
                            <Link
                                className={`element-menu ${element.url === protectedRoutes.routes[indexCurrentRoutes]?.url ? "active" : ""}`}
                                onClick={(e) => changeOpen(false)}
                                to={defaultPrevUrl + element.url}
                                key={`menu-item-index-${index}`}
                            >
                                <span>
                                <span className="icon-block" key={`menu-item-icon-block-${index}`}>
                                    {React.createElement(element.icon, {
                                        className: "icon-element",
                                        key: `menu-item-icon-${index}`
                                    }, null)}
                                </span>
                                <span className="title" key={`menu-item-title-${index}`}>
                                    {element.title}
                                </span>
                                </span>
                            </Link>
                        )}
                        <span
                            className={`element-menu setting ${indexCurrentRoutes === "setting" ? "active" : ""}`}
                            onClick={(e) => {
                                navigate(defaultPrevUrl + settingsRoutes.url);
                                changeOpen(false);
                                setOpenSettingMenu(true);
                            }}
                        >
                        <span>
                            <span className="icon-block">
                                {React.createElement(settingsRoutes.icon, {className: "icon-element"}, null)}
                            </span>
                            <span className="title">
                                    {settingsRoutes.title}
                            </span>
                        </span>
                        <span onClick={changeOpenSettingsMenu} className={`arrow ${openSettingMenu ? "open" : ""}`}>
                            <div className="list-settings-menu-short">
                                {settingsRoutes.routes.map((element, index) =>
                                    <Link
                                        to={defaultPrevUrl + settingsRoutes.url + element.url}
                                        key={`list-settings-element-short-${index}`}
                                        className={`list-settings-element-short ${element.url === settingsRoutes.routes[indexCurrentRoutesSetting]?.url ? "active" : ""}`}
                                        onClick={(e) => setOpenSettingMenu(false)}
                                    >
                                        {element.title}
                                    </Link>
                                )}
                            </div>
                        </span>
                    </span>
                    </div>
                    <div className="end-block">
                        <Link
                            className={`element-menu ${indexCurrentRoutes === "account" ? "active" : ""}`}
                            onClick={(e) => changeOpen(false)}
                            to={defaultPrevUrl + accountRoute.url}
                        >
                        <span>
                        <span className="icon-block">
                            {React.createElement(accountRoute.icon, {className: "icon-element"}, null)}
                        </span>
                            <span className="title">
                            {accountRoute.title}
                        </span>
                        </span>
                        </Link>
                        <span
                            className={`element-menu`}
                            onClick={handlerLogOut}
                        >
                        <span>
                        <span className="icon-block">
                            {React.createElement(ExitIcon, {className: "icon-element"}, null)}
                        </span>
                        <span className="title">
                            {"Вийти"}
                        </span>
                        </span>
                    </span>
                    </div>
                </div>

                <div className="grey-background" onClick={(e) => changeOpen(false)}></div>
            </div>
            {indexCurrentRoutes === "setting" &&
                <div className={`menu-settings ${openSettingMenu ? "open" : ""}`}>
                    <div className="title">
                        Налаштування сторінок
                    </div>
                    <TitleBarMore titlePage={"Налаштування сторінок"} openMenu={(e) => changeOpen(true)}/>
                    <div className="list-settings-menu">
                        {settingsRoutes.routes.map((element, index) =>
                            <Link
                                to={defaultPrevUrl + settingsRoutes.url + element.url}
                                key={`list-settings-element-${index}`}
                                className={`list-settings-element ${element.url === settingsRoutes.routes[indexCurrentRoutesSetting]?.url ? "active" : ""}`}
                                onClick={(e) => setOpenSettingMenu(false)}
                            >
                                <span className="title">{element.title}</span>
                                <span className="arrow"></span>
                            </Link>
                        )}
                    </div>
                </div>
            }
        </>
    );
};

export default NavigationBar;