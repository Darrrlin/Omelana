import React, {useEffect, useState} from 'react';

import '../css';
import MoreIcons from "../../../ui/icons/MoreIcons";
import InputWithDescription from "../../../ui/Inputs/InputWithDescription";
import InputDiscount from "../../../ui/Inputs/InputDiscount";
import Switcher from "../../../ui/Inputs/Switcher";
import CalendarInput from "../../../ui/Inputs/CalendarInput";
import {Modal} from "../../../ui/modal";

const DiscountProductWidget = ({
                                   currentPrice,
                                   discountPrice,
                                   setDiscountPrice,
                                   discountPercent,
                                   setDiscountPercent,
                                   isTimeLine,
                                   setIsTimeLine,
                                   firstTimeLine,
                                   setFirstTimeline,
                                   secondTimeLine,
                                   setSecondTimeLine,
                                   isOpenContextMenu,
                                   setIsOpenContextMenu,
                                   actionDisableDiscount,
                                   setPricePercentData
                               }) => {
    const [prevPrice, setPrevPrice] = useState(0);
    const [prevPercent, setPrevPercent] = useState(0);

    useEffect(() => {
        let percent = 1
        if (!isNaN(parseFloat(discountPercent))) {
            percent = 1 - parseFloat(discountPercent)/100;
        } else if (!isNaN(parseFloat(discountPercent.slice(0, discountPercent.length - 1)))) {
            percent = 1 - parseFloat(discountPercent.slice(0, discountPercent.length - 1))/100;
        }
        setPricePercentData(currentPrice*percent, 100 - percent*100);
        setPrevPercent(100 - percent*100)
        setPrevPrice(currentPrice*percent)

    }, [currentPrice]);

    useEffect(() => {
        window.addEventListener("click", (e) => {
            setIsOpenContextMenu(false);
        })
    }, []);

    useEffect(() => {
        const interval = setInterval(() => {
            if (discountPercent !== prevPercent) {
                if (discountPercent === 0) {
                    return;
                }
                let value = parseFloat(discountPercent.replace(",", "."));
                if (isNaN(value)) {
                    value = parseFloat(discountPercent.slice(0, discountPercent - 1).replace(",", "."));

                    if (isNaN(value)) {
                        setDiscountPercent(discountPercent.replace(",", "."));
                        return;
                    }
                }
                if (!(0 <= value && value <= 100)) {
                    return;
                }
                value = 1 - value.toFixed()/100;
                setDiscountPrice((currentPrice*value).toFixed());
                setPrevPercent(discountPercent);
                setPrevPrice((currentPrice*value).toFixed());
            } else if (discountPrice !== prevPrice) {
                const percent = (100 - (discountPrice/(currentPrice/100))).toFixed();
                setDiscountPercent(percent)
            }
        }, 2000);
        return () => clearInterval(interval);
    }, [discountPrice, discountPercent]);

    const changeDiscountPrice = (val) => {
        if (/^\d*(\.|,)?\d*$/.test(val) || val === "") {
            setDiscountPrice(val.replace(",", "."));
        }
    }

    const changeDiscountPercent = (val) => {
        if (/^\d*(\.|,)?\d*%?$/.test(val) || val === "") {
            setDiscountPercent(val);
        }
    }

    return (
        <div className={`discount-property-widget`}>
            <div className="title-discount">
                <span className="title">Знижка</span>
                <span className="more-block" onClick={(e) => {
                    e.preventDefault();
                    setIsOpenContextMenu(!isOpenContextMenu);
                    e.stopPropagation();
                }}>
                    <MoreIcons className="more-icon"/>
                    <div className={`option-list ${isOpenContextMenu ? "open" : ""}`} >
                        <div
                            onClick={(e) => actionDisableDiscount()}
                            className="action"
                        >Скасувати знижку</div>
                    </div>
                </span>
            </div>
            <div className="price-bar">
                <InputWithDescription
                    label="Ціна знижена"
                    state={discountPrice}
                    setState={changeDiscountPrice}
                    error=""
                    desc="грн"
                    isSpecific={true}
                />
                <InputDiscount
                    label="Відсоток знижки"
                    state={discountPercent}
                    setState={changeDiscountPercent}
                    error=""
                />
            </div>
            <div className="time-line-bar">
                <div className="title">Часовий проміжок</div>
                <div className="switcher-time-line"><Switcher state={isTimeLine} setState={setIsTimeLine}/></div>
            </div>

            {isTimeLine &&
                <>
                    <div className="calendar-form-input-group">
                        <div className={`form-calendar-input-data`}>
                            <CalendarInput
                                label="Дата початку дії знижки"
                                state={firstTimeLine}
                                setState={setFirstTimeline}
                            />
                        </div>
                        <div className="minus-calendar-block"></div>
                        <div className={`form-calendar-input-data`}>
                            <CalendarInput
                                label="Дата початку дії знижки"
                                state={secondTimeLine}
                                setState={setSecondTimeLine}
                            />
                        </div>
                    </div>
                </>
            }

            {/*<div className="form-full-calendar"></div>*/}

            {/*<Modal isOpen={typeDateActive !== null} setIsOpen={(value) => {*/}
            {/*    if (value === false) {*/}
            {/*        setTypeDateActive(null);*/}
            {/*    }*/}
            {/*}} />*/}
        </div>
    );
};

export default DiscountProductWidget;