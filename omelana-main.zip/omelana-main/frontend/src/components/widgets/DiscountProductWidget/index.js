import DiscountProductWidget from "./result";

export default DiscountProductWidget;