import React, {useEffect, useState} from 'react';
import '../css/index.css'
import ButtonAdd from '../../../ui/buttons/OrderButtons'
import MoreIcons from "../../../ui/icons/MoreIcons"
import InputSearch from '../../../ui/Inputs/InputSearch'
import Button from '../../../ui/buttons/SettingsButton'
import SelectUI from "../../../ui/selects/SelectUI"
import TitleTablePage from "../../../ui/TitleTablePage"


const OrderMainWidget = ({openMenu,openPage,underDataButtons, sortStateValue, setSortStateValue, sortDateValue, setSortDateValue}) => {

    const [globalContextMenu, setGlobalContextMenu] = useState(false);

    const sortByDate = (sort)=>{
        setSortDateValue(sort)
      }

    const editProduct = (index) => {
    return navigate(defaultPrevUrl + `orders/${data[index].id}/`);
    }

    const sortByStatus = (sort)=>{
        setSortStateValue(sort)
      }
      const onClick=()=>{
      }

      const addDiscount =()=>{

      }
      const setStatusNotIs =()=>{
        
      }

    return(
        <div>
            <TitleTablePage
                actionIcon={openMenu}
                title="Замовлення"
                actionMainButton={() => navigate(defaultPrevUrl + 'products/create')}
                buttonNum={openPage}
            >
                Замовлення
            </TitleTablePage>
            <div className='main-row'>
                <InputSearch
                    desktop='Пошук за №, Клієнтом, Номером телефону'
                    phone='Пошук'
                />
                <div className='phone-row'>
                <SelectUI
                    defaultTitle="Статус замовлення"
                    option={[{id:1,text:'По зростанню'},
                    {id:2,text:'По спаданню'}
                    ]}
                    state={sortDateValue}
                    setState={sortByDate}
                />
                <SelectUI
                    defaultTitle="Сортувати за датою"
                    option={[{id:1,text:'Виконані спершу'},
                    {id:2,text:'Не виконані першу'}
                    ]}
                    state={sortStateValue}
                    setState={sortByStatus}
                />
                <div className="column more-button" onClick={(e) => {
                e.stopPropagation();
                e.preventDefault();
                }}>
                    <MoreIcons className="icon-block" onClick={() => setGlobalContextMenu(!globalContextMenu)}/>
                    <div className={`context-menu ${globalContextMenu? "show" : ""}`}>
                            <div
                                className="list-element"
                                onClick={()=>{underDataButtons[0].action();setGlobalContextMenu(true)}}>
                                Позначити як "Прочитано"
                            </div>
                            <div
                                className="list-element"
                                onClick={()=>{underDataButtons[1].action();setGlobalContextMenu(true)}}>
                                Позначити як "В процесі"
                            </div>
                            <div
                                className="list-element"
                                onClick={()=>{underDataButtons[2].action();setGlobalContextMenu(true)}}>
                                Позначити як "Виконано"
                            </div>
                            <div
                                className="list-element"
                                onClick={()=>{underDataButtons[3].action();setGlobalContextMenu(true)}}>
                                Видалити
                            </div>

                    </div>
                </div>
                </div>
            </div>
        </div>
    )




}
export default OrderMainWidget;
