import OrderMainWidget from "./result";


export default OrderMainWidget;