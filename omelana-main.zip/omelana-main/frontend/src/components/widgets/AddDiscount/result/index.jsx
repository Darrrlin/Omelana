import React from "react"
import {Modal} from '../../../ui/modal'
import '../css'
import InputWithDescription from "../../../ui/Inputs/InputWithDescription";
import Switcher from "../../../ui/Inputs/Switcher";
import CalendarInput from "../../../ui/Inputs/CalendarInput";

const AddDiscount = ({
                        error,
                        saveDiscount,
                        isOpen,
                        setIsOpen,
                        isTimeLine,
                        setIsTimeLine,
                        discountPrice,
                        changeDiscountPrice,
                        firstTimeLine,
                        setFirstTimeline,
                        secondTimeLine,
                        setSecondTimeLine
                     }) => {
    return (
        <Modal
            isOpen={isOpen}
            setIsOpen={setIsOpen}>
            <div className="modal-discount">
                <div className="discount-bar">
                        <span>
                            Додати знижку
                        </span>
                    <div className="bar-swither">
                        <span className="only-phone-visible">
                            <span className="switsher-bar-title">
                                Часовий проміжок
                            </span>
                                <Switcher
                                    state={isTimeLine}
                                    setState={setIsTimeLine}/>
                        </span>
                    </div>
                </div>
                <div className="input-with-date">
                    <InputWithDescription
                        error={error}
                        label="Відсоток знижки"
                        state={discountPrice}
                        setState={changeDiscountPrice}
                        desc="%"
                    />
                    <span className="only-desc-visible">
                        <div className="switsher-bar-title">
                        <span>
                            Часовий проміжок
                        </span>
                            <Switcher
                                state={isTimeLine}
                                setState={setIsTimeLine}/>
                        </div>
                        </span>
                </div>
                {isTimeLine &&
                    <>
                        <div className="calendar-form-input-group">
                            <div className={`form-calendar-input-data`}>
                                <CalendarInput
                                    label="Дата початку дії знижки"
                                    state={firstTimeLine}
                                    setState={setFirstTimeline}
                                />
                            </div>
                            <div className="minus-calendar-block"></div>
                            <div className={`form-calendar-input-data`}>
                                <CalendarInput
                                    label="Дата початку дії знижки"
                                    state={secondTimeLine}
                                    setState={setSecondTimeLine}
                                />
                            </div>
                        </div>
                    </>
                }

                <div className="discount-footer">
                    <div className="discount-button cancel" onClick={() => {
                        setIsOpen(false);
                        setSecondTimeLine("");
                        setFirstTimeline("");
                        changeDiscountPrice(0)

                    }}>
                        Скасувати
                    </div>
                    <div className="discount-button confirm" onClick={
                        saveDiscount}>
                        Зберегти
                    </div>
                </div>
            </div>
        </Modal>
    )
}
export default AddDiscount;