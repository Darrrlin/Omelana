import AddDiscount from './result'

export default AddDiscount;