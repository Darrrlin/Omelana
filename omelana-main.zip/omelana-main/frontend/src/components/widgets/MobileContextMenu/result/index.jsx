import React from 'react';

import '../css';

const MobileContextMenu = ({isOpenContextMenu, setIsOpenContextMenu, actionList}) => {
    return (
        <div className={`modal-mobile-context-menu ${isOpenContextMenu ? "open" : ""}`}>
            <div className="grey-background"></div>
            <div className="context-menu" onClick={(event) => {
                event.stopPropagation();
                event.preventDefault();
            }}>
                {actionList.map((element, index) =>
                    <div key={`mobile-context-menu-item-${index}`} className="context-action" onClick={() => {
                        setIsOpenContextMenu(false);
                        element.action()
                    }}>
                        {element.title}
                    </div>
                )}
            </div>
        </div>
    );
};

export default MobileContextMenu;
