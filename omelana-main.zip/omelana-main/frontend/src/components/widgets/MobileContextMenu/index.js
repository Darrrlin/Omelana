import MobileContextMenu from "./result"


export {
    MobileContextMenu
}