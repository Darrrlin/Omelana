import ModalDiscountProduct from "./result";

export default ModalDiscountProduct;