import React from 'react';

import '../css';

const ModalDiscountProduct = () => {
    return (
        <div>

        </div>
    );
};

export default ModalDiscountProduct;