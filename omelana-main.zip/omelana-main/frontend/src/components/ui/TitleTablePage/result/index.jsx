import React from 'react';
import {Link} from "react-router-dom";
import MenuIcon from "@mui/icons-material/Menu";
import LeftArrowIcon from "../../icons/LeftArrowIcon";

import '../css';
import PlusIcon from "../../icons/PlusIcon";

const TitleTablePage = ({
                             children,
                             actionIcon,
                             title,
                             actionMainButton,
                         }) => {
    return (
        <div className="header-table-page">
            <div className="title-bar">
                <MenuIcon className="action-icon" onClick={actionIcon}/>
                <span className={`title`}>{title}</span>
            </div>
            <div className="action-main-block">
                <button className="header-action" onClick={actionMainButton}>
                    <PlusIcon className="icon-button" />
                    {children}
                </button>
            </div>
        </div>
    );
};

export default TitleTablePage;