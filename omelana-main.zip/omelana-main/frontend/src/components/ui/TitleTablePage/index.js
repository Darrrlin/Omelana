import TitleTablePage from "./result";

export default TitleTablePage;