import React from 'react';

import '../css';

const Loader = (props) => {
    return (
        <div className="loader-container">
            <div className="loader"></div>
        </div>
    );
};

export default Loader;