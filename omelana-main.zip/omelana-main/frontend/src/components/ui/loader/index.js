import Loader from "./result";

export {
    Loader
}