import Pagination from "./result";

export {
    Pagination
}