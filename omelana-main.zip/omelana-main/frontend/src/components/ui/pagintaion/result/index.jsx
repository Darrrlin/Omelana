import React, {useEffect, useState} from 'react';

import '../css/index.css';
import {PaginationElement} from "../PaginationElement";

const Pagination = ({page, maxPage, setPage}) => {
    const [pagesList, setPagesList] = useState([]);

    useEffect(() => {
        if (maxPage < 10) {
            setPagesList(Array(maxPage).fill().map((_, idx) => 1 + idx));
        } else if (page < 6) {
            setPagesList([1, 2, 3, 4, 5, 6, 7, '...', maxPage]);
        } else if (page + 6 > maxPage) {
            setPagesList([1, "...", maxPage - 6, maxPage - 5, maxPage - 4, maxPage - 3, maxPage - 2, maxPage - 1, maxPage]);
        } else {
            setPagesList([1, "...", page - 2, page - 1, page, page + 1, page + 2, "...", maxPage]);
        }
    }, [page, maxPage])

    return (
        <>
            {maxPage > 1 &&
                <div className='pagination'>
                    <div className="container">
                        {pagesList.map((element, index) =>
                            <PaginationElement
                                title={element}
                                key={`pagination-element-${index}`}
                                callback={typeof element === "number"
                                    ? () => setPage(element)
                                    : () => undefined
                                }
                                isActive={page === element}
                            />
                        )}
                    </div>
                </div>
            }
        </>
    );
};

export default Pagination;