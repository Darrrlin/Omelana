import PaginationElement from "./result";

export {
    PaginationElement
}