import React from 'react';

import '../css/index.css';
const PaginationElement = ({title, callback, isActive}) => {
    return (
        <div className={`pagination-element ${isActive ? "active" : ""}`} onClick={callback}>
            {title}
        </div>
    );
};

export default PaginationElement;