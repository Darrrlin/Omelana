import React from 'react';
import MenuIcon from '@mui/icons-material/Menu';
import '../css'
import {IconButton} from "@mui/material";

const TitleBarMore = ({titlePage, openMenu}) => {
    return (
        <div className="title-block">
            <span className="hamburger-icon-block">
                <IconButton onClick={openMenu}>
                    <MenuIcon/>
                </IconButton>
            </span>
            <span className="title-page">
                {titlePage}
            </span>
        </div>
    );
};

export default TitleBarMore;