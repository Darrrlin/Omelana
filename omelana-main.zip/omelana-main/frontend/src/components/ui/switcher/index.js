import React, {useState} from 'react'
import './index.css'



const Switcher =(props) =>{
    const add = () =>{
        props.setValue(props.index+1)
    }
    const remove = () =>{
        props.setValue(props.index-1)
    }
    return(
        <div className='switcher' style={{fontSize:props.fontSize}}>
            {props.data[props.index]}  
            <span className='change-value-button' onClick={remove} >&lt;</span > 
            <span className='change-value-button' onClick={add}>&gt;</span>
        </div>
    )
}
export default Switcher;