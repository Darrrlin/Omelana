import React, {useEffect, useRef, useState} from 'react';
import "./index.css"

import Row from '../orderRow'


const Table = ({
                   removeCategory,
                   handleSelectAll,
                   selectElement,
                   head,
                   data,
                   uniteTablet,
                   uniteMobile,
                   greenState,
                   blueState,
                   redState,
                   greyState,
                   greenTitle,
                   blueTitle,
                   redTitle,
                   greyTitle,
                   underDataButtons,
                   isOpenContextMenu,
                   setIsOpenContextMenu,
                   blockWidth,
                   onClickElement,
                   selectAll
               }) => {
    const [showDeleteButton, setShowDeleteButton] = useState(false);
    const [startX, setStartX] = useState([]);
    const [translateX, setTranslateX] = useState([]);
    const [buttonPosition, setButtonPosition] = useState({left: 0, top: 0});
    const buttonWidth = underDataButtons ? underDataButtons.length * blockWidth : 0;
    const tableRef = useRef(null);
    const thRef = useRef(null);



    useEffect(() => {
        if (underDataButtons && underDataButtons.length > 0 && thRef.current && tableRef.current) {
            const tableRect = tableRef.current.getBoundingClientRect();
            const thRect = thRef.current.getBoundingClientRect();
            const buttonTop = thRect.top - tableRect.top;
            const buttonLeft = thRect.left - tableRect.left + thRect.width;
            setButtonPosition({left: buttonLeft, top: buttonTop});
        }
    }, [underDataButtons, thRef, tableRef]);

    useEffect(() => {
        window.addEventListener('click', (e) => {
            setIsOpenContextMenu(-1);
        })
    }, []);



    const handleDoubleClick = (e, index) => {
        if (e.detail === 2) {
            onClickElement(index);
        }
    }
    const handleTouchStart = (e, index) => {
        setStartX(prevStartX => {
            const updatedStartX = [...prevStartX];
            updatedStartX[index] = e.touches[0].clientX;
            return updatedStartX;
        });
    };

    const handleTouchMove = (e, index) => {
        const currentX = e.touches[0].clientX;
        const deltaX = currentX - startX[index];

        if (deltaX < -50) {
            setShowDeleteButton(true);
        } else if (deltaX > 50) {
            setShowDeleteButton(false);
        }
        if (!showDeleteButton && deltaX < 0) {
            setTranslateX(prevTranslateX => {
                const updatedTranslateX = [...prevTranslateX];
                updatedTranslateX[index] = deltaX;
                return updatedTranslateX;
            });
        }
    };

    const handleTouchEnd = (index) => {
        if (showDeleteButton) {
            setTranslateX(prevTranslateX => {
                const updatedTranslateX = [...prevTranslateX];
                updatedTranslateX[index] = -buttonWidth;
                return updatedTranslateX;
            });
        } else {
            setTranslateX(prevTranslateX => {
                const updatedTranslateX = [...prevTranslateX];
                updatedTranslateX[index] = 0;
                return updatedTranslateX;
            });
        }
    };

    const handleButtonClick = (e, onClick, index) => {
        onClick(e, index);
        setTranslateX(prevTranslateX => {
            const updatedTranslateX = [...prevTranslateX];
            updatedTranslateX[index] = 0;
            return updatedTranslateX;
        });
    };

    return (
        <div className='custom-table'>
            <div className='source-table' ref={tableRef}>
                <Row
                    isHeader={true}
                    head={head}
                    data={{}}
                    uniteTablet={uniteTablet}
                    greenState={greenState}
                    blueState={blueState}
                    redState={redState}
                    greyState={greyState}
                    greenTitle={greenTitle}
                    blueTitle={blueTitle}
                    redTitle={redTitle}
                    greyTitle={greyTitle}
                    isOpenContextMenu={isOpenContextMenu}
                    setIsOpenContextMenu={setIsOpenContextMenu}
                    underDataButtons={underDataButtons}
                    onClickElement={handleDoubleClick}
                    selectAll={selectAll}
                />
                {data.map((dataRow, indexDataRow) => (
                    <Row
                        key={`row-element-${indexDataRow}`}
                        selectElement={() => selectElement(indexDataRow)}
                        indexElement={indexDataRow}
                        head={head}
                        data={dataRow}
                        uniteTablet={uniteTablet}
                        greenState={greenState}
                        blueState={blueState}
                        redState={redState}
                        greyState={greyState}
                        greenTitle={greenTitle}
                        blueTitle={blueTitle}
                        redTitle={redTitle}
                        greyTitle={greyTitle}
                        isOpenContextMenu={isOpenContextMenu}
                        setIsOpenContextMenu={setIsOpenContextMenu}
                        underDataButtons={underDataButtons}
                        onClickElement={handleDoubleClick}
                        selectAll={selectAll}
                    />
                ))}
            </div>

            <table>
                <tbody className='phone-table'>
                {data.map((dataRow, index) => (
                    <tr key={index}>
                        <th ref={index === 0 ? thRef : null}>
                            <div className='value-row'>
                                <div
                                    className={`value-block ${dataRow.status === greyState ? "is-deleted" : ''}`}
                                    onClick={(e) => onClickElement(e, index)}
                                    onTouchStart={(e) => handleTouchStart(e, index)}
                                    onTouchMove={(e) => handleTouchMove(e, index)}
                                    onTouchEnd={() => handleTouchEnd(index)}
                                    style={{transform: `translateX(${translateX[index] || 0}px)`}}
                                >
                                    <div className="right-table-row-block-mobile">
                                        {uniteMobile.right.map((elementRightIndex, indexElementRightIndex) =>
                                            <div className={`element-row-block ${indexElementRightIndex === 0
                                                ? "first-element"
                                                : ''}`}
                                                 key={`right-table-row-block-mobile-${indexElementRightIndex}`}
                                            >
                                                <span>{elementRightIndex[1]}</span>
                                                {dataRow[head.optionsHeader[elementRightIndex[0]].keyData]}
                                            </div>
                                        )}
                                    </div>
                                    <div className="left-table-row-block-mobile">
                                        {uniteMobile.left.map((elementLeftIndex, indexElementLeftIndex) =>
                                            <div className={`element-row-block 
                                                ${head.optionsHeader[elementLeftIndex].keyData === "status" ? "status" : ""} 
                                                ${dataRow[head.optionsHeader[elementLeftIndex].keyData] === greenState ? "open-status" : ""} 
                                                ${dataRow[head.optionsHeader[elementLeftIndex].keyData] === blueState ? "process-status" : ""} 
                                                ${dataRow[head.optionsHeader[elementLeftIndex].keyData] === redState ? "close-status" : ""} 
                                                ${dataRow[head.optionsHeader[elementLeftIndex].keyData] === greyState ? "remove-status" : ""} 
                                                `}
                                                 key={`left-table-row-block-mobile-${indexElementLeftIndex}`}
                                            >
                                                {head.optionsHeader[elementLeftIndex].keyData === "status"
                                                    ? dataRow[head.optionsHeader[elementLeftIndex].keyData]
                                                    : dataRow[head.optionsHeader[elementLeftIndex].keyData] === greenState
                                                        ? greenTitle
                                                        : dataRow[head.optionsHeader[elementLeftIndex].keyData] === blueState
                                                            ? blueTitle
                                                            : dataRow[head.optionsHeader[elementLeftIndex].keyData] === redState
                                                                ? redTitle
                                                                : dataRow[head.optionsHeader[elementLeftIndex].keyData] === greyState
                                                                    ? greyTitle
                                                                    : dataRow[head.optionsHeader[elementLeftIndex].keyData]}
                                            </div>
                                        )}
                                    </div>
                                </div>

                                <div
                                    className="group-data-buttons"
                                    style={{
                                        left: `${buttonPosition.left - (blockWidth * underDataButtons.length)}px`
                                    }}
                                >
                                    {underDataButtons.map((button, index) => (
                                        <div
                                            style={{backgroundColor: button.color, width: blockWidth + 'px'}}
                                            key={index}
                                            className={`data-button`}

                                            onClick={(e) => handleButtonClick(e, button.onClick, index)}
                                        >
                                            <img alt="icon-button"
                                                 style={button.iconStyle}
                                                 src={button.iconSrc}
                                            />
                                            <span>{button.title}</span>
                                        </div>
                                    ))}
                                </div>

                            </div>

                        </th>
                    </tr>
                ))}
                </tbody>
            </table>

        </div>
    );
};

export default Table;
