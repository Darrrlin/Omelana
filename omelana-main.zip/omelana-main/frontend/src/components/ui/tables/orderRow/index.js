import React from 'react'
import "./index.css"
import CheckBox from "../../Inputs/CheckBox";
import MoreIcons from "../../icons/MoreIcons";
import inde from "../../../pages/CategoryPage/result";


const Row = ({
                 isHeader,
                 selectElement,
                 indexElement,
                 head,
                 data,
                 uniteTablet,
                 greenState,
                 blueState,
                 redState,
                 greyState,
                 greenTitle,
                 blueTitle,
                 redTitle,
                 greyTitle,
                 isOpenContextMenu,
                 setIsOpenContextMenu,
                 underDataButtons,
                 onClickElement,
                 selectAll
             }) => {



    return (
        <div className={`row ${isHeader ? "header" : ""} ${!isHeader && data.isSelected ? "selected" : ""}
         ${data.status === greyState ? "remove" : ""}`}
             onClick={onClickElement}
        >
            <div className="column checkbox">
                <CheckBox name={""} onChange={isHeader ? selectAll : () => selectElement(indexElement)} state={isHeader ? head.isSelectAll :data.isSelected}/>
            </div>

            {head.optionsHeader.map((headerElement, indexHeaderElement) =>

                <div className={`column data 
                ${uniteTablet.indexOf(indexHeaderElement) !== -1
                    ? uniteTablet.length && uniteTablet[0] === indexHeaderElement
                        ? "main-unite-tablet"
                        : "default-unite-tablet"
                    : ""}
                ${headerElement.keyData === "status" ? "status" : ""}
                ${!isHeader && data[headerElement.keyData] === greenState ? "open-status" : ""}
                ${!isHeader && data[headerElement.keyData] === blueState ? "process-status" : ""}
                ${!isHeader && data[headerElement.keyData] === redState ? "close-status" : ""}
                ${!isHeader && data[headerElement.keyData] === greyState ? "remove-status" : ""}
                `}
                    key={`table-row-${indexElement}-column-${indexHeaderElement}`}
                    style={{
                        "--desktop-width": headerElement.width,
                        "--tablet-width": headerElement.widthTablet
                    }}
                >
                    <span className="default-data"
                          key={`table-row-${indexElement}-column-${indexHeaderElement}-desktop`}>
                        {isHeader
                            ? headerElement.title
                            : headerElement.keyData !== "status"
                                ? data[headerElement.keyData]
                                : data[headerElement.keyData] === greenState
                                    ? greenTitle
                                    : data[headerElement.keyData] === blueState
                                        ? blueTitle
                                        : data[headerElement.keyData] === redState
                                            ? redTitle
                                            : data[headerElement.keyData] === greyState
                                                ? greyTitle
                                                : ""}
                    </span>
                    {uniteTablet.indexOf(indexHeaderElement) === 0 && uniteTablet.length && uniteTablet[0] &&
                        <span className="tablet-data"
                              key={`table-row-${indexElement}-column-${indexHeaderElement}-tablet`}>
                            {isHeader
                                ? headerElement.title
                                : uniteTablet.map((uniteElement, indexUniteElement) =>
                                    <div className="inite-block"
                                         key={`table-row-${indexElement}-column-${indexHeaderElement}-tablet-${indexUniteElement}`}>
                                        {data[head.optionsHeader[uniteElement].keyData]}
                                    </div>
                                )}
                        </span>
                    }

                </div>
            )}

            <div className="column more-button" onClick={(e) => {
                e.stopPropagation();
                e.preventDefault();
            }}>
                <MoreIcons className="icon-block" onClick={() => setIsOpenContextMenu(indexElement)}/>
                <div className={`context-menu ${isOpenContextMenu === indexElement ? "show" : ""}`}>
                    {underDataButtons.map((_element, indexContextMenu) =>
                        <div
                            key={`table-context-menu-element-${indexContextMenu}`}
                            className="list-element"
                            onClick={(e) => {
                                setIsOpenContextMenu(false);
                                _element.action(e, indexElement);
                            }}>
                            {_element.title}
                        </div>
                    )}

                </div>
            </div>
        </div>
    )
}
export default Row;