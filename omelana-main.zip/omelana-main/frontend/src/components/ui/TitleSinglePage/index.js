import TitleSinglePage from "./result";

export default TitleSinglePage;