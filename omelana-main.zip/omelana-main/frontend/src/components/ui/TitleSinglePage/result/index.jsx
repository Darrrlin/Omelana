import React from 'react';
import {Link} from "react-router-dom";
import MenuIcon from "@mui/icons-material/Menu";
import LeftArrowIcon from "../../icons/LeftArrowIcon";

import '../css';

const TitleSinglePage = ({
                             children,
                             tabletIcon,
                             mobileIcon,
                             actionIcon,
                             sectionTitle,
                             sectionPath,
                             mainTitle,
                             mainTitleName,
                             actionMainButton,
                             styleClassMainButton,
                             icon
                         }) => {
    return (
        <div className="header-single-page">
            <div className="links">
                <Link className="section-title" to={sectionPath}>{sectionTitle}</Link>
                <span className="main-title">{mainTitleName}</span>
            </div>
            <div className="tablet-title">
                {tabletIcon !== undefined
                    ? tabletIcon === "arrow"
                        ? <LeftArrowIcon className="action-icon" onClick={actionIcon}/>
                        : <MenuIcon className="action-icon" onClick={actionIcon}/>
                    : null
                }
                <span className={`title`}>{mainTitle}</span>
            </div>

            <div className="mobile-title">
                {mobileIcon !== undefined
                    ? mobileIcon === "arrow"
                        ? <LeftArrowIcon className="action-icon" onClick={actionIcon}/>
                        : <MenuIcon className="action-icon" onClick={actionIcon}/>
                    : null
                }
                <span className={`title ${!mobileIcon ? "not-icon" : ""}`}>{mainTitle}</span>
            </div>
            <div className="action-main-block">
                <button className={`header-action ${
                    styleClassMainButton === "secondary"
                        ? "secondary-button"
                        : styleClassMainButton === "primary"
                            ? "primary-button"
                            : "minor-button"
                }`} onClick={actionMainButton}>
                    {icon &&
                            React.createElement(icon, {className: "icon-button"}, null)
                    }
                    {children}
                </button>
            </div>
        </div>
    );
};

export default TitleSinglePage;