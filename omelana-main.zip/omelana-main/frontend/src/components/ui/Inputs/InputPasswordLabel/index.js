import React from 'react';
import {
    FormControl,
    FormLabel,
    IconButton,
} from "@mui/material";
import {Visibility, VisibilityOff} from "@mui/icons-material";
import '../input.css';
import {theme} from "../../../config/deisgn/mui.config";

const InputPasswordLabel = ({className, value, onChange, label, prefixLabel, errorText, sx}) => {
    const [showPassword, setShowPassword] = React.useState(false);

    const handleClickShowPassword = () => setShowPassword((show) => !show);

    const handleMouseDownPassword = (event) => {
        event.preventDefault();
    };

    return (
        <FormControl className={className} sx={{
            width: "100%",
            display: 'block',
            ...sx
        }}>
            <FormLabel sx={{
                display: "block",
                fontSize: "max(14px, .97vw)",
                fontWeight: "500",
                color:   "#9A989B"
            }}>
                {label}
            </FormLabel>

            <div className='form-group'>
                <input
                    className={`form-input ${!!errorText ? 'error' : ''}`}
                    id={`form-control-password-${prefixLabel}`}
                    type={showPassword ? 'text' : 'password'}
                    value={value}
                    onChange={onChange}
                />
                <div className='icon-group' >
                    <IconButton
                        aria-label="toggle password visibility"
                        onClick={handleClickShowPassword}
                        onMouseDown={handleMouseDownPassword}
                        edge="end"
                    >
                        {showPassword
                            ? <VisibilityOff sx={{
                                color: !!errorText ? theme.palette.warning.main : "#686B6F"
                            }}/>
                            : <Visibility sx={{
                                color: !!errorText ? theme.palette.warning.main : "#686B6F"
                            }}/>}
                    </IconButton>
                </div>
            </div>
            {!!errorText &&
                <FormLabel
                    sx={{
                        marginTop: '3pd',
                        fontSize: 'max(14px, .83vw)',
                        color: theme.palette.error.main
                    }}
                >
                    {errorText}
                </FormLabel>
            }
        </FormControl>
    );
};

export default InputPasswordLabel;