import React, {useState} from 'react'
import './index.css'

const TextArea = ({width, height, title, defaultValue, onChange, error})=>{
    return(
        <div className='text-area-block'>
            <div>{title}</div>
            <textarea value={defaultValue} className={
                `${error==='' ? 'text-area-element' : 'text-area-element text-area-element-error'}`
            }
            
            width={width} style={{'minHeight':height}} onChange={onChange} >

            </textarea>
        </div>
    )
}
export default TextArea;