import AutocompleteInput from "./result";

export default AutocompleteInput;