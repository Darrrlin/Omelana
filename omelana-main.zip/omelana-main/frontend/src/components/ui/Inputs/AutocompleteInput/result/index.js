import React, { useState } from 'react';
import '../css/index.css';

const AutocompleteInput = ({ options, hasError, title }) => {
  const [inputValue, setInputValue] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(false);

  const handleInputChange = (event) => {
    const value = event.target.value;
    setInputValue(value);

    if (value.length >= 3) {
      setShowSuggestions(true);
    } else {
      setShowSuggestions(false);
    }
  };

  const handleOptionClick = (value) => {
    setInputValue(value);
    setShowSuggestions(false);
  };

  const filteredOptions = options.filter((option) =>
    option.toLowerCase().startsWith(inputValue.toLowerCase())
  );

  return (
    <div className={`input ${hasError ? 'error' : ''}`}>
      <span className='autocomplete-input-title'>
        {title}
      </span>
      <span className='input-image'></span>
      <input
        className={`desktop ${hasError ? 'error' : ''}`}
        placeholder=''
        type='text'
        value={inputValue}
        onChange={handleInputChange}
      />
      {showSuggestions && (
        <div className='suggestions'>
          {filteredOptions.length > 0 ? (
            filteredOptions.map((option, index) => (
              <div
                key={index}
                onClick={() => handleOptionClick(option)}
                className='suggestion'
              >
                {option}
              </div>
            ))
          ) : (
            <div className='no-suggestions'>Немає пропозицій</div>
          )}
        </div>
      )}
    </div>
  );
};

export default AutocompleteInput;
