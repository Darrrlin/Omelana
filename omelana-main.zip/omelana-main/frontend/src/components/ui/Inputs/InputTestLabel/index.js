import React from 'react';
import {
    FormControl, FormLabel,
} from "@mui/material";
import '../input.css';
import WarningIcon from "../../icons/WarningIcon";
import {theme} from "../../../config/deisgn/mui.config";

const InputTextLabel = ({className, value, onChange, label, prefixLabel, errorText, sx}) => {
    return (
        <FormControl className={className} sx={{
            width: "100%",
            display: 'block',
            ...sx
        }}>
            <FormLabel sx={{
                display: "block",
                fontSize: "max(14px, .97vw)",
                fontWeight: "500",
                color: "#9A989B"
            }}>
                {label}
            </FormLabel>

            <div className='form-group'>
                <input
                    className={`form-input ${!!errorText ? 'error' : ''}`}
                    id={`form-control-password-${prefixLabel}`}
                    type='text'
                    value={value}
                    onChange={onChange}
                />
                <div className='icon-group warning'>
                    {errorText &&
                        <WarningIcon edge="end" sx={{
                            color: !!errorText ? theme.palette.warning.main : "#686B6F"
                        }}/>
                    }
                </div>
            </div>
            {!!errorText &&
                <FormLabel
                    sx={{
                        marginTop: '3pd',
                        fontSize: 'max(12px, .83vw)',
                        color: theme.palette.error.main
                    }}
                >
                    {errorText}
                </FormLabel>
            }
        </FormControl>
    );
};

export default InputTextLabel;