import React from 'react';

import './index.css';
const CircleCheckBox = ({name, state, setState}) => {
    return (
        <div className="container">
            <div className="round">
                <input type="checkbox" checked={state} onChange={setState} id={`checkbox-${name}`}/>
                <label htmlFor={`checkbox-${name}`}></label>
            </div>
        </div>
    );
};

export default CircleCheckBox;