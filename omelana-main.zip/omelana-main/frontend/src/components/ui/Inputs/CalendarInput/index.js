import CalendarInput from "./result";

export default CalendarInput;