import React from 'react';

import '../css/index.css';

const CalendarInput = ({state, setState, label}) => {
    return (
        <div className="form-calendar-input">
            <div className="title">{label}</div>
            <input value={state} onChange={(event)=> {
                setState(event.target.value);
            }} type="date" className="form-input"/>
        </div>
    );
};

export default CalendarInput;