import React, {useState} from 'react';

import './index.css'

const InputDiscount = ({label, state, setState, error}) => {
    const [isFocus, setIsFocus] = useState(false);

    return (
        <div className="form-discount-data">
            <div className="title">{label}</div>

            <div className={`form-input ${isFocus ? "focus" : error ? "error" : ""}`}>
                <input value={state} onChange={(event) => setState(event.target.value)}
                       onFocus={() => setIsFocus(true)}
                       onBlur={(() => setIsFocus(false))}
                />
            </div>

            {error &&
                <div className="input-discount-error">{error}</div>
            }
        </div>
    );
};

export default InputDiscount;