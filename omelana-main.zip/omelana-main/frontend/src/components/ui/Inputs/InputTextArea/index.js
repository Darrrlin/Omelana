import React from 'react';

import './index.css'

const InputTextArea = ({label, state, setState, error, height}) => {
    return (
        <div className="form-text-area">
            <div className="title">{label}</div>

            <textarea
                style={{height: `${height}`}}
                className={`input-text-area ${error ? "error" : ""}`}
                value={state}
                onChange={(event) => setState(event.target.value)}
            />

            {error &&
                <div className="input-text-area-error">{error}</div>
            }
        </div>
    );
};

export default InputTextArea;