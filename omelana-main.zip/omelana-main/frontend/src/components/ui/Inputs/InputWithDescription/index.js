import React, {useState} from 'react';

import './index.css'

const InputWithDescription = ({label, state, setState, error, desc, isSpecific}) => {
    const [isFocus, setIsFocus] = useState(false);

    const changeValue = (value) => {
        if (/^\d*(\.|,)?\d*$/.test(value)) {
            setState(value);
        }
    }

    return (
        <div className={`form-description-data`}>
            <div className="title">{label}</div>

            <div className={`input-description ${isFocus ? "focus" : error ? "error" : ""}`}>
                <div className={`form-input ${isSpecific ? "specific" : ""}`}>
                    <input value={state} onChange={(event) => changeValue(event.target.value)}
                           onFocus={() => setIsFocus(true)}
                           onBlur={(() => setIsFocus(false))}
                    />
                </div>
                <div className="input-description-title">
                    {desc}
                </div>
            </div>

            {error &&
                <div className="input-description-error">{error}</div>
            }
        </div>
    );
};

export default InputWithDescription;