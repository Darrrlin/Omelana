import React, {useEffect} from 'react';

import './index.css';

const CheckBox = ({state, name, onChange}) => {
    return (
        <span className="checkbox" onClick={onChange}>
            <input className="custom-checkbox" type="checkbox" id={name} name={name} checked={state} onChange={() => {}} />
            <label htmlFor={name} ></label>
        </span>
);
};

export default CheckBox;