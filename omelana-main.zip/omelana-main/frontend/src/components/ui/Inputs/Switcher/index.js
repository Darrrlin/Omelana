import React, {useEffect} from 'react';

import './index.css';

const Switcher = ({state, setState}) => {
    return (
        <label className="switcher-box" onMouseUp={() => setState(!state)}>
            <input checked={state} onChange={() => {}} type="checkbox" />
            <span className="slider"></span>
        </label>
    );
};

export default Switcher;