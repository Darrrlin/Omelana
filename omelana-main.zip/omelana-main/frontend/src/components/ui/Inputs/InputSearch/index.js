import React from 'react'
import './index.css'
import SearchIcon from "../../icons/SearchIcon";

const InputSearch = ({desktop, phone, actionSearch, state, setState}) => {

    const handleKeyDown = (event) => {
        if (event.key === 'Enter') {
            actionSearch();
        }
    };

    return (
        <div className='input'>
            <SearchIcon className="input-image" onClick={actionSearch}/>
            <input className='desktop' placeholder={desktop} type='text' value={state}
                   onChange={(e) => setState(e.target.value)}
                   onKeyDown={handleKeyDown}
            />
            <input className='phone' placeholder={phone} type='text' value={state}
                   onChange={(e) => setState(e.target.value)}
                   onKeyDown={handleKeyDown}
            />
        </div>

    )
}
export default InputSearch;