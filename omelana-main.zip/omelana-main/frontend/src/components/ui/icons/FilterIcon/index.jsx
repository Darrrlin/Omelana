import React from 'react';

const FilterIcon = (props) => {
    return (
        <div>
            <svg {...props} viewBox="0 0 24 24" fill="none">
                <path d="M7 5H18V6.33907H17.9511L13.7222 10.9723V19L11.2778 16.3219V10.9656L7.055 6.33907H7V5Z" fill="#6E6C6E"/>
            </svg>
        </div>
    );
};

export default FilterIcon;