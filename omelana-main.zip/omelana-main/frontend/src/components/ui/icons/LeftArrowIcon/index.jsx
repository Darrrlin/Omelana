import React from 'react';

const LeftArrowIcon = (props) => {
    return (
        <svg {...props} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path fillRule="evenodd" clipRule="evenodd" d="M27.6573 37.999C27.0733 37.999 26.4933 37.745 26.0973 37.253L16.4413 25.253C15.8453 24.511 15.8533 23.451 16.4633 22.719L26.4633 10.719C27.1693 9.87099 28.4313 9.75699 29.2813 10.463C30.1293 11.169 30.2433 12.431 29.5353 13.279L20.5853 24.021L29.2153 34.745C29.9073 35.605 29.7713 36.865 28.9093 37.557C28.5413 37.855 28.0973 37.999 27.6573 37.999Z" fill="#212020"/>
        </svg>
    );
};

export default LeftArrowIcon;