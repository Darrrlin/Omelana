import React, {useEffect, useState} from 'react';

import '../css/index.css';
import {createPortal} from "react-dom";

const Modal = ({children, key, isOpen, setIsOpen}) => {
    const [height, setHeight] = useState("100%");

    useEffect(() => {
        if (isOpen) {
            const body = document.body,
                html = document.documentElement;

            setHeight(Math.max(body.scrollHeight, body.offsetHeight,
                html.clientHeight, html.scrollHeight, html.offsetHeight));
        }
    }, [isOpen]);


    return (
        <>
            {createPortal(
                <div className={`main-modal ${isOpen ? "open" : ""}`} style={{height: `${height}px`}}>
                    <div className="modal-background" onClick={(event) => setIsOpen(false)}
                         style={{height: `${height}px`}}>
                    </div>
                    {children}
                </div>,
                document.body,
                key
            )}
        </>
    );
};

export default Modal;