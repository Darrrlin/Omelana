import Modal from "./result";

export {
    Modal
}