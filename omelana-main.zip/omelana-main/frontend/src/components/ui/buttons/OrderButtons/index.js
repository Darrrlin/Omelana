import React from 'react'
import './button.css'


const ButtonAdd  = (props)=>{
    return(
        <div className='headerBlock'>
            <span>
                <span>III</span>
                <h1 className='headerTitle'>Замовлення</h1>
            </span>
            <div className='invis-block'></div>
            <span className='buttonContainer'>
                <div className='button desktop'>
                    {props.desktop}
                </div>
                <div className='button phone'>
                    {props.phone}
                </div>
            </span>
        </div>

    )
}
export default ButtonAdd;