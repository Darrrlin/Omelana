import React from 'react'
import './index.css'


const Button  = (props)=>{
    return(
        <div className='header-block' onClick={props.onClick}>
            <div className='first'>
                <span className='icon'>
                    III
                </span>
                <span className='arrow'>
                    <h1>
                        &lt;
                    </h1>

                </span>

            </div>
            <div className='second'>
                {props.header}
            </div>
            <div className='third'>
                <div className='button'>
                    {props.text}
                </div>  
            </div>
        </div>

    )
}
export default Button;