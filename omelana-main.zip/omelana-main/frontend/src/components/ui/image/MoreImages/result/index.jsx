import React, {useCallback} from 'react';

import '../css';
import convertToBase64 from "../../../../uttils/helper/uttils/ImgeReader";
import DeleteIcon from "../../../icons/DeleteIcon";
import ImageIcon from "../../../icons/ImageIcon";
const MoreImages = ({width, height, imageData, setImageData, error, setError, listSelect, setListSelect, deletedImageData}) => {


    const handleChangeImage = useCallback(async (e) => {
        const file = e.target.files[0];
        convertToBase64(file).then((data) => {
            setImageData([...imageData, {imageUrl: data, image:file, isNew: true}])
        }).catch((error) => {
            setError(true);
        });

    }, [setError])

    const deleteImage = (index) => {
        deletedImageData(index)
    }

    const handleChangeMixin = (index) => {
        if (listSelect.indexOf(index) !== -1) {
            setListSelect(listSelect.filter(element => element !== index));
        } else {
            setListSelect([...listSelect, index])
        }
    }

    return (
        <div className="more-image-block">
            { imageData.map((element, index) =>
                <div
                    className="image-block"
                    key={`image-block-${index}`}
                >
                    <img src={element.imageUrl} className="image-source" alt="Фото" key={`image-source-${index}`}/>
                    <div className="hover-block" key={`hover-block-${index}`}>
                        <div className={`hover-mixing ${listSelect.indexOf(index) !== -1 ? "active" : ""}`}
                             onClick={() => handleChangeMixin(index)}
                             key={`hover-mixing-${index}`}
                        >
                            {listSelect.indexOf(index) !== -1 ? listSelect.indexOf(index) + 1 : ""}
                        </div>
                        <div className="hover-action" onClick={() => deleteImage(index)}
                             key={`hover-action-${index}`}
                        >
                            <DeleteIcon className={"action-icon"}
                                        key={`action-icon-${index}`}
                            />
                            <span className="action-text"
                                  key={`action-text-${index}`}
                            >Видалити</span>
                        </div>
                    </div>
                </div>
            )}
            <label className={`add-image ${error ? "error" : ""}`} style={{width: width, height: height}}>
                <ImageIcon className={"image-icon"} />
                <span className="sub-text">Завантажити фото</span>
                <input
                    type="file"
                    accept="image/*, png, jpeg, jpg"
                    style={{display: 'none'}}
                    onChange={handleChangeImage}
                />
            </label>
        </div>
    );
};

export default MoreImages;