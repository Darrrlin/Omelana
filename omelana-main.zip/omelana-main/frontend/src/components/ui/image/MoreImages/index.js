import MoreImages from "./result";

export {
    MoreImages
}