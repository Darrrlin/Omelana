import OneImage from "./result";

export {
    OneImage
}