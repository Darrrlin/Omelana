import React, {useCallback} from 'react';

import '../css';
import ImageIcon from "../../../icons/ImageIcon";
import convertToBase64 from "../../../../uttils/helper/uttils/ImgeReader";
import DeleteIcon from "../../../icons/DeleteIcon";
const OneImage = ({width, height, imageUrl, setImageUrl, setImage, title, error, setError}) => {

    const handleChangeImage = useCallback(async (e) => {
        const file = e.target.files[0];
        convertToBase64(file).then((data) => {
            setImage(file);
            setImageUrl(data);
        }).catch((error) => {
            setError(true);
        });

    }, [setError])

    const deleteImage = () => {
        setError(false);
        setImageUrl(null);
        setImage(null);
    }

    return (
        <div className="one-image-block">
            <div className="title-image-block">
                {title}
            </div>
            {imageUrl
                ? <div className="image-block" style={{width: width, height: height}}>
                    <img src={imageUrl} className="image-source" alt="Фото"/>
                    <div className="hover-block">
                        <div className="hover-action" onClick={deleteImage}>
                            <DeleteIcon className={"action-icon"} />
                            <span className="action-text">Видалити</span>
                        </div>
                    </div>
                </div>
                : <label className={`add-image ${error ? "error" : ""}`} style={{width: width, height: height}}>
                    <ImageIcon className={"image-icon"} />
                    <span className="sub-text">Завантажити фото</span>
                    <input
                        type="file"
                        accept="image/*, png, jpeg, jpg"
                        style={{display: 'none'}}
                        onChange={handleChangeImage}
                    />
                </label>
            }
        </div>
    );
};

export default OneImage;