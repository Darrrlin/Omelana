import {OneImage} from "./OneImage";
import {MoreImages} from "./MoreImages";

export {
    OneImage,
    MoreImages
}