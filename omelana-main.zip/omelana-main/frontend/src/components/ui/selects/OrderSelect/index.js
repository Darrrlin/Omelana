import React, { useState, useRef, useEffect } from 'react';
import './index.css'


const Select = ({options, value, onChange, defaultValuePhone, defaultValueDesctop})=>{
  const [isOpen, setIsOpen] = useState(false);
  const [selectedOption, setSelectedOption] = useState(null);
  const selectRef = useRef();

  const toggleSelect = () => {
    setIsOpen(!isOpen);
  };

  const handleOptionSelect = (option) => {
    setSelectedOption(option);
    setIsOpen(false);
    onChange(option.value);
  };

  const handleClickOutside = (event) => {
    if (selectRef.current && !selectRef.current.contains(event.target)) {
      setIsOpen(false);
    }
  };

  const handleMouseDown = (event) => {
    event.preventDefault();
  };

  const handleMouseEnter = () => {
    document.body.style.cursor = 'pointer';
  };

  const handleMouseLeave = () => {
    document.body.style.cursor = 'default';
  };

  useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
  return(
      <div className="custom-select" ref={selectRef}>
        <div className="selected-option" onClick={toggleSelect}>
        <span className="desktop"> {selectedOption ? selectedOption.name : defaultValueDesctop}</span>
        <span className="mobile"> {selectedOption ? selectedOption.name : defaultValuePhone} </span>
        </div>
        {isOpen && (
          <ul className="options-list" onMouseDown={handleMouseDown}>
            {options.map((option) => (
              <li
                key={option.value}
                onClick={() => handleOptionSelect(option)}
                onMouseEnter={handleMouseEnter}
                onMouseLeave={handleMouseLeave}
                className={selectedOption === option ? 'selected' : ''}
              >
                {option.name}
              </li>
            ))}
          </ul>
        )}
      </div>
  )
}
export default Select;