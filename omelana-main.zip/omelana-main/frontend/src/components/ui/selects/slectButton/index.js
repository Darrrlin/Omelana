import React, {useState} from 'react'
import './index.css'

const SelectButton=(props)=>{
    const [isSelected, setIsSelected] = useState(false);
      
        const handleClick = () => {
          if(props.selectAll===true){
            if (isSelected){
              for(let i = 0; i < props.valuesCount-1; i++){
                document.getElementById(i).classList.remove('selected');
              }
            }
            else{
              for(let i = 0; i < props.valuesCount-1; i++){
                document.getElementById(i).classList.add('selected');
              }
            }
          }
          setIsSelected(!isSelected);
          document.getElementById(props.id).classList.add('selected');
          if (isSelected){
            document.getElementById(props.id).classList.remove('selected');
          }else{
            document.getElementById(props.id).classList.add('selected');
          }
        };
    return(
        <div className={`custom-block ${isSelected ? 'selected' : ''}`} onClick={handleClick}>
            <span className="checkmark">&#10004;</span>
        </div>
    )
}
export default SelectButton;