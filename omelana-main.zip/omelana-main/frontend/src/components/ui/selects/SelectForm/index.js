import React from 'react';

import './index.css';
import SelectUI from "../SelectUI";

const SelectForm = ({title, option, state, setState, defaultTitle}) => {
    return (
        <div className="select-form">
            <div className="title">{title}</div>
            <SelectUI
                option={option}
                state={state}
                setState={setState}
                defaultTitle={defaultTitle}
            />
        </div>
    );
};

export default SelectForm;