import React, {useEffect, useRef, useState} from 'react';

import './index.css'

const SelectUI = ({option, state, setState, defaultTitle, error}) => {
    const [isOpen, setIsOpen] = useState(false);
    const selectContainer = useRef(null);

    useEffect(() => {
        window.addEventListener("click", (event) => {
            setIsOpen(false);
        })

    }, []);

    return (
        <div className={`select-box ${isOpen ? "open" : ""}`} ref={selectContainer} onClick={(event) => {
            event.stopPropagation();
            event.preventDefault();
            setIsOpen(!isOpen);
        }}>
            <div className={`select-title ${!Number.isInteger(state) || state === -1 ? "secondary" : ""} ${error ? "error": ""}`}>
                {Number.isInteger(state) && state !== -1 ? option[state].text : defaultTitle}
            </div>
            <div className="list-select">
                {option.map((element, index) => {
                        return (<div
                            className={`list-select-element ${index === state ? "selected" : ""}`}
                            key={`list-element-${index}`}
                            onClick={() => setState(index)}
                        >
                            {element.text}
                        </div>)
                    }
                )}
            </div>
        </div>
    );
};

export default SelectUI;