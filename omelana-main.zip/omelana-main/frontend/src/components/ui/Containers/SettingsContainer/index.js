import React, {useState} from 'react'
import './index.css'

function SettingsContainer(props){
    return(
        <div className='settings-container'>
            {props.items.map((item)=>
                item
            )}
        </div>
    )
}
export default SettingsContainer;