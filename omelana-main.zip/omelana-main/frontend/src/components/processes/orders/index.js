import {useRemoveOrderMutation, 
    useUpdateOrderMutation, 
    useGetOrderMutation, 
    useGetOrdersMutation,
    useChangeStatusOrdersMutation, 
    moduleApiSlice} from "./api/moduleApiSlice";

export {
    moduleApiSlice as OrdersApiSlice,
    useRemoveOrderMutation, 
    useUpdateOrderMutation, 
    useGetOrderMutation, 
    useGetOrdersMutation,
    useChangeStatusOrdersMutation
}