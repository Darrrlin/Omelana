import {apiSlice} from "../../../uttils/api/apiSlice";

export const moduleApiSlice = apiSlice.injectEndpoints({
    endpoints: build => ({
        removeOrder: build.mutation({
            query: id => ({
                url: `orders/orderlist/${id}`,
                method: 'DELETE',
            })
        }),
        updateOrder: build.mutation({
            query: credentials => ({
                url: "category/admin/element",
                method: 'POST',
                body: {...credentials, type_methods: "UPDATE"}
            })
        }),
        getOrder: build.mutation({
            query: id => ({
                url: `category/admin/element?id=${id}`,
                method: 'GET',
            })
        }),
        getOrders: build.mutation({
            query: id => ({
                url: `orders/orderslist/`,
                method: 'GET',
            })
        }),
        changeStatusOrders: build.mutation({
            query: credentials => {
                return {
                    url: "orders/orderupdate/",
                    method: 'POST',
                    body: credentials,
                }
            }
        }),

    })
});

export const {
    useRemoveOrderMutation, 
    useUpdateOrderMutation, 
    useGetOrderMutation, 
    useGetOrdersMutation,
    useChangeStatusOrdersMutation} = moduleApiSlice;