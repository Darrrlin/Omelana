import {
    useUpdateSettingsMutation,
    useGetSettingsMutation,
    moduleApiSlice
} from "./api/moduleApiSlice";

export {
    moduleApiSlice as SettingsApiSlice,
    useUpdateSettingsMutation,
    useGetSettingsMutation,

}