import {apiSlice} from "../../../uttils/api/apiSlice";

export const moduleApiSlice = apiSlice.injectEndpoints({
    endpoints: build => ({
        updateSettings: build.mutation({
            query: credentials => ({
                url: "settings/changeSetting/",
                method: 'POST',
                body: credentials,
                formData: true
            })
        }),
        getSettings: build.mutation({
            query: id => ({
                url: `settings/settingslist/`,
                method: 'GET',
            })
        }),
    })
});

export const {
    useUpdateSettingsMutation,
    useGetSettingsMutation,
} = moduleApiSlice;