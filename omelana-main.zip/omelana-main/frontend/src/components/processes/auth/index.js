import {moduleSlice, setCredential, selectCurrentToken, selectCurrentUser, logOut} from "./store/moduleSlice";
import {moduleApiSlice, useLoginMutation, useLogoutMutation, useLogoutAllMutation, useChangePasswordMutation} from "./api/moduleApiSlice";

export {
    moduleSlice as AuthSlice,
    moduleApiSlice as AuthApiSlice,
    useLoginMutation,
    useLogoutAllMutation,
    useLogoutMutation,
    useChangePasswordMutation,
    setCredential,
    selectCurrentUser,
    selectCurrentToken,
    logOut
};