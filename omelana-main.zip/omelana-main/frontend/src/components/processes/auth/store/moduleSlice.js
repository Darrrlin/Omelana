import {createSlice} from "@reduxjs/toolkit";
import JWTDecoder from "../../../uttils/helper/uttils/JWTDecoder";

const initialState = {
    accessToken: "",
    user: undefined,
}

export const moduleSlice = createSlice({
    name: "auth",
    initialState,
    reducers: {
        setCredential: (state, action) => {
            const accessToken = action.payload.access,
                userData = JWTDecoder(accessToken),
                user= {
                    username: userData.username,
            };

            state.accessToken = accessToken;
            state.user = user;
        },
        logOut: (state, action) => {
           state.accessToken = "";
           state.user = undefined;
        }
    }
});

export const {setCredential, logOut} = moduleSlice.actions

export const selectCurrentUser = (state) => state.auth.user;
export const selectCurrentToken = (state) => state.auth.accessToken;