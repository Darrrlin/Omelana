import {apiSlice} from "../../../uttils/api/apiSlice";

export const moduleApiSlice = apiSlice.injectEndpoints({
    endpoints: build => ({
        login: build.mutation({
            query: credentials => ({
                url: "auth/login/",
                method: 'POST',
                body: {...credentials}
            })
        }),
        logout: build.mutation({
            query: () => ({
                url: "auth/logout/",
                method: 'POST',
                body: {}
            })
        }),
        logoutAll: build.mutation({
            query: () => ({
                url: "auth/logout-all/",
                method: 'POST',
                body: {}
            })
        }),
        changePassword: build.mutation({
            query: (credential) => ({
                url: "auth/change-password/",
                method: 'POST',
                body: credential
            })
        }),
    })
});

export const {useLoginMutation, useLogoutAllMutation, useLogoutMutation, useChangePasswordMutation} = moduleApiSlice;