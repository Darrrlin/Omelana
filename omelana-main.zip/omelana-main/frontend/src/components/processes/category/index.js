import {
    moduleApiSlice,
    useCreateCategoryMutation,
    useGetCategoriesMutation,
    useGetCategoryMutation,
    useUpdateCategoryMutation,
    useRemoveCategoryMutation,
    useCopyCategoryMutation
} from "./api/moduleApiSlice";

export {
    moduleApiSlice as CategoryApiSlice,
    useCreateCategoryMutation,
    useUpdateCategoryMutation,
    useGetCategoryMutation,
    useGetCategoriesMutation,
    useRemoveCategoryMutation,
    useCopyCategoryMutation
}