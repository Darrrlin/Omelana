import {apiSlice} from "../../../uttils/api/apiSlice";

export const moduleApiSlice = apiSlice.injectEndpoints({
    endpoints: build => ({
        createCategory: build.mutation({
            query: credentials => ({
                url: "category/admin/element",
                method: 'POST',
                body: credentials,
                formData: true
            })
        }),
        updateCategory: build.mutation({
            query: credentials => ({
                url: "category/admin/element",
                method: 'POST',
                body: credentials,
                formData: true
            })
        }),
        removeCategory: build.mutation({
            query: id => ({
                url: `category/admin/element?id=${id}`,
                method: 'DELETE'
            })
        }),
        getCategory: build.mutation({
            query: id => ({
                url: `category/admin/element?id=${id}`,
                method: 'GET',
            })
        }),
        getCategories: build.mutation({
            query: isFullInformation => ({
                url: `category/admin/elements?type=${isFullInformation ? "full" : "short"}`,
                method: 'GET',
            })
        }),
        copyCategory: build.mutation({
            query: id => ({
                url: `category/admin/element?id=${id}`,
                method: 'PUT'
            })
        }),
    })
});

export const {
    useCreateCategoryMutation,
    useUpdateCategoryMutation,
    useGetCategoryMutation,
    useGetCategoriesMutation,
    useRemoveCategoryMutation,
    useCopyCategoryMutation
} = moduleApiSlice;