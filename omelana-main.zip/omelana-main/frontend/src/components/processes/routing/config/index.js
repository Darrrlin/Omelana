import React from "react";
import SettingIcon from "../../../ui/icons/SettingIcon";
import PlugPage from "../../../pages/PlugPage/result"
import StatisticIcon from "../../../ui/icons/StatisticIcon";
import OrdersIcon from "../../../ui/icons/OrdersIcon";
import ProductsIcon from "../../../ui/icons/ProductsIcon";
import CategoryIcon from "../../../ui/icons/CategoryIcon";
import PersonIcon from "../../../ui/icons/PersonIcon";
// import {CreateCategoryPage} from "../../../pages/CreateCategoryPage";
// import {ChangeCategoryPage} from "../../../pages/ChangeCategoryPage";
// import {OrderPage} from '../../../pages/OrdersPage'
// import {SettingsMain} from '../../../pages/SettingsPage/MainPage'
// import {CategorySettings} from '../../../pages/SettingsPage/CategorySettings'
// import {OrdersAndPayments} from '../../../pages/SettingsPage/OrdersAndPayments'
// import {UserAgreement} from '../../../pages/SettingsPage/UserAgreement'
// import {Contacts} from '../../../pages/SettingsPage/Contacts'
// import {CategoryPage} from "../../../pages/CategoryPage";
// import AccountPage from "../../../pages/Account Page/result";
// import {StatisticPage} from '../../../pages/Statistic Page'
// import {PersonalData} from '../../../pages/SettingsPage/PersonalData'
// import {CreateProductPage, ProductPage} from "../../../pages/ProductsPages";
// import {AddEditOderPage} from '../../../pages/AddEditOderPage'
// import TableProductsPage from "../../../pages/ProductsPages/TableProductsPage";
const LoginPage = React.lazy(() => import('../../../pages/LoginPage/result'));

const CreateCategoryPage = React.lazy(() => import('../../../pages/CreateCategoryPage/result'));
const ChangeCategoryPage = React.lazy(() => import('../../../pages/ChangeCategoryPage/result'));
const OrderPage = React.lazy(() => import('../../../pages/OrdersPage/result'));
const SettingsMain = React.lazy(() => import('../../../pages/SettingsPage/MainPage/result'));
const CategorySettings = React.lazy(() => import('../../../pages/SettingsPage/CategorySettings/result'));
const OrdersAndPayments = React.lazy(() => import('../../../pages/SettingsPage/OrdersAndPayments/result'));
const UserAgreement = React.lazy(() => import('../../../pages/SettingsPage/UserAgreement/result'));
const Contacts = React.lazy(() => import('../../../pages/SettingsPage/Contacts/result'));
const CategoryPage = React.lazy(() => import('../../../pages/CategoryPage/result'));
const AccountPage = React.lazy(() => import('../../../pages/Account Page/result'));
const StatisticPage = React.lazy(() => import('../../../pages/Statistic Page/result'));
const PersonalData = React.lazy(() => import('../../../pages/SettingsPage/PersonalData/result'));
const CreateProductPage = React.lazy(() => import('../../../pages/ProductsPages/CreateProductPage/result'));
const ProductPage = React.lazy(() => import('../../../pages/ProductsPages/ProductPage/result'));
const AddEditOderPage = React.lazy(() => import('../../../pages/AddEditOderPage/result'));
const TableProductsPage = React.lazy(() => import('../../../pages/ProductsPages/TableProductsPage/result'));


// const CategorySettings = React.lazy(() => import('../../../pages/LoginPage/result'))
// const OrderPage = React.lazy(() => import('../../../pages/OrdersPage/result'))

export const defaultPrevUrl = "/admin/";
export const publicRoutes = {
    basicUrl: "login",
    routes: [
        {
            page: LoginPage,
            url: "login",
            options: {}
        },
    ]
};

export const protectedRoutes = {
    basicUrl: "statistic",
    basicIndex: 0,
    routes: [
        {
            title: "Статистика",
            page: StatisticPage,
            url: "statistic",
            options: {},
            icon: StatisticIcon,
            isShow: true
        },
        {
            title: "Замовлення",
            page: OrderPage,
            url: "orders",
            options: {},
            icon: OrdersIcon,
            isShow: true
        },
        {
            title: "Товари",
            page: TableProductsPage,
            url: "products/",
            options: {},
            icon: ProductsIcon,
            isShow: true
        },
        {
            page: CreateProductPage,
            url: "products/create",
            options: {},
        },
        {
            page: ProductPage,
            url: "products/:id/",
            options: {},
        },
        {
            title: "Категорії",
            page: CategoryPage,
            url: "category",
            options: {text: "Категорії"},
            icon: CategoryIcon,
            isShow: true
        },
        {
            page: CreateCategoryPage,
            url: "category/create",
            options: {},
        },
        {
            page: ChangeCategoryPage,
            url: "category/:id/",
            options: {},
        },
        {
            page:AddEditOderPage,
            url: "orders/edit",
            options:{}
        }
    ]
};

export const settingsRoutes = {
    title: "Загальні налаштування",
    icon: SettingIcon,
    url: "settings/",
    basicUrl: "home",
    routes: [
        {
            title: "Головна",
            page: SettingsMain,
            url: "home",
            options: {}
        },
        {
            title: "Категорія",
            page: CategorySettings,
            url: "category",
            options: {},
        },
        {
            title: "Доставка та оплата",
            page: OrdersAndPayments,
            url: "delivery-payments",
            options: {}
        },
        {
            title: "Контакти",
            page: Contacts,
            url: "contacts",
            options: {}
        },
        {
            title: "Положення про обробку і захист персональних даних",
            page: PersonalData,
            url: "regulations",
            options: {}
        },
        {
            title: "Угода користувача",
            page: UserAgreement,
            url: "user-agreement",
            options: {}
        }
    ],
    basicIndex: 0
}

export const accountRoute = {
    page: AccountPage,
    icon: PersonIcon,
    url: "account",
    options: {},
    title: "Особистий профіль",
}
