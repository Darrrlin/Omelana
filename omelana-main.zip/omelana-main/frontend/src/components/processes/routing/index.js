import Router from "./router"
import {publicRoutes, defaultPrevUrl, protectedRoutes} from "./config";


export {
    Router,
    publicRoutes,
    defaultPrevUrl,
    protectedRoutes
};