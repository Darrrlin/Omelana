import {BrowserRouter, Navigate, Route, Routes} from "react-router-dom";
import React, {Suspense, useState} from 'react';
import {useSelector} from "react-redux";
import {selectCurrentToken} from "../../auth";
import {accountRoute, defaultPrevUrl, protectedRoutes, publicRoutes, settingsRoutes} from "../config";

import '../css';
import NavigationBar from "../../../widgets/NavigationBar";
import {Loader} from "../../../ui/loader";


const Router = () => {
    const token = useSelector(selectCurrentToken);
    const [openSettingMenu, setOpenSettingMenu] = useState(false)

    const [indexCurrentRoutes, setIndexCurrentRoutes] = useState();
    const [isOpenMenu, setIsOpenMenu] = useState(false);

    return (
        <BrowserRouter>
            <>
                {token
                    ?
                    <div className="page-block">
                        {/* private routes */}
                        <NavigationBar
                            isOpen={isOpenMenu}
                            changeOpen={setIsOpenMenu}
                            callbackSetCurrentRoutes={setIndexCurrentRoutes}
                            openSettingMenu={openSettingMenu}
                            setOpenSettingMenu={setOpenSettingMenu}
                        />
                        <div className={`page ${indexCurrentRoutes === "setting" ? "setting" : ""}`}>
                            <Suspense fallback={<Loader />}>
                                <Routes>
                                    {protectedRoutes.routes.map((route, index) => {
                                        return <Route exact key={`protect-routes-${index}`}
                                                      path={defaultPrevUrl + route.url}
                                                      element={
                                                          React.createElement(route.page, {
                                                              openMenu: (e) => setIsOpenMenu(true),
                                                              ...route.options
                                                          }, null)
                                                      }/>
                                    })}
                                    {settingsRoutes.routes.map((element, index) =>
                                        <Route
                                            key={`setting-route-${index}`}
                                            path={defaultPrevUrl + settingsRoutes.url + element.url}
                                            element={
                                                React.createElement(element.page, {
                                                    openMenu: (e) => setOpenSettingMenu(true),
                                                    ...element.options
                                                }, null)
                                            }/>
                                    )}
                                    <Route path={defaultPrevUrl + settingsRoutes.url + `*`}
                                           element={<Navigate to={settingsRoutes.basicUrl}/>}/>
                                    <Route path={defaultPrevUrl + accountRoute.url} element={
                                        React.createElement(accountRoute.page, {
                                            openMenu: (e) => setIsOpenMenu(true),
                                            ...accountRoute.options
                                        }, null)
                                    }/>
                                    {/* TODO: fix route redirect */}
                                    <Route path={`${defaultPrevUrl}*`}
                                           element={<Navigate to={defaultPrevUrl + protectedRoutes.basicUrl}/>}/>
                                </Routes>
                            </Suspense>
                        </div>
                    </div>
                    :
                    <Routes>
                        {/* public routes */}
                        {publicRoutes.routes.map((route, index) => {
                            return <Route key={`protect-routes-${index}`} path={defaultPrevUrl + route.url} element={
                                React.createElement(route.page, route.options, null)
                            }/>
                        })}
                        <Route path={`${defaultPrevUrl}*`}
                               element={<Navigate to={defaultPrevUrl + publicRoutes.basicUrl}/>}/>
                    </Routes>

                }
            </>
        </BrowserRouter>
    );
};

export default Router;