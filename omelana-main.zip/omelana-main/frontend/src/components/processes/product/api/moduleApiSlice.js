import {apiSlice} from "../../../uttils/api/apiSlice";

export const moduleApiSlice = apiSlice.injectEndpoints({
    endpoints: build => ({
        createProduct: build.mutation({
            query: credentials => {
                credentials.append("type_methods", "CREATE");
                return {
                    url: "products/admin/element",
                    method: 'POST',
                    body: credentials,
                    formData: true
                }
            }
        }),
        updateProduct: build.mutation({
            query: credentials => {
                credentials.append("type_methods", "UPDATE");
                return {
                    url: "products/admin/element",
                    method: 'POST',
                    body: credentials,
                    formData: true
                }
            }
        }),
        getProduct: build.mutation({
            query: id => ({
                url: `products/admin/element?id=${id}`,
                method: 'GET',
            })
        }),
        getProducts: build.mutation({
            query: credentials => {
                let parameters = '';
                if (Object.keys(credentials).length !== 0
                    && credentials.constructor === Object) {
                    let listParameters = [];
                    Object.keys(credentials).forEach(key => {
                        listParameters.push(`${key}=${credentials[key]}`);
                    });
                    parameters = `?${listParameters.join("&")}`
                }
                return {
                    url: `products/admin/elements${parameters}`,
                    method: 'GET',
                }
            }
        }),

        copyProduct: build.mutation({
            query: id => {
                return {
                    url: `products/admin/element?id=${id}`,
                    method: 'PUT',
                }
            }
        }),

        removeProducts: build.mutation({
            query: ids => {
                return {
                    url: "products/admin/element",
                    method: 'POST',
                    body: {id: `${ids}`, type_operations: "toggle_deleted_elements"},
                }
            }
        }),

        changeStatusProducts: build.mutation({
            query: ids => {
                return {
                    url: "products/admin/element",
                    method: 'POST',
                    body: {id: `${ids}`, type_operations: "change_status_availability"},
                }
            }
        }),
        addSaleProducts: build.mutation({
            query: credentials => {
                return {
                    url: "products/admin/element",
                    method: 'POST',
                    body: {...credentials, type_operations: "sale"},
                }
            }
        }),
    })
});

export const {
    useGetProductsMutation,
    useCreateProductMutation,
    useUpdateProductMutation,
    useGetProductMutation,
    useRemoveProductsMutation,
    useChangeStatusProductsMutation,
    useAddSaleProductsMutation,
    useCopyProductMutation
} = moduleApiSlice;