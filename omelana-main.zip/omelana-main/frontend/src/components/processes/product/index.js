import {
    moduleApiSlice,
    useCreateProductMutation,
    useGetProductMutation,
    useGetProductsMutation,
    useUpdateProductMutation,
    useRemoveProductsMutation,
    useChangeStatusProductsMutation,
    useAddSaleProductsMutation,
    useCopyProductMutation
} from "./api/moduleApiSlice";

export {
    moduleApiSlice as ProductApiSlice,
    useCreateProductMutation,
    useUpdateProductMutation,
    useGetProductMutation,
    useGetProductsMutation,
    useRemoveProductsMutation,
    useChangeStatusProductsMutation,
    useAddSaleProductsMutation,
    useCopyProductMutation
}