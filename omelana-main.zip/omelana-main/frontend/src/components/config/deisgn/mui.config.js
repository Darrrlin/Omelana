import {createTheme} from "@mui/material";

export const theme = createTheme({
    palette: {
        primary: {
            main: '#b969f7',
        },
        secondary: {
            main: '#D9D9D9',
            contrastText: '#FDFAFF',
        },
        error: {
            main: '#EB5757',
        },
        success: {
            main: '#00D856',
        },
        warning: {
            main: '#EB5757',
        },
        focus: {
            main: "#3FA2F7"
        }
    },
    typography: {
        fontFamily: "Manrope, Arial, Helvetica, sans-serif, -apple-system",
        button: {
            fontSize: "14px",
            textTransform: "capitalize",
            color: "#FDFAFF",
            borderRadius: "12px",
            boxShadow: "0px 2px 10px rgba(33, 32, 32, 0.15)",
            padding: "16px"
        },
    },
    breakpoints: {
        values: {
            mobile: 0,
            tablet: 320,
            desktop: 768,
        },
    },
    components: {
        // MuiOutlinedInput: {
        //     styleOverrides: {
        //         root: {
        //             borderRadius: 6,
        //             border: "1px solid #D4D4D4",
        //             '&:focus': {
        //                 borderColor: "#3FA2F7"
        //             }
        //         }
        //     }
        // }
    }
})