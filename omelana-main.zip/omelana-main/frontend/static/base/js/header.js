function Header() {
    let self = this;

    self.relationDeleteProduct = () => {
    };

    self.relationAddQuantityProduct = () => {
    };

    self.relationMinusQuantityProduct = () => {
    };

    self.relationChangeQuantityProduct = () => {
    };

    self.apiDeleteProduct = (id) => {
        self.cartProducts.remove(function (element) {
            return element.id === id;
        });
    };

    self.apiAddProduct = (id) => {
        self.loadsProduct([id,], true);
    }

    self.apiAddQuantityProduct = function (id) {
        self.addQuantityProduct(id);
    }

    self.apiMinusQuantityProduct = function (id) {
        self.minusQuantityProduct(id);
    }

    self.apiChangeQuantityProduct = function (id, value) {
        self.changeQuantityProduct(id, value);
    }

    self.apiGetCartProducts = () => {
        return self.cartProducts()
    }

    self.cartProducts = ko.observableArray([]);

    self.sumsProducts = ko.computed(function () {
        return self.cartProducts().map((_element) => _element.price * _element.quantityProduct()).reduce(
            (accumulator, currentValue) => accumulator + currentValue,
            0,
        );
    }, self);

    self.initialRelation = function (callbackDeleteProduct, callbackAddQuantityProduct, callbackMinusQuantityProduct, callbackChangeQuantityProduct) {
        self.relationDeleteProduct = callbackDeleteProduct ? callbackDeleteProduct : () => {
        };
        self.relationAddQuantityProduct = callbackAddQuantityProduct ? callbackAddQuantityProduct : () => {
        };
        self.relationMinusQuantityProduct = callbackMinusQuantityProduct ? callbackMinusQuantityProduct : () => {
        };
        self.relationChangeQuantityProduct = callbackChangeQuantityProduct ? callbackChangeQuantityProduct : () => {
        };
    }

    self.deleteProduct = function (oT, event) {
        self.cartProducts.remove(oT);
        self.relationDeleteProduct(oT.id);
    }

    self.addQuantityProductHandler = function (oT, event) {
        self.addQuantityProduct(oT.id);
        self.relationAddQuantityProduct(oT.id);
    }

    self.openProductHeader = function (oT, event) {
        window.open(`/products/${oT.id}`, '_blank');
    }

    self.openOption = function (oT, event) {
        event.stopPropagation();
        event.preventDefault();
        event.target.closest(".more-icon-block").classList.toggle("active")
    }

    self.minusQuantityProductHandler = function (oT, event) {
        self.minusQuantityProduct(oT.id);
        self.relationMinusQuantityProduct(oT.id)
    }

    self.changeQuantityProductHandler = (oT, event) => {
        self.changeQuantityProduct(oT.id, event.target.value);
        self.relationChangeQuantityProduct(oT.id, event.target.value);
    }


    self.getResizeElement = function (value) {
        return 35 + 10 * `${value}`.length
    }

    self.changeQuantityProduct = (id, value) => {
        let tempArray = self.cartProducts();
        const indexElement = tempArray.findIndex((_element) => {
            return _element.id === id
        });
        if (indexElement === -1) {
            return;
        }

        const valueTemp = parseInt(value) || 1;
        tempArray[indexElement] = {
            ...tempArray[indexElement],
            quantityProduct: ko.observable(valueTemp),
            sumProduct: tempArray[indexElement].price * (valueTemp),
            sizeInput: self.getResizeElement(valueTemp)
        };
        self.cartProducts([...tempArray]);
    }

    self.addQuantityProduct = function (id) {

        let tempArray = self.cartProducts();
        const indexElement = tempArray.findIndex((_element) => {
            return _element.id === id
        });
        if (indexElement === -1) {
            return;
        }

        const value = parseInt(tempArray[indexElement].quantityProduct()) || 1;

        tempArray[indexElement] = {
            ...tempArray[indexElement],
            quantityProduct: ko.observable(value + 1),
            sumProduct: tempArray[indexElement].price * (value + 1),
            sizeInput: self.getResizeElement(value + 1)
        };
        self.cartProducts([...tempArray]);
    }

    self.minusQuantityProduct = function (id) {
        let tempArray = self.cartProducts();
        const indexElement = tempArray.findIndex((_element) => {
            return _element.id === id
        });
        if (indexElement === -1) {
            return;
        }
        const value = parseInt(tempArray[indexElement].quantityProduct()) || 1;

        tempArray[indexElement] = {
            ...tempArray[indexElement],
            quantityProduct: ko.observable(Math.max(value - 1, 1)),
            sumProduct: tempArray[indexElement].price * (Math.max(value - 1, 1)),
            sizeInput: self.getResizeElement(Math.max(value - 1, 1))
        };
        self.cartProducts([...tempArray]);
    }


    self.loadsProduct = async function (ids, isAdd = false) {

    
        if (isAdd) {
            let dataFromBase = await fetch(`/api/products/elements?products_list=${ids[0]}`, {
                method: "GET", // или 'PUT'
                headers: {
                    "Content-Type": "application/json",
                },
            });
            dataFromBase = await dataFromBase.json();
            dataFromBase = dataFromBase[0];
            if (dataFromBase.status === 0) {
                return;
            }
            let price = dataFromBase.price;
            if (dataFromBase["start_sale"] && dataFromBase["end_sale"]) {
                const dateStart = new Date(Date.parse(`${dataFromBase["start_sale"]}`)),
                    dateEnd = new Date(Date.parse(`${dataFromBase["end_sale"]}`));
                if (dateStart && dateEnd && Date.now() - dateEnd < 0) {
                    price = ((100 - dataFromBase.sale) / 100 * dataFromBase.price).toFixed()
                }
            }
            self.cartProducts([...self.cartProducts(), {
                id: dataFromBase.id,
                imageUrl: dataFromBase.image ? dataFromBase.image.image : '',
                title: dataFromBase.title,
                price: price,
                quantityProduct: ko.observable(1),
                sumProduct: price,
                sizeInput: 55
            }]);
        } else {
            const productsList = ids.map((_val) => _val.id);
            if (productsList.length < 1) {
                return;
            }
            let dataFromBase = await fetch(`/api/products/elements?products_list=${productsList.join(',')}`, {
                method: "GET", // или 'PUT'
                headers: {
                    "Content-Type": "application/json",
                },
            });
            dataFromBase = await dataFromBase.json();
            let tempCartProduct = [];
            for (const dataFromBaseKey in dataFromBase) {
                if (dataFromBase[dataFromBaseKey].status === 0) {
                    continue;
                }
                let price = dataFromBase[dataFromBaseKey].price;
                if (dataFromBase[dataFromBaseKey]["start_sale"] && dataFromBase[dataFromBaseKey]["end_sale"]) {
                    const dateStart = new Date(Date.parse(`${dataFromBase[dataFromBaseKey]["start_sale"]}`)),
                        dateEnd = new Date(Date.parse(`${dataFromBase[dataFromBaseKey]["end_sale"]}`));
                    if (dateStart && dateEnd && Date.now() - dateEnd < 0) {
                        price = ((100 - dataFromBase[dataFromBaseKey].sale) / 100 * dataFromBase[dataFromBaseKey].price).toFixed()
                    }
                }
                const cartLongDataElement = cartLongData.find((element) => element.id === dataFromBase[dataFromBaseKey].id)

                tempCartProduct.push({
                    id: cartLongDataElement.id,
                    imageUrl: dataFromBase[dataFromBaseKey].image ? dataFromBase[dataFromBaseKey].image.image : '',
                    title: dataFromBase[dataFromBaseKey].title,
                    price: price,
                    quantityProduct: ko.observable(cartLongDataElement.quantityProduct),
                    sumProduct: cartLongDataElement.quantityProduct * price,
                    sizeInput: self.getResizeElement(cartLongDataElement.quantityProduct)
                })
            }

            self.cartProducts([...tempCartProduct]);
        }
    }


    let cartLongData = JSON.parse(localStorage.getItem("cartLongData"));

    if (cartLongData) {
        self.loadsProduct(cartLongData);
    }

    window.addEventListener('beforeunload', (event) => {
        const tempCartProducts = self.cartProducts();
        localStorage.setItem("cartLongData", JSON.stringify(tempCartProducts.map((_element) => {
            return {id: _element.id, quantityProduct: _element.quantityProduct()}
        })));
    })
}

window.addEventListener('DOMContentLoaded', function () {

    document.querySelectorAll('.grey-background').forEach(item => {
        item.addEventListener('click', event => {
            event.currentTarget.parentNode.classList.remove("active");
        })
    })


    document.querySelectorAll('.modal-cart .cart .cart-container .product-element').forEach(item => {
        item.addEventListener('click', event => {
            item.querySelector(".description-block .more-icon-block").classList.remove("active");
        })
    })

    const cartModalElement = document.querySelector('aside.modal-cart'),
        cartButtonOpenModalElement = document.querySelector('header .desktop-navbar .left-content .cart-block'),
        cartButtonCloseModalElement = document.querySelector('aside.modal-cart .cart .cart-container .title-bar img'),
        cartButtonContinueOrderingModalElement = document.querySelector('aside.modal-cart .cart .cart-container .bottom-bar .button-continue-shopping '),
        mobileMenuButtonOpenModalElement = document.querySelector('header .desktop-navbar .hamburger-menu-button'),
        mobileMenuButtonCloseModalElement = document.querySelector('header aside .container-content .close-icon'),
        mobileMenuModalElement = document.querySelector('header aside'),
        categoryButtonOpenModalElement = document.querySelector('header .desktop-navbar nav div.navbar-link.products'),
        categoryModalElements = document.querySelector('header .nav-bar-sub-links-modal'),
        categoryTitleModalElements = document.querySelectorAll('header .nav-bar-sub-links-modal .nav-bar-sub-links .nav-link-category-links a'),
        categoryImageModalElements = document.querySelectorAll('header .nav-bar-sub-links-modal .nav-bar-sub-links .nav-link-category-images img'),
        confirmOrderModelElement = document.querySelector('.modal-confirm-ordering'),
        confirmOrderButtonCloseModalElement = document.querySelector('.modal-confirm-ordering .confirm-ordering .close-icon'),
        confirmOrderButtonContinueModalElement = document.querySelector('.modal-confirm-ordering .confirm-ordering .button.outline.continue-button');

    function changeStateModalCart(event, state) {
        cartModalElement.classList.remove("active");
        if (state) {
            const cartModalElementBackground = cartModalElement.querySelector(".grey-background"),
                body = document.body,
                html = document.documentElement,
                height = Math.max(body.scrollHeight, body.offsetHeight,
                    html.clientHeight, html.scrollHeight, html.offsetHeight),
                width = Math.max(body.offsetWidth,
                    html.clientWidth, html.offsetWidth);

            if (width / html.clientHeight <= 99 / 100) {
                const element = cartModalElement.querySelector('.cart');
                element.style.minHeight = `${height}px`;
            }
            cartModalElementBackground.style.height = `${height}px`;
            cartModalElement.classList.add("active")
        }
    }

    function changeMobileMenu(event, state) {
        mobileMenuModalElement.classList.remove("active");
        if (state) {
            const body = document.body,
                html = document.documentElement;
            mobileMenuModalElement.style.height = `${Math.max(body.scrollHeight, body.offsetHeight,
                html.clientHeight, html.scrollHeight, html.offsetHeight)}px`;
            mobileMenuModalElement.classList.add("active");
        }
    }

    cartButtonOpenModalElement.addEventListener('click', (event) => {
        changeStateModalCart(event, true);
    });

    cartButtonCloseModalElement.addEventListener('click', (event) => {
        changeStateModalCart(event);
    });

    cartButtonContinueOrderingModalElement.addEventListener('click', (event) => {
        changeStateModalCart(event);
    });

    mobileMenuButtonOpenModalElement.addEventListener('click', (event) => {
        changeMobileMenu(event, true);
    });

    mobileMenuButtonCloseModalElement.addEventListener('click', (event) => {
        changeMobileMenu(event);
    });


    categoryButtonOpenModalElement.addEventListener('click', (event) => {
        categoryModalElements.classList.toggle("active");
        const categoryModalElementsBackground = categoryModalElements.querySelector(".grey-background"),
            body = document.body,
            html = document.documentElement;
        categoryModalElementsBackground.style.height = `calc(${Math.max(body.scrollHeight, body.offsetHeight,
            html.clientHeight, html.scrollHeight, html.offsetHeight)}px - var(---heoght-header))`;
        categoryButtonOpenModalElement.classList.toggle("active");
    });

    confirmOrderButtonCloseModalElement.addEventListener('click', (event) => {
        confirmOrderModelElement.classList.remove("active");
    });

    confirmOrderButtonContinueModalElement.addEventListener('click', (event) => {
        confirmOrderModelElement.classList.remove("active");
    });


    if (categoryTitleModalElements) {
        categoryTitleModalElements.forEach(item => {
            item.addEventListener('mouseover', function (event) {
                const target = event.target || event.srcElement,
                    idTarget = target.id,
                    idImage = `${idTarget}-img`;
                let imageElement = document.getElementById(idImage);
                for (const categoryImageModalElement of categoryImageModalElements) {
                    categoryImageModalElement.classList.remove('active');
                }
                imageElement.classList.add("active")
            })
        });

        categoryTitleModalElements.forEach(item => {
            item.addEventListener('onmouseout', function (event) {
                const target = event.target || event.srcElement,
                    idTarget = target.id,
                    idImage = `${idTarget}-img`;
                let imageElement = document.getElementById(idImage);
                imageElement.classList.remove("active")
            })
        });
    } else {
        console.log("categoryTitleModalElements is Empty!")
    }


})
