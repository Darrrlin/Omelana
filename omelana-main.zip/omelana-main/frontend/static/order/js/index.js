function OrderViewModel(parentSelf) {
  const self = this;
  self.products=ko.observableArray([]) ;
  self.comments = ko.observable('');
  self.changeMenuState = function(product){
    product.menuHidden(!product.menuHidden())
  };

  self.removeProduct = function(product){
    self.productsListTemp.remove(product);
    self.totalSumCounter();
    self.updateStorage();
  };
  
  self.updateStorage = function(){
    localStorage.clear();
    localStorage.setItem("cartLongData", JSON.stringify(self.productsListTemp().map((_element) => {
      return {id: _element.id, quantityProduct: _element.count()}
    })));
  }
  
  self.closeAllPopupMenu = function(){
    self.productsListTemp().map(product => product.menuHidden(true));
  }
  
  self.plus = function(product){
    product.count(parseInt(product.count())+1);
    self.totalSumCounter();
    self.updateStorage();
  };

  self.minus = function(product){
    if(product.count()>1){
      product.count( parseInt(product.count())-1)
    }
    self.totalSumCounter();
    self.updateStorage();
  };
  self.changeDelivery = function(choise){
    self.deliveryChoise(choise);
  };
  const cartLongData = JSON.parse(localStorage.getItem("cartLongData"));
  self.deliveryChoise = ko.observable('Самовивіз з Тернополя')

  self.contactsForm=ko.observableArray([
    {
      title:"Ім'я",
      value:'',
      error: ko.observable('')
    },
    {
      title:"Прізвище",
      value:'',
      error:ko.observable('')
    },
    {
      title:"Телефон",
      value:'',
      error:ko.observable('')
    },
    {
      title:"Електронна пошта",
      value:'',
      error:ko.observable('')
    },
    
  ])
  
  self.deliveryChoises = ko.observableArray([
    'Самовивіз з Тернополя',
    'Самовивіз з Нової пошти',
    'Самовивіз з Укрпошти',
    //'Кур’єр Нової пошти',
   // 'Кур’єр Укрпошти'
  ])

  self.paymentChoise = ko.observable('Оплата під час отримання товару');
  self.paymentChoises = ko.observableArray([
    'Оплата під час отримання товару',
    //'Карткою онлайн'
  ])
  self.changePayment = function(choise){
    self.paymentChoise(choise);
  }
  self.rez = ko.observable(100);
  self.totalSumCounter = function() {
      let sum = 0;
      this.productsListTemp().map((val)=>{
        sum = sum + (val.price*val.count())
      })
      self.rez(sum);
      return sum;
  };

  document.getElementsByClassName('order-content-main-block')[0].addEventListener('click', function(event) {
    var target = event.target;  
    // Перевірити, чи клікнуто на елемент, що не належить до меню
    if (!target.closest('.dots-vertical')) {
      self.closeAllPopupMenu();
      self.suggestedData([]);
      self.suggestedPlaces([]);
    }
  });
  self.apiKey = '9292798adf2829108b26e77a94ba6a18';
  self.url='https://api.novaposhta.ua/v2.0/json/';
  self.isOpen= ko.observable(false);
  self.inputWords = ko.observable("")
  self.data=ko.observableArray([]);
  self.places=ko.observableArray([]);
  self.suggestedData = ko.observableArray([]);
  self.inputPlace = ko.observable("");
  self.suggestedPlaces = ko.observableArray([]);
  
  self.chekSuggest = function(){
    self.suggestedData(self.data().filter(value=> value.includes(self.inputWords())));

    }
  self.checkCities = function(data, event){
    if(data!=="Самовивіз з Нової пошти" && data!=="Кур’єр Нової пошти" && data!=='Самовивіз з Укрпошти'){
      self.inputWords(data);
      self.suggestedData([]);
      self.loadPositions();
    }
  };
  self.setPlace = function(data,event){
    self.inputPlace(data); 
    self.suggestedPlaces([]);
    self.places([]);
  }
  self.checkPlace = function(){
    if(self.inputPlace()!==''){
      self.places(self.arrayCities.filter(value=> value.includes(self.inputPlace())));
    }
  }

  self.arrayCities =  [];

  self.loadPositions = function(){
    self.arrayCities = [];
    fetch(self.url, {
      method: 'POST',
      body: JSON.stringify({
          "modelName": "Address",
          "calledMethod": "getWarehouses", 
          "methodProperties": {  
          "CityName" : self.inputWords()}
        }),
      headers: {
        'Content-type': 'application/json; charset=UTF-8',
      },
    })
      .then((response) => response.json())
      .then((data) => {

        data.data.map((data, index) => {
          self.arrayCities.push(data.Description);
        });
        self.suggestedPlaces(self.arrayCities);
        self.places(self.arrayCities);
      })
      .catch((err) => {
        console.log(err.message);
      });
  }
  self.productsListTemp = ko.observableArray([]);
  self.longCard = ko.observableArray([]);
  self.card = ko.observableArray([]);
  self.afterLoad = async function(){
    self.productsListTemp([]);
    self.longCard( JSON.parse(localStorage.getItem("cartLongData")));
    self.longCard().map(async(value)=>{
      let dataFromBase = await fetch(`/api/products/elements?products_list=${value.id}`, {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
        },
      });
      dataFromBase = await dataFromBase.json();
      dataFromBase = dataFromBase[0];

      self.productsListTemp.push({
        id:dataFromBase.id,
        title:dataFromBase.title,
        image:dataFromBase.image.image,
        count:ko.observable(value.quantityProduct),
        price:dataFromBase.price,
        menuHidden:ko.observable(true)
    
      })
    })
    self.products(self.productsListTemp());
    self.arrayCities = [];
    fetch(self.url, {
      method: 'POST',
      body: JSON.stringify({
        "modelName": "Address",
        "calledMethod": "getCities",        
      }),

      
      headers: {
        'Content-type': 'application/json; charset=UTF-8',
      },
    })
      .then((response) => response.json())
      .then((data) => {
        data.data.map((data, index) => {
          self.arrayCities.push(data.Description);
        });
        self.data(self.arrayCities);
      })
      .catch((err) => {
        console.log(err.message);
      });
      setTimeout(()=>{
        self.totalSumCounter();

      },1000)
  }
  self.suggestedErrors =ko.observableArray(['asdasd','']);
  
  const url = "https://raw.githubusercontent.com/Medniy2000/ua_locations/master/json/ua_locations_10_11_2021.json";
  self.loadUkrSelf = function(){
    fetch(url)
  .then(response => response.json())
  .then(data => { // Отримані дані від API
    // Тут ви можете обробити дані, як вам потрібно
  })
  .catch(error => {
    console.error('Error:', error);
  });
  }
  self.sendForm = async function(){
    if(self.contactsForm()[0]['value'] === ""){
      self.contactsForm()[0]['error']("Заповніть це поле")
      return 0;
    }
    else{
      self.contactsForm()[0]['error']("")
    }
    if(self.contactsForm()[1]['value'] === ""){
      self.contactsForm()[1]['error']("Заповніть це поле")
      return 0;
    }
    else{
      self.contactsForm()[1]['error']("")
    }
    if(self.contactsForm()[2]['value'] === ""){
      self.contactsForm()[2]['error']("Заповніть це поле")
      return 0;
    }
    else{
      if(String(self.contactsForm()[2]['value']).length < 10){
        self.contactsForm()[2]['error']("Надто короткий номер")
        return 0;
      }
      self.contactsForm()[2]['error']("")
    }
    let mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if( !self.contactsForm()[3]['value'].match(mailformat)){
        self.contactsForm()[3]['error']("Заповніть це поле") 
        return 0;
    }
    if(self.contactsForm()[3]['value'] === ""){
      self.contactsForm()[3]['error']("Заповніть це поле") 
      return 0;
    }else{
      self.contactsForm()[3]['error']("")
    }
    let delivery = "";
    if(self.deliveryChoises() === "Самовивіз з Тернополя"){
      delivery = 0;
    } else{
      delivery = ""+self.inputWords()+ " " + self.inputPlace();
    }
    if(self.deliveryChoise() !=='Самовивіз з Тернополя'){
      if(self.inputWords() === ''){
        self.suggestedErrors(['Заповніть це поле','']);
        return 0;
      }
      else{
        self.suggestedErrors(['','']);
      }
      if(self.inputPlace() === ''){
        self.suggestedErrors(['','Заповніть це поле']);
        return 0;
      }
      else{
        self.suggestedErrors(['','']);
      }
    }
    let items_list = "";
    self.productsListTemp().map((elem)=>{
      for (let i = 0; i < elem.count(); i++) {
        items_list += elem.id + ",";
      }
    })
    
    let request = await fetch(`/api/orders/orderslist/`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body:JSON.stringify({
        "email":self.contactsForm()[3].value,
        "first_name":self.contactsForm()[0].value,
        "second_name":self.contactsForm()[1].value,
        "sur_name":"",
        "type_payment":1,
        "phone_number":self.contactsForm()[2].value,
        "address":delivery,
        "items_list":items_list,
      })
    });
    localStorage.setItem("cartLongData", "[]");
    window.location.replace('/');
  }


  
    self.afterLoad();
  }
