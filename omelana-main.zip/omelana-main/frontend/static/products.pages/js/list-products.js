function ListProductsViewModel(parentSelf) {
    let self = this;
    self.id = parseInt(window.location.pathname.split('/')[2]);

    self.productsList = ko.observableArray([]);
    self.isAnimationMore = ko.observable(false);
    self.isLockedUpdateFilter = false;


    self.showMore = async function () {
        if (self.isLockedUpdateFilter) {
            return;
        }
        self.isAnimationMore(true);
        self.currentPage(self.currentPage() + 1);
        await self.updateData(true);
        self.isAnimationMore(false);
    }

    self.closeFilter = function () {
        filterContainer.classList.remove('active')
    }

    // elements


    self.openProduct = function (oT, event) {
        window.open(`/products/${oT.id}/`);
    }

    self.deleteFromCartHandler = (oT, event) => {
        event.preventDefault();
        event.stopPropagation();
        self.deleteFromCart(oT.id);
        parentSelf.headerController.apiDeleteProduct(oT.id);
    }

    self.addToCartHandler = (oT, event) => {
        event.preventDefault();
        event.stopPropagation();
        self.addToCart(oT.id);
    }

    self.deleteFromCart = (id) => {
        self.productsList([...self.productsList().map((_element, _index) => {
            if (_element.id === id) {
                return {..._element, inCart: false}
            }
            return {..._element};
        })]);
    }

    self.addToCart = (id) => {
        parentSelf.headerController.apiAddProduct(id)
        self.productsList([...self.productsList().map((_element, _index) => {
            if (_element.id === id) {
                return {..._element, inCart: true}
            }
            return {..._element};
        })]);
    }

    parentSelf.headerController.initialRelation(
        self.deleteFromCart
    );

    // data load

    self.generateUrl = function () {
        let objectsProperty = {
            "counts_page": self.countsListText(),
            "page": self.currentPage(),
            "order_by": self.sortedListSelectIndex() === 0 ? "price" : self.sortedListSelectIndex() === 1 ? "-price" : "-created"
        };

        if (self.isPriceFilter()) {
            objectsProperty["price_start"] = self.leftPrice();
            objectsProperty["price_end"] = self.rightPrice();
        }

        const listProperty = self.filterStableList();
        for (const listPropertyElement of listProperty) {
            if (objectsProperty.hasOwnProperty(`${listPropertyElement.idElement}`)) {
                objectsProperty[`${listPropertyElement.idElement}`].push(listPropertyElement.title);
            } else {
                objectsProperty[`${listPropertyElement.idElement}`] = [];
                objectsProperty[`${listPropertyElement.idElement}`].push(listPropertyElement.title);
            }
        }

        return Object.keys(objectsProperty).map(key => {
            if (Array.isArray(objectsProperty[key])) {
                return `${key}=${objectsProperty[key].join(",")}`;
            }
            return `${key}=${objectsProperty[key]}`;
        }).join('&');
    }

    self.changeUrl = function (params) {
        history.replaceState({}, "Товари", `/category/${self.id}?${params}`);
    }

    self.readParamsUrl = function () {
        if (!window.location.search) {
            return [];
        }
        return window.location.search.split("?")[1].split("&").reduce((accumulator, _element) => {
            let [key, value] = _element.split("=");
            value = decodeURIComponent(value);
            if (value.includes(",")) {
                value = value.split(",").map(_value => decodeURIComponent(decodeURI(_value)));
            }
            let obj = {};
            obj[`${key}`] = value
            return {...accumulator, ...obj};
        }, {});
    }

    const loadElements = (arr) => {
        return arr.map((_val, index) => {
            let isDiscount = false, priceDiscount = _val.price;
            if (_val["start_sale"] && _val["end_sale"]) {
                const dateStart = new Date(Date.parse(`${_val["end_sale"]}`)),
                    dateEnd = new Date(Date.parse(`${_val["end_sale"]}`));
                if (dateStart && dateEnd && Date.now() - dateEnd < 0) {
                    isDiscount = true;
                    priceDiscount = ((100 - _val.sale) / 100 * _val.price).toFixed()
                }
            }
            return {
                id: _val.id,
                isDelete: _val["on_delete"],
                imageUrl: _val.image ? _val.image.image : '',
                title: _val.title,
                price: _val.price,
                priceDiscount: priceDiscount,
                inCart: false,
                isDiscount: isDiscount,
            }
        })
    }

    self.preLoadDateElements = async () => {
        try {
            await self.loadDataFilter();
            let params = window.location.search;
            if (params) {
                params = `&${window.location.search.split("?")[1]}`;
            }
            let [responseElements, filter] = await self.loadDataElements(`category=${self.id}${params}`);
            if (filter.maxPage !== self.maxPage()) {
                const params = self.readParamsUrl();
                const page = params.hasOwnProperty("page") ? parseInt(params["page"]) : 1;
                self.currentPage(page);
                self.maxPage(filter.maxPage);
            }
            self.updatePriceConst(filter.minPrice, filter.maxPrice);
            self.productsList(responseElements);
            self.isLockedUpdateFilter = false;
        } catch (e) {
            console.log(e)
        }
    }

    self.loadDataElements = async (params) => {
        try {
            let responseElements = []
            if (params) {
                try {
                    responseElements = await fetch(`/api/products/filter-elements?${params}`, {
                        method: "GET", // или 'PUT'
                        headers: {
                            "Content-Type": "application/json",
                        },
                    });
                    responseElements = await responseElements.json();
                    if (responseElements.products.length === 0) {
                        responseElements = await fetch(`/api/products/filter-elements?category=${self.id}`, {
                            method: "GET", // или 'PUT'
                            headers: {
                                "Content-Type": "application/json",
                            },
                        });
                        responseElements = await responseElements.json();
                    }
                } catch (e) {
                    responseElements = await fetch(`/api/products/filter-elements?category=${self.id}`, {
                        method: "GET", // или 'PUT'
                        headers: {
                            "Content-Type": "application/json",
                        },
                    });
                    responseElements = await responseElements.json();
                }
            } else {
                try {
                    responseElements = await fetch(`/api/products/filter-elements?category=${self.id}&${self.generateUrl()}`, {
                        method: "GET", // или 'PUT'
                        headers: {
                            "Content-Type": "application/json",
                        },
                    });
                    responseElements = await responseElements.json();
                    if (responseElements.products.length === 0) {
                        responseElements = await fetch(`/api/products/filter-elements?category=${self.id}`, {
                            method: "GET", // или 'PUT'
                            headers: {
                                "Content-Type": "application/json",
                            },
                        });
                        responseElements = await responseElements.json();
                    }
                } catch (e) {
                    responseElements = await fetch(`/api/products/filter-elements?category=${self.id}`, {
                        method: "GET", // или 'PUT'
                        headers: {
                            "Content-Type": "application/json",
                        },
                    });
                    responseElements = await responseElements.json();
                }
            }
            const cartProducts = parentSelf.headerController.apiGetCartProducts();

            const filter = responseElements.filters;

            responseElements = loadElements(responseElements.products);

            if (cartProducts.length) {
                for (const cartProduct of cartProducts) {
                    responseElements = responseElements.map(_element => {
                        if (_element.id === cartProduct.id) {
                            return {..._element, inCart: true};
                        }
                        return {..._element};
                    })
                }
            }

            return [responseElements, filter];

        } catch (e) {
            console.log(e)
        }
    }

    self.loadDataFilter = async () => {
        try {
            let responseFilter = await fetch(`/api/products/filter?category=${self.id}`, {
                method: "GET", // или 'PUT'
                headers: {
                    "Content-Type": "application/json",
                },
            });

            responseFilter = await responseFilter.json();

            const urlsParams = self.readParamsUrl();

            responseFilter = responseFilter.map(_element => {
                return {
                    id: _element.id,
                    title: _element.name,
                    options: _element.values.map((option, optionIndex) => {
                        let state = false
                        if (urlsParams.hasOwnProperty(`${_element.id}`) && urlsParams[`${_element.id}`].includes(option.value)) {
                            if (Array.isArray(urlsParams[`${_element.id}`]) || option.value === urlsParams[`${_element.id}`]) {
                                state = true;
                            }
                        }
                        return {
                            id: optionIndex,
                            idElement: _element.id,
                            state: state,
                            title: option.value
                        }
                    })
                };
            });

            if (urlsParams.hasOwnProperty("counts_page")) {
                self.countsListText(urlsParams["counts_page"]);
            }

            if (urlsParams.hasOwnProperty("page")) {
                self.currentPage(parseInt(urlsParams["page"]));
            }

            if (urlsParams.hasOwnProperty("order_by")) {
                if (urlsParams["order_by"] === "price") {
                    self.sortedListSelectIndex(0);
                } else if (urlsParams["order_by"] === "-price") {
                    self.sortedListSelectIndex(1);
                } else {
                    self.sortedListSelectIndex(2);
                }

                self.sortedListText(self.sortedListOptions()[self.sortedListSelectIndex()].text);
            }

            let checkPrice = false;


            if (urlsParams.hasOwnProperty("price_start")) {
                checkPrice = true;
                self.leftPrice(parseInt(urlsParams["price_start"]))
            }

            if (urlsParams.hasOwnProperty("price_end")) {
                checkPrice = true;
                self.rightPrice(parseInt(urlsParams["price_end"]))
            }

            self.isPriceFilter(checkPrice)

            self.filtersList(responseFilter);
            updateFilters();
        } catch (e) {
            console.log(e)
        }
    }

    self.updateData = async function (isShowMore = false) {
        self.isLockedUpdateFilter = true;
        self.changeUrl(self.generateUrl());
        let [responseElements, filter] = await self.loadDataElements();
        if (!isShowMore && filter.maxPage !== self.maxPage()) {
            self.currentPage(1);
            self.maxPage(filter.maxPage);
        }
        if (isShowMore) {
            self.productsList([...self.productsList(),...responseElements])
        } else {
            self.productsList(responseElements);
        }
        self.isLockedUpdateFilter = false;
    }

    // selectLists filter bar
    self.sortedListText = ko.observable("Новинки");
    self.sortedListSelectIndex = ko.observable(2);
    self.sortedListOptions = ko.observableArray([
        {id: 0, text: "Від дешевих до дорогих"},
        {id: 1, text: "Від дорогих до дешевих"},
        {id: 2, text: "Новинки"}]);
    self.countsListText = ko.observable("12");
    self.countsListSelectIndex = ko.observable(0);
    self.countsListOptions = ko.observableArray([{id: 0, text: "12"}, {id: 1, text: "24"}, {id: 2, text: "36"}]);

    self.changeSelectSortElement = function (oT, event) {
        if (self.isLockedUpdateFilter) {
            return;
        }
        self.sortedListText(oT.text);
        self.sortedListSelectIndex(oT.id);
        self.currentPage(1);
        self.updateData();
    }

    self.changeSelectCountsElement = function (oT, event) {
        if (self.isLockedUpdateFilter) {
            return;
        }
        self.countsListText(oT.text);
        self.countsListSelectIndex(oT.id);
        self.currentPage(1);
        self.updateData();
    }

    const selectsUI = document.querySelectorAll('.filter-bar .filter-selects .select-form-group .select-form');

    selectsUI.forEach(item => {
        item.addEventListener('click', event => {
            event.preventDefault();
            event.stopPropagation();
            item.classList.toggle("active");
        })
    })

    document.addEventListener('click', () => {
        selectsUI.forEach(item => {
            item.classList.remove('active')
        })
    })


    // price filter form

    self.minPrice = ko.observable(100);
    self.maxPrice = ko.observable(10000);
    self.isPriceFilter = ko.observable(false);
    self.percentValuePrice = (self.maxPrice() - self.minPrice()) / 100
    self.leftPrice = ko.observable(self.minPrice());
    self.rightPrice = ko.observable(self.maxPrice());

    self.updatePriceConst = function (minPrice, maxPrice) {
        if (minPrice !== self.minPrice()) {
            self.minPrice(minPrice);
            if (self.leftPrice() < minPrice) {
                self.leftPrice(minPrice);
            }
        }
        if (maxPrice !== self.maxPrice()) {
            self.maxPrice(maxPrice);
            if (self.rightPrice() > maxPrice) {
                self.rightPrice(maxPrice);
            }
        }
        self.percentValuePrice = (self.maxPrice() - self.minPrice()) / 100;


        leftButtonPercent = (self.leftPrice() - self.minPrice()) / self.percentValuePrice;
        rightButtonPercent = (self.rightPrice() - self.minPrice()) / self.percentValuePrice;
        updateButton(false);

    }

    self.submitPrice = function () {
        if (self.isLockedUpdateFilter) {
            return;
        }
        self.currentPage(1);
        self.isPriceFilter(true);
        self.updateData();

    }

    self.clearFilterPriceHandler = function () {
        if (self.isLockedUpdateFilter) {
            return;
        }
        self.currentPage(1);
        self.clearFilterPrice(true)
    }

    self.clearFilterPrice = function (update) {
        self.isPriceFilter(false);
        self.leftPrice(self.minPrice());
        self.rightPrice(self.maxPrice());
        leftButtonPercent = 0;
        rightButtonPercent = 100;
        updateButton(false);
        if (update) {

            self.updateData();
        }
    }

    self.changeLeftPrice = function (oT, event) {
        if (self.isLockedUpdateFilter) {
            return;
        }
        let value = parseInt(event.target.value);
        if (value > self.rightPrice()) {
            value = parseInt(self.rightPrice());
        }
        self.leftPrice(value);
        if (value >= self.minPrice() && value <= self.maxPrice()) {
            leftButtonPercent = (value - self.minPrice()) / self.percentValuePrice;
        }
        updateButton(false);
    }

    self.changeRightPrice = function (oT, event) {
        if (self.isLockedUpdateFilter) {
            return;
        }
        let value = parseInt(event.target.value);
        if (value < self.leftPrice()) {
            value = parseInt(self.leftPrice());
        }
        self.rightPrice(value);
        if (value >= self.minPrice() && value <= self.maxPrice()) {
            rightButtonPercent = (value - self.minPrice()) / self.percentValuePrice;
        }
        updateButton(false);
    }


    const buttonPriceRightElement = document.getElementById("slider-range-button-type-right"),
        buttonPriceLeftElement = document.getElementById("slider-range-button-type-left"),
        spacePriceElement = document.getElementById('slider-range-space'),
        sliderContainer = document.querySelector('.price-progress');

    let prevXPrice = 0, currentElement = 0, isMoved = false,
        spacePriceElementWidth = spacePriceElement.clientWidth / 100, leftButtonPercent = 0, rightButtonPercent = 100;

    const startMoveElementPrice = (event, typeClick, typeElement) => {
        if (self.isLockedUpdateFilter) {
            return;
        }
        isMoved = true;
        currentElement = typeElement;
        if (typeClick === "mouse") {
            prevXPrice = event.clientX;
        } else {
            prevXPrice = event.touches[0].clientX;
        }
        spacePriceElementWidth = spacePriceElement.clientWidth / 100;
    }

    const moveElementPrice = (event, typeClick, typeElement) => {
        if (isMoved) {
            let currentX = 0;
            if (typeClick === "mouse") {
                currentX = event.clientX;
            } else {
                currentX = event.touches[0].clientX;
            }

            const deltaX = currentX - prevXPrice;
            prevXPrice = currentX;

            if (typeElement === 0) {
                // right
                rightButtonPercent += deltaX / spacePriceElementWidth;
                if (rightButtonPercent > 100) {
                    rightButtonPercent = 100;
                } else if (rightButtonPercent < leftButtonPercent) {
                    rightButtonPercent = leftButtonPercent;
                }
            } else {
                leftButtonPercent += deltaX / spacePriceElementWidth;
                if (leftButtonPercent < 0) {
                    leftButtonPercent = 0;
                } else if (rightButtonPercent < leftButtonPercent) {
                    leftButtonPercent = rightButtonPercent;
                }
            }

            updateButton();
        }
    }

    const encMoveElementPrice = () => {
        if (isMoved) {
            isMoved = false;
        }
    }

    const updateButton = (full = true) => {
        buttonPriceRightElement.style.left = `${rightButtonPercent.toFixed()}%`;
        buttonPriceLeftElement.style.left = `${leftButtonPercent.toFixed()}%`;
        let deltaPercent = rightButtonPercent - leftButtonPercent;
        spacePriceElement.style.marginLeft = `${leftButtonPercent.toFixed()}%`;
        spacePriceElement.style.width = `${deltaPercent.toFixed()}%`;
        if (full) {
            self.leftPrice(self.minPrice() + parseInt((self.percentValuePrice * leftButtonPercent).toFixed()));
            self.rightPrice(self.minPrice() + parseInt((self.percentValuePrice * rightButtonPercent).toFixed()));
        }
    }

    buttonPriceRightElement.addEventListener('mousedown', (event) => startMoveElementPrice(event, 'mouse', 0));
    buttonPriceRightElement.addEventListener('mouseup', encMoveElementPrice);
    buttonPriceRightElement.addEventListener('mousemove', (event) => moveElementPrice(event, 'mouse', 0));
    buttonPriceRightElement.addEventListener('touchmove', (event) => moveElementPrice(event, 'touch', 0));
    buttonPriceRightElement.addEventListener('touchstart', (event) => startMoveElementPrice(event, 'touch', 0));
    buttonPriceRightElement.addEventListener('touchend', encMoveElementPrice);
    buttonPriceRightElement.addEventListener('touchcancel', encMoveElementPrice);

    buttonPriceLeftElement.addEventListener('mousedown', (event) => startMoveElementPrice(event, 'mouse', 1));
    buttonPriceLeftElement.addEventListener('mouseup', encMoveElementPrice);
    buttonPriceLeftElement.addEventListener('mousemove', (event) => moveElementPrice(event, 'mouse', 1));
    buttonPriceLeftElement.addEventListener('touchmove', (event) => moveElementPrice(event, 'touch', 1));
    buttonPriceLeftElement.addEventListener('touchstart', (event) => startMoveElementPrice(event, 'touch', 1));
    buttonPriceLeftElement.addEventListener('touchend', encMoveElementPrice);
    buttonPriceLeftElement.addEventListener('touchcancel', encMoveElementPrice);

    sliderContainer.addEventListener('mouseout', encMoveElementPrice);


    // other left bar filter

    self.filtersList = ko.observableArray([{
        id: 0,
        title: "Матеріал",
        options: [
            {id: 1, idElement: 0, state: false, title: "Біли'йь"},
            {id: 2, idElement: 0, state: false, title: "Червоний"},
            {id: 3, idElement: 0, state: false, title: "Синій"}
        ]
    }])

    self.changeOption = function (idOption, idElement) {
        if (self.isLockedUpdateFilter) {
            return;
        }
        const tempList = self.filtersList();
        const filterElement = tempList.find((_element) => _element.id === idElement);
        let optionElement = filterElement.options;

        optionElement = optionElement.map((_val) => {
            if (_val.id === idOption) {
                return {..._val, state: !_val.state}
            }
            return {..._val};
        })
        self.filtersList(self.filtersList().map((_val, _index) => {
            if (_val.id === idElement) {
                return {..._val, options: [...optionElement]};
            }
            return {..._val};
        }));
        updateFilters();
        self.currentPage(1);
        self.updateData();
    }


    let filterOptions = document.getElementsByName(".form-choose-element");


    const updateFilters = function () {
        filterOptions = document.querySelectorAll(".form-choose-element");

        filterOptions.forEach(item => {
            if (!item.id) {
                return;
            }
            const idList = item.id.split('-');
            item.addEventListener('click', () => {
                self.changeOption(parseInt(idList[3]), parseInt(idList[1]));
            })
        })
    }

    // list filters

    self.filterStableList = ko.computed(function () {
        const tempArray = self.filtersList();
        let outputList = [];
        tempArray.forEach(item => {
            item.options.forEach(option => {
                if (option.state === true) {
                    outputList.push(option);
                }
            })
        })
        return outputList;
    }, self);

    self.resetFilter = function () {
        if (self.isLockedUpdateFilter) {
            return;
        }
        self.filtersList(self.filtersList().map(_element => {
            return {..._element, options: _element.options.map(option => ({...option, state: false}))};
        }));
        self.clearFilterPrice(false);
        updateFilters();
        self.currentPage(1);
        self.updateData();
    }

    self.deleteFilter = function (oT, event) {
        if (self.isLockedUpdateFilter) {
            return;
        }
        self.filtersList(self.filtersList().map(_element => {
            if (oT.idElement === _element.id) {
                return {
                    ..._element, options: _element.options.map(option => {
                        if (option.id === oT.id) {
                            return {...option, state: false}
                        }
                        return {...option};
                    })
                };
            }
            return {..._element};
        }));
        updateFilters();
        self.currentPage(1);
        self.updateData();
    }

    // pagination

    self.maxPage = ko.observable(25);
    self.currentPage = ko.observable(1);
    self.typePagination = ko.observable(1);

    const resizeTypePagination = () => {
        const h = document.documentElement.clientHeight,
            w = document.documentElement.clientWidth;
        if (w / h <= 99 / 100) {
            self.typePagination(2);
        } else {
            self.typePagination(1)
        }
    }

    resizeTypePagination();

    window.addEventListener('resize', resizeTypePagination);

    self.paginationList = ko.computed(function () {
        const maxPage = self.maxPage(), page = self.currentPage(), typePagination = self.typePagination();
        let tempList = [];
        if (typePagination === 1) {
            if (maxPage < 10) {
                tempList = Array(maxPage).fill().map((_, idx) => 1 + idx);
            } else if (page < 6) {
                tempList = [1, 2, 3, 4, 5, 6, 7, '...', maxPage];
            } else if (page + 6 > maxPage) {
                tempList = [1, "...", maxPage - 6, maxPage - 5, maxPage - 4, maxPage - 3, maxPage - 2, maxPage - 1, maxPage];
            } else {
                tempList = [1, "...", page - 2, page - 1, page, page + 1, page + 2, "...", maxPage];
            }
        } else {
            if (maxPage < 6) {
                tempList = Array(maxPage).fill().map((_, idx) => 1 + idx);
            } else if (page < 3) {
                tempList = [1, 2, 3, 4, ">"];
            } else if (page + 3 > maxPage) {
                tempList = ["<", maxPage - 3, maxPage - 2, maxPage - 1, maxPage];
            } else {
                tempList = ["<", page - 1, page, page + 1, ">"];
            }
        }

        return tempList.map(_val => ({title: _val, active: _val === self.currentPage()}));
    }, self);

    self.changePage = function (oT, event) {
        if (self.isLockedUpdateFilter) {
            return;
        }
        switch (oT.title) {
            case "...":
                break;
            case "<":
                self.currentPage(self.currentPage() - 1);
                break;
            case ">":
                self.currentPage(self.currentPage() + 1);
                break;
            default:
                self.currentPage(parseInt(oT.title));
        }
        self.updateData();
    }

    self.preLoadDateElements();

    const filterButtonElement = document.querySelector('main > section > div.button.icon.open-filter-mobile'),
        filterContainer = document.getElementById('filter-more-block'),
        filterBackground = filterContainer.getElementsByClassName("grey-background")[0],
        filterContent = filterContainer.getElementsByClassName("container")[0],
        closeElementFilter = document.querySelector("#filter-more-block > div.container > div > img");

    filterButtonElement.addEventListener('click', () => {
        const body = document.body,
            html = document.documentElement;
        filterContainer.classList.toggle('active');
        filterContent.style.height = `${Math.max(body.scrollHeight, body.offsetHeight,
            html.clientHeight, html.scrollHeight, html.offsetHeight)}px`;
        filterBackground.style.height = `${Math.max(body.scrollHeight, body.offsetHeight,
            html.clientHeight, html.scrollHeight, html.offsetHeight)}px`;
    })


    closeElementFilter.addEventListener('click', () => {
        filterContainer.classList.remove('active');
    })
}