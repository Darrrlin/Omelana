function ProductViewModel(parentSelf) {
    let self = this;
    self.id = parseInt(document.querySelector("main").id.split("-")[1]);


    self.quantityProduct = ko.observable(1);
    self.inCart = ko.observable(false);
    self.visitedArray = ko.observableArray([]);
    self.recommendationArray = ko.observableArray([]);
    self.sizeInput = ko.observable(45);

    //

    self.openProduct = function (oT, event) {
        window.open(`/products/${oT.id}/`);
    }

    self.getResizeElement = function (value) {
        return 35 + 10 * `${value}`.length
    }

    self.changeQuantityProductHandler = (oT, event) => {
        self.changeQuantityProduct(self.id, event.target.value);
        if (self.inCart) {
            parentSelf.headerController.apiChangeQuantityProduct(oT.id, event.target.value);
        }
    }

    self.minusQuantityProductHandler = (oT, event) => {
        self.minusQuantityProduct(self.id);
        if (self.inCart) {
            parentSelf.headerController.apiMinusQuantityProduct(oT.id);
        }
    }

    self.addQuantityProductHandler = (oT, event) => {
        self.addQuantityProduct(self.id);
        if (self.inCart) {
            parentSelf.headerController.apiAddQuantityProduct(oT.id);
        }
    }

    self.deleteFromCartHandler = (oT, event) => {
        event.preventDefault();
        event.stopPropagation();
        self.deleteFromCart(oT.id);
        parentSelf.headerController.apiDeleteProduct(oT.id);
    }

    self.addToCartHandler = (oT, event) => {
        event.preventDefault();
        event.stopPropagation();
        self.addToCart(oT.id);
    }

    self.changeQuantityProduct = (id, value) => {
        if (id !== self.id) {
            return;
        }
        const valueTemp = parseInt(value) || 1;
        self.quantityProduct(valueTemp);
        self.sizeInput(self.getResizeElement(valueTemp));
    }

    self.minusQuantityProduct = (id) => {
        if (id !== self.id) {
            return;
        }

        const value = parseInt(self.quantityProduct()) || 1;

        self.quantityProduct(Math.max(value - 1, 1));
        self.sizeInput(self.getResizeElement(Math.max(value - 1, 1)));
    }

    self.addQuantityProduct = (id) => {
        if (id !== self.id) {
            return;
        }

        const value = parseInt(self.quantityProduct()) || 1;

        self.quantityProduct(value + 1);
        self.sizeInput(self.getResizeElement(value + 1));

    }

    self.deleteFromCart = (id) => {
        if (id === self.id) {
            self.inCart(false);
        }

        self.recommendationArray([...self.recommendationArray().map((_element, _index) => {
            if (_element.id === id) {
                return {..._element, inCart: false}
            }
            return {..._element};
        })]);

        self.visitedArray([...self.visitedArray().map((_element, _index) => {
            if (_element.id === id) {
                return {..._element, inCart: false}
            }
            return {..._element};
        })]);
    }

    self.addToCart = (id) => {
        parentSelf.headerController.apiAddProduct(id)
        if (id === self.id) {
            self.inCart(true);
            parentSelf.headerController.changeQuantityProduct(self.id, self.quantityProduct());
        }

        self.recommendationArray([...self.recommendationArray().map((_element, _index) => {
            if (_element.id === id) {
                return {..._element, inCart: true}
            }
            return {..._element};
        })]);

        self.visitedArray([...self.visitedArray().map((_element, _index) => {
            if (_element.id === id) {
                return {..._element, inCart: true}
            }
            return {..._element};
        })]);
    }

    parentSelf.headerController.initialRelation(
        self.deleteFromCart,
        self.addQuantityProduct,
        self.minusQuantityProduct,
        self.changeQuantityProduct
    );

    const loadElements = (arr) => {
        return arr.map((_val, index) => {
            let isDiscount = false, priceDiscount = _val.price;
            if (_val["start_sale"] && _val["end_sale"]) {
                const dateStart = new Date(Date.parse(`${_val["end_sale"]}`)),
                    dateEnd = new Date(Date.parse(`${_val["end_sale"]}`));
                if (dateStart && dateEnd && Date.now() - dateEnd < 0) {
                    isDiscount = true;
                    priceDiscount = ((100 - _val.sale) / 100 * _val.price).toFixed()
                }
            }
            return {
                id: _val.id,
                isDelete: _val["on_delete"],
                imageUrl: _val.image ? _val.image.image : '',
                title: _val.title,
                price: _val.price,
                priceDiscount: priceDiscount,
                inCart: false,
                isDiscount: isDiscount,
            }
        })
    }

    // loads data
    const loadData = async () => {
        let visitedElements = localStorage.getItem("visitedElements");
        if (visitedElements) {
            try {
                visitedElements = visitedElements.split(',').map((_el) => parseInt(_el));
                visitedElements.unshift(self.id);
                visitedElements = Array.from(new Set(visitedElements));
                visitedElements = visitedElements.join(",");

            } catch (e) {
                visitedElements = `${self.id}`;
            }
        } else {
            visitedElements = `${self.id}`;
        }
        localStorage.setItem("visitedElements", visitedElements);
        try {
            let responseVisited = await fetch(`/api/products/elements?products_list=${visitedElements}`, {
                method: "GET", // или 'PUT'
                headers: {
                    "Content-Type": "application/json",
                },
            });
            responseVisited = await responseVisited.json();
            let responseRecommendation = await fetch(`/api/products/recommendation?products_list=${visitedElements}`, {
                method: "GET", // или 'PUT'
                headers: {
                    "Content-Type": "application/json",
                },
            });

            const cartProducts = parentSelf.headerController.apiGetCartProducts();

            responseRecommendation = await responseRecommendation.json();
            responseVisited = loadElements(responseVisited);
            responseRecommendation = loadElements(responseRecommendation);
            if (cartProducts.length) {
                for (const cartProduct of cartProducts) {
                    if (cartProduct.id === self.id) {
                        self.inCart(true);
                        self.quantityProduct(cartProduct.quantityProduct());
                    }
                    responseRecommendation = responseRecommendation.map(_element => {
                        if (_element.id === cartProduct.id) {
                            return {..._element, inCart: true};
                        }
                        return {..._element};
                    })
                    responseVisited = responseVisited.map(_element => {
                        if (_element.id === cartProduct.id) {
                            return {..._element, inCart: true};
                        }
                        return {..._element};
                    })
                }
            }

            self.recommendationArray(responseRecommendation);
            self.visitedArray(responseVisited);
            initialValue();
            updateArrow();
            updateSliders()
        } catch (error) {
            console.error("Error:", error);
        }

        // api/products/elements?products_list=
    }

    loadData();
    //
    // action user
    const listImagesElements = document.querySelectorAll('article.content-block > section.image-block > div.small-photos-block > img.small-photo');
    const listPaginationElement = document.querySelectorAll('article.content-block > section.image-block > div.pagination-photo-block > .dot-pagination');
    const mainPhoto = document.getElementById("main-photo");
    const photoBlock = document.querySelector('article.content-block > section.image-block > div.main-photo-block');
    const rightArrowImage = document.querySelector('article.content-block > section.image-block > div.main-photo-block > div.right.arrow-block > div');
    const leftArrowImage = document.querySelector('article.content-block > section.image-block > div.main-photo-block > div.left.arrow-block > div');
    let startPhotoX = 0, checkMove = false;


    const removeActivePhoto = (index) => {
        const elementPagination = document.querySelector(`#pagination-photo-element-${index}`);
        const elementPaginationPhoto = document.querySelector(`#small-photo-element-${index}`);
        elementPaginationPhoto.classList.remove('active');
        elementPagination.classList.remove('active');
    }

    const setActivePhoto = (index) => {
        const elementPagination = document.querySelector(`#pagination-photo-element-${index}`);
        const elementPaginationPhoto = document.querySelector(`#small-photo-element-${index}`);
        elementPaginationPhoto.classList.add('active');
        elementPagination.classList.add('active');
        mainPhoto.dataset.index = `${index}`;
        mainPhoto.src = elementPaginationPhoto.src;
    }

    const nextPhoto = () => {
        const currentId = parseInt(mainPhoto.dataset.index);
        const nextId = (currentId + 1) % listImagesElements.length;
        removeActivePhoto(currentId);
        setActivePhoto(nextId);
    }

    const prevPhoto = () => {
        const currentId = parseInt(mainPhoto.dataset.index);
        let prevId = currentId - 1;
        if (prevId < 0) {
            prevId = listImagesElements.length - 1
        }

        removeActivePhoto(currentId);
        setActivePhoto(prevId);
    };

    const setPhoto = (event) => {
        const currentId = parseInt(mainPhoto.dataset.index);
        const newId = parseInt(event.target.id.split("-").at(-1));
        removeActivePhoto(currentId);
        setActivePhoto(newId);
    };

    const handleTouchStart = (event) => {
        startPhotoX = event.touches[0].clientX;
        checkMove = true
    };

    const handleTouchMove = (event) => {
        let currentX = event.touches[0].clientX, deltaX = currentX - startPhotoX;
        if (deltaX > 100 && checkMove) {
            prevPhoto();
            checkMove = false;
        } else if (deltaX < -100 && checkMove) {
            nextPhoto();
            checkMove = false;
        }
    };

    listImagesElements.forEach(item => {
        item.addEventListener('click', setPhoto)
    });

    listPaginationElement.forEach(item => {
        item.addEventListener('click', setPhoto)
    });

    rightArrowImage.addEventListener('click', nextPhoto);
    leftArrowImage.addEventListener('click', prevPhoto);

    photoBlock.addEventListener("touchstart", handleTouchStart);
    photoBlock.addEventListener('touchmove', handleTouchMove);

    // sliders
    let widthCardResponsive = [21.8, 45.83, 43.12],
        visitedSlider = document.querySelector("#visited-slider"),
        recommendationSlider = document.querySelector("#recommendation-slider"),
        visitedSliderContainer = document.querySelector(".card-slider:has(#visited-slider)"),
        recommendationSliderContainer = document.querySelector(".card-slider:has(#recommendation-slider)");
    let leftArrowVisited = visitedSliderContainer.querySelector('.slider-list-element .slider-left-container'),
        rightArrowVisited = visitedSliderContainer.querySelector('.slider-list-element .slider-right-container'),
        leftArrowRecommendation = recommendationSliderContainer.querySelector('.slider-list-element .slider-left-container'),
        rightArrowRecommendation = recommendationSliderContainer.querySelector('.slider-list-element .slider-right-container');
    let vw = 0, widthCard = 1, leftRecommendationSlider = 0, leftVisitedSlider = 0, h = 0, w = 0, typeWidth = 0;


    const checkIsMinValue = (value) => {
        return value >= 0;
    }

    const checkIsMaxValue = (value, width) => {
        return w + 15 >= width + value
    }

    const updateArrow = () => {
        if (checkIsMinValue(leftVisitedSlider) || typeWidth === 2) {
            leftArrowVisited.style.display = 'none';
        } else {
            leftArrowVisited.style.display = 'block';
        }

        if (checkIsMaxValue(leftVisitedSlider, visitedSlider.clientWidth) || typeWidth === 2) {
            rightArrowVisited.style.display = 'none';
        } else {
            rightArrowVisited.style.display = 'block';
        }

        if (checkIsMinValue(leftRecommendationSlider) || typeWidth === 2) {
            leftArrowRecommendation.style.display = 'none';
        } else {
            leftArrowRecommendation.style.display = 'block';
        }

        if (checkIsMaxValue(leftRecommendationSlider, recommendationSlider.clientWidth) || typeWidth === 2) {
            rightArrowRecommendation.style.display = 'none';
        } else {
            rightArrowRecommendation.style.display = 'block';
        }

    }

    const getNormalValue = (value, width) => {
        if (checkIsMinValue(value)) {
            return 0;
        } else if (checkIsMaxValue(value, width)) {
            return w - width - 15;
        }
        return parseInt(value);
    }

    const initialValue = () => {
        h = document.documentElement.clientHeight;
        w = document.documentElement.clientWidth;
        const vh = h / 100;
        vw = w / 100;
        let newWidthCard = 0;
        if (vw / vh <= 99 / 100) {
            typeWidth = 2;
            newWidthCard = vw * widthCardResponsive[2];
        } else if (vw / vh <= 16 / 10) {
            typeWidth = 1;
            newWidthCard = vw * widthCardResponsive[1];
        } else {
            typeWidth = 1;
            newWidthCard = vw * widthCardResponsive[0];
        }

        leftVisitedSlider = parseInt((leftVisitedSlider / widthCard) * newWidthCard);
        leftRecommendationSlider = parseInt((leftRecommendationSlider / widthCard) * newWidthCard);
        widthCard = newWidthCard;
        updateSliders();
        updateArrow();
        visitedSlider = document.querySelector("#visited-slider");
        recommendationSlider = document.querySelector("#recommendation-slider");
        visitedSliderContainer = document.querySelector(".card-slider:has(#visited-slider)");
        recommendationSliderContainer = document.querySelector(".card-slider:has(#recommendation-slider)");
        leftArrowVisited = visitedSliderContainer.querySelector('.slider-list-element .slider-left-container');
        rightArrowVisited = visitedSliderContainer.querySelector('.slider-list-element .slider-right-container');
        leftArrowRecommendation = recommendationSliderContainer.querySelector('.slider-list-element .slider-left-container');
        rightArrowRecommendation = recommendationSliderContainer.querySelector('.slider-list-element .slider-right-container');
    }

    const updateSliders = () => {
        visitedSlider.style.left = `${leftVisitedSlider}px`;
        recommendationSlider.style.left = `${leftRecommendationSlider}px`;
        visitedSliderContainer
            .querySelector('.slider-progress')
            .style.setProperty('--width-slider', `${((leftVisitedSlider * -1 + w) / (visitedSlider.clientWidth / 100)).toFixed(2)}%`);
        recommendationSliderContainer
            .querySelector('.slider-progress')
            .style.setProperty('--width-slider', `${((leftRecommendationSlider * -1 + w) / (recommendationSlider.clientWidth / 100)).toFixed(2)}%`);
    }

    setTimeout(() => initialValue(), 200);

    const changeLeftSliders = (type, value) => {
        if (type === 'recommendation') {
            leftRecommendationSlider = getNormalValue(leftRecommendationSlider + value, recommendationSlider.clientWidth);
        } else {
            leftVisitedSlider = getNormalValue(leftVisitedSlider + value, visitedSlider.clientWidth);
        }
        updateSliders();
        updateArrow();
    }

    const leftArrowAction = (type) => {
        changeLeftSliders(type, widthCard);
    }

    const rightArrowAction = (type) => {
        changeLeftSliders(type, -widthCard);
    }

    leftArrowVisited.addEventListener('click', () => leftArrowAction());
    rightArrowVisited.addEventListener('click', () => rightArrowAction());
    leftArrowRecommendation.addEventListener('click', () => leftArrowAction('recommendation'));
    rightArrowRecommendation.addEventListener('click', () => rightArrowAction('recommendation'));

    window.addEventListener('resize', () => initialValue());

    let prevSliderX = 0;

    const handleTouchStartSliders = (event) => {
        prevSliderX = event.touches[0].clientX;
    };

    const handleTouchMoveSliders = (type, event) => {
        let currentX = event.touches[0].clientX, deltaX = currentX - prevSliderX;
        prevSliderX = currentX;
        changeLeftSliders(type, deltaX);
    };

    visitedSlider.addEventListener("touchstart", handleTouchStartSliders);
    visitedSlider.addEventListener('touchmove', (event) => handleTouchMoveSliders("", event));
    recommendationSlider.addEventListener("touchstart", handleTouchStartSliders);
    recommendationSlider.addEventListener('touchmove', (event) => handleTouchMoveSliders("recommendation", event));

}