function MainViewModel(parentSelf) {
    let self = this;

    self.recommendationList = ko.observableArray([]);
    self.recommendationFullList = [];

    self.isAnimationMore = ko.observable(false);

    self.visitedElements = '';

    self.maxInRow = 2;
    self.page = 1;
    self.maxPage = 1;

    const resizeElement = () => {
        const h = document.documentElement.clientHeight,
            w = document.documentElement.clientWidth;
        let newWidthCard = 0;
        if (w / h <= 16 / 10) {
            self.maxInRow = 2;
        } else {
            self.maxInRow = 4;
        }

        self.recommendationList(self.recommendationFullList.slice(0, self.page*self.maxInRow));
    }

    resizeElement();



    self.showMore = function () {
        if (self.page === self.maxPage) {
            return;
        }
        self.isAnimationMore(true);
        self.page = self.page + 1;
        self.recommendationList(self.recommendationFullList.slice(0, self.page*self.maxInRow));
        self.isAnimationMore(false);
    }

    self.addToCartHandler = function (oT, event) {
        event.preventDefault();
        event.stopPropagation();
        self.addToCart(oT.id);
        parentSelf.headerController.apiAddProduct(oT.id);
    }

    self.deleteFromCartHandler = function (oT, event) {
        event.preventDefault();
        event.stopPropagation();
        self.deleteFromCart(oT.id);
        parentSelf.headerController.apiDeleteProduct(oT.id);
    }

    self.openProduct = function (oT, event) {
        window.location.href = `/products/${oT.id}`;
    }

    self.deleteFromCart = function (id) {
        self.recommendationFullList = self.recommendationFullList.map((_element, _index) => {
            if (_element.id === id) {
                return {..._element, inCart: false}
            }
            return {..._element};
        });
        self.recommendationList([...self.recommendationList().map((_element, _index) => {
            if (_element.id === id) {
                return {..._element, inCart: false}
            }
            return {..._element};
        })]);
    }

    self.addToCart = function (id) {
        self.recommendationFullList = self.recommendationFullList.map((_element, _index) => {
            if (_element.id === id) {
                return {..._element, inCart: true}
            }
            return {..._element};
        });
        self.recommendationList([...self.recommendationList().map((_element, _index) => {
            if (_element.id === id) {
                return {..._element, inCart: true}
            }
            return {..._element};
        })]);
    }
    const loadElements = (arr) => {
        return arr.map((_val, index) => {
            let isDiscount = false, priceDiscount = _val.price;
            if (_val["start_sale"] && _val["end_sale"]) {
                const dateStart = new Date(Date.parse(`${_val["end_sale"]}`)),
                    dateEnd = new Date(Date.parse(`${_val["end_sale"]}`));
                if (dateStart && dateEnd && Date.now() - dateEnd < 0) {
                    isDiscount = true;
                    priceDiscount = ((100 - _val.sale) / 100 * _val.price).toFixed()
                }
            }
            return {
                id: _val.id,
                isDelete: _val["on_delete"],
                imageUrl: _val.image ? _val.image.image : '',
                title: _val.title,
                price: _val.price,
                priceDiscount: priceDiscount,
                inCart: false,
                isDiscount: isDiscount,
            }
        })
    }

    self.loadsFromBaseElement = async function () {
        self.visitedElements = localStorage.getItem("visitedElements");
        if (self.visitedElements) {
            try {
                self.visitedElements = self.visitedElements.split(',').map((_el) => parseInt(_el));
                self.visitedElements = Array.from(new Set(self.visitedElements));
                self.visitedElements = self.visitedElements.join(",");

            } catch (e) {
                self.visitedElements = ``;
            }
        } else {
            self.visitedElements = ``;
        }
        try {
            let responseRecommendation = await fetch(`/api/products/recommendation?products_list=${self.visitedElements}`, {
                method: "GET", // или 'PUT'
                headers: {
                    "Content-Type": "application/json",
                },
            });

            const cartProducts = parentSelf.headerController.apiGetCartProducts();

            responseRecommendation = await responseRecommendation.json();
            responseRecommendation = loadElements(responseRecommendation);
            if (cartProducts.length) {
                for (const cartProduct of cartProducts) {
                    responseRecommendation = responseRecommendation.map(_element => {
                        if (_element.id === cartProduct.id) {
                            return {..._element, inCart: true};
                        }
                        return {..._element};
                    })
                }
            }

            self.recommendationFullList = responseRecommendation;
            self.maxPage = Math.ceil(self.recommendationFullList / self.maxInRow);

            self.recommendationList(responseRecommendation.slice(0, self.page*self.maxInRow));
        } catch (error) {
            console.error("Error:", error);
        }
    }


    parentSelf.headerController.initialRelation(self.deleteFromCart);



    self.loadsFromBaseElement();

    window.addEventListener('resize', () => resizeElement());
}