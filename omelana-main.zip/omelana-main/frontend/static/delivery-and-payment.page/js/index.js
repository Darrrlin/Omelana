function DeliveryAndPaymentViewModel () {

}