function AgreementViewModel (parentSelf) {

}